// ==UserScript==
// @name               IG Helper
// @name:ar            أداة IG
// @name:de            IG-Helfer
// @name:es            Ayudante de IG
// @name:fr            Assistant IG
// @name:id            Asisten IG
// @name:it            Assistente IG
// @name:ja            IG助手
// @name:ko            IG조수
// @name:pt-BR         Assistente do IG
// @name:ro            IG Helper
// @name:ru            Помощник IG
// @name:th            ตัวช่วย IG
// @name:tr            IG Yardımcısı
// @name:vi            Trợ lý IG
// @name:zh-CN         IG小助手
// @name:zh-TW         IG小精靈
// @namespace          https://github.snkms.com/
// @version            4.0.3
// @description        Download photos and videos from Instagram posts in one click, including Stories, Reels, and profile pictures.
// @description:ar     نزّل صورًا ومقاطع فيديو من منشورات Instagram بنقرة واحدة، بما في ذلك القصص وReels وصور الملف الشخصي.
// @description:de     Lade Fotos und Videos aus Instagram-Beiträgen mit einem Klick herunter, einschließlich Stories, Reels und Profilbildern.
// @description:es     Descarga fotos y videos de publicaciones de Instagram con un clic, incluyendo Stories, Reels y fotos de perfil.
// @description:fr     Téléchargez en un clic les photos et vidéos des publications Instagram, y compris les Stories, les Reels et les photos de profil.
// @description:id     Unduh foto dan video dari postingan Instagram dalam satu klik, termasuk Stories, Reels, dan foto profil.
// @description:it     Scarica foto e video dai post di Instagram con un solo clic, incluse Storie, Reels e foto del profilo.
// @description:ja     Instagramの投稿の写真や動画をワンクリックでダウンロード。ストーリー、リール、プロフィール写真にも対応。
// @description:ko     한 번의 클릭으로 Instagram 게시물의 사진과 동영상을 다운로드하고, 스토리, 릴스, 프로필 사진도 지원합니다.
// @description:pt-BR  Baixe fotos e vídeos de publicações do Instagram com um clique, incluindo Stories, Reels e fotos de perfil.
// @description:ro     Descarcă cu un singur clic fotografii și videoclipuri din postările Instagram, inclusiv storyuri, reels și fotografii de profil.
// @description:ru     Скачивайте фото и видео из публикаций Instagram в один клик, включая Stories, Reels и фото профиля.
// @description:th     ดาวน์โหลดรูปภาพและวิดีโอจากโพสต์ Instagram ได้ในคลิกเดียว รวมถึง Stories, Reels และรูปโปรไฟล์.
// @description:tr     Instagram gönderilerindeki fotoğraf ve videoları tek tıkla indirin; Hikayeler, Reels ve profil fotoğrafları da dahildir.
// @description:vi     Tải xuống ảnh và video từ bài viết trên Instagram chỉ với một cú nhấp, bao gồm Stories, Reels và ảnh đại diện.
// @description:zh-CN  一键下载 Instagram 帖子中的照片和视频，还包括快拍、Reels 和头像。
// @description:zh-TW  一鍵下載 Instagram 貼文中的照片、影片，還包含限時動態、Reels 與大頭貼。
// @author             SN-Koarashi (5026)
// @match              https://*.instagram.com/*
// @grant              GM_addStyle
// @grant              GM_getResourceText
// @grant              GM_getValue
// @grant              GM_info
// @grant              GM_notification
// @grant              GM_openInTab
// @grant              GM_registerMenuCommand
// @grant              GM_setValue
// @grant              GM_unregisterMenuCommand
// @grant              GM_xmlhttpRequest
// @connect            cdn.jsdelivr.net
// @connect            i.instagram.com
// @connect            raw.githubusercontent.com
// @require            https://cdn.jsdelivr.net/npm/mediabunny@1.34.5/dist/bundles/mediabunny.min.cjs#sha256-wUFR+x2bDvpqgMAVGy2CvGvULyjTGvGy4UUAm8rae5U=
// @require            https://code.jquery.com/jquery-4.0.0.min.js#sha256-OaVG6prZf4v69dPg6PhVattBXkcOWQB62pdZ3ORyrao=
// @resource           INTERNAL_CSS https://cdn.jsdelivr.net/gh/SN-Koarashi/ig-helper@master/style.css
// @resource           LOCALE_MANIFEST https://cdn.jsdelivr.net/gh/SN-Koarashi/ig-helper@master/locale/manifest.json
// @supportURL         https://github.com/SN-Koarashi/ig-helper/
// @contributionURL    https://ko-fi.com/snkoarashi
// @icon               https://www.google.com/s2/favicons?domain=www.instagram.com&sz=32
// @compatible         chrome >= 100
// @compatible         edge >= 100
// @compatible         firefox >= 100
// @license            GPL-3.0-only
// @run-at             document-idle
// @downloadURL https://update.greasyfork.org/scripts/404535/IG%20Helper.user.js
// @updateURL https://update.greasyfork.org/scripts/404535/IG%20Helper.meta.js
// ==/UserScript==

// eslint-disable-next-line no-unused-vars
(function ($, Mediabunny) {
    'use strict';

    /* initial */

    /******** USER SETTINGS ********/
    // !!! DO NOT CHANGE THIS AREA !!!
    // ??? PLEASE CHANGE SETTING WITH MENU ???
    const USER_SETTING = {
        'AUTO_RENAME': true,
        'CAPTURE_IMAGE_VIA_MEDIA_CACHE': true,
        'CHECK_FOR_UPDATE': true,
        'DIRECT_DOWNLOAD_ALL': false,
        'DIRECT_DOWNLOAD_STORY': false,
        'DIRECT_DOWNLOAD_VISIBLE_RESOURCE': false,
        'DISABLE_VIDEO_LOOPING': false,
        'FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED': false,
        'FORCE_FETCH_ALL_RESOURCES': false,
        'FORCE_RESOURCE_VIA_MEDIA': false,
        'HTML5_VIDEO_CONTROL': false,
        'MODIFY_RESOURCE_EXIF': false,
        'MODIFY_VIDEO_VOLUME': false,
        'NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST': false,
        'PREFER_DASH_MANIFEST': false,
        'REDIRECT_CLICK_USER_STORY_PICTURE': false,
        'RENAME_PUBLISH_DATE': true,
        'SCROLL_BUTTON': true,
        'SKIP_VIEW_STORY_CONFIRM': false,
        'SKIP_SHARED_WITH_YOU_DIALOG': false
    };

    const PARENT_CHILD_MAPPING = {
        'AUTO_RENAME': [
            'RENAME_PUBLISH_DATE'
        ],
        'FORCE_RESOURCE_VIA_MEDIA': [
            'FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED',
            'NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST',
            'PREFER_DASH_MANIFEST'
        ]
    };
    const IMAGE_CACHE_KEY = 'URLS_OF_IMAGES_TEMPORARILY_STORED';
    const IMAGE_CACHE_MAX_AGE = 12 * 60 * 60 * 1000; // 12h in ms
    const IMAGE_MAX_CACHE_ITEMS = 300;
    /*******************************/

    // Icon download by Google Fonts Material Icon & Lucide
    const SVG = {
        DOWNLOAD: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-download-icon lucide-download"><path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/></svg>',
        NEW_TAB: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-external-link-icon lucide-external-link"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>',
        THUMBNAIL: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-image-icon lucide-image"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>',
        DOWNLOAD_ALL: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-cloud-download-icon lucide-cloud-download"><path d="M12 13v8l-4-4"/><path d="m12 21 4-4"/><path d="M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284"/></svg>',
        CLOSE: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>',
        FULLSCREEN: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-maximize-icon lucide-maximize"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
        TURN_DEG: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#1f1f1f"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7.34 6.41L.86 12.9l6.49 6.48 6.49-6.48-6.5-6.49zM3.69 12.9l3.66-3.66L11 12.9l-3.66 3.66-3.65-3.66zm15.67-6.26C17.61 4.88 15.3 4 13 4V.76L8.76 5 13 9.24V6c1.79 0 3.58.68 4.95 2.05 2.73 2.73 2.73 7.17 0 9.9C16.58 19.32 14.79 20 13 20c-.97 0-1.94-.21-2.84-.61l-1.49 1.49C10.02 21.62 11.51 22 13 22c2.3 0 4.61-.88 6.36-2.64 3.52-3.51 3.52-9.21 0-12.72z"/></svg>'
    };

    /*******************************/

    // FIX: resourceCountSelector moved to module scope — was previously re-declared
    // inside every createDownloadButton() invocation, and also referenced from the
    // body-level delegated handlers added below.

    // Improve the selector by using the value from the getVisibleNodeIndex function in 'const $viewport'.
    const resourceCountSelector = '*:not([data-pagelet])>*:not([role]):not([data-pagelet])>*>*>*[role]>*>ul[class] li[class]';

    /*******************************/
    const checkInterval = 250;
    const style = GM_getResourceText("INTERNAL_CSS");
    const locale_manifest = JSON.parse(GM_getResourceText("LOCALE_MANIFEST"));

    const userIdCache = new Map();

    // OPTIMIZATION: Cached jQuery body reference — used in many places, jQuery 4
    // creates a new wrapper for each $('body') call. Reusing $body avoids that
    // overhead while remaining 100% behavior-compatible.
    const $body = $('body');

    var state = {
        videoVolume: (GM_getValue('G_VIDEO_VOLUME')) ? GM_getValue('G_VIDEO_VOLUME') : 1,
        tempFetchRateLimit: false,
        fileRenameFormat: (GM_getValue('G_RENAME_FORMAT')) ? GM_getValue('G_RENAME_FORMAT') : '%USERNAME%-%SOURCE_TYPE%-%SHORTCODE%-%YEAR%%MONTH%%DAY%_%HOUR%%MINUTE%%SECOND%_%ORIGINAL_NAME_FIRST%',
        registerMenuIds: [],
        locale: {},
        lang: GM_getValue('UI_LANGUAGE') || navigator.language || navigator.userLanguage,
        currentURL: location.href,
        firstStarted: false,
        pageLoaded: false,
        GL_logger: [],
        GL_referrer: null,
        GL_postPath: null,
        GL_username: null,
        GL_repeat: null,
        GL_dataCache: {
            stories: {},
            highlights: {}
        },
        GL_observer: new MutationObserver(function () {
            onReadyMyDW();
        }),
        GL_imageCache: GM_getValue(IMAGE_CACHE_KEY, {}),
        GL_mediaDataCache: {},
        GL_weakCache: {
            overlay: new WeakMap(),
            mutedButton: new WeakMap(),
        },
        debugHotkeyKeyCode: (GM_getValue('G_HOTKEY_DEBUG_KEYCODE')) ? GM_getValue('G_HOTKEY_DEBUG_KEYCODE') : 90,
        settingsHotkeyKeyCode: (GM_getValue('G_HOTKEY_SETTINGS_KEYCODE')) ? GM_getValue('G_HOTKEY_SETTINGS_KEYCODE') : 87,
        keySettingsHotkeyKeyCode: (GM_getValue('G_HOTKEY_KEY_SETTINGS_KEYCODE')) ? GM_getValue('G_HOTKEY_KEY_SETTINGS_KEYCODE') : 67,
        downloadStoryHotkeyKeyCode: (GM_getValue('G_HOTKEY_DOWNLOAD_STORY_KEYCODE')) ? GM_getValue('G_HOTKEY_DOWNLOAD_STORY_KEYCODE') : 83
    };
    /*******************************/

    // initialization script
    initSettings();
    GM_addStyle(style);
    registerMenuCommand();

    getTranslationText(state.lang).then((res) => {
        state.locale[state.lang] = res;
        repaintingTranslations();
        registerMenuCommand();
        checkingScriptUpdate(300);
    }).catch((err) => {
        registerMenuCommand();
        checkingScriptUpdate(300);

        if (!state.lang.startsWith('en')) {
            console.error('getTranslationText catch error:', err);
        }
    });

    logger('Script Loaded', GM_info.script.name, 'version:', GM_info.script.version);
    registerPostClickHandlers();
    purgeCache();
    /*******************************/

    // Main Timer
    // eslint-disable-next-line no-unused-vars
    var timer = setInterval(function () {
        // page loading or unnecessary route
        if ($('div#splash-screen').length > 0 && !$('div#splash-screen').is(':hidden') ||
            location.pathname.match(/^\/(explore(\/.*)?|challenge\/?.*|direct\/?.*|qr\/?|accounts\/.*|emails\/.*|language\/?.*?|your_activity\/?.*|settings\/help(\/.*)?$)$/ig) ||
            !location.hostname.startsWith('www.') || location.pathname.startsWith('/auth_platform/codeentry/') || location.pathname.startsWith('/challenge/') ||
            location.pathname.startsWith('/consent/') || location.pathname.startsWith('/accounts/') ||
            ((location.pathname.endsWith('/followers/') || location.pathname.endsWith('/following/')) && ($(`body > div[class]:not([id^="mount"]) div div[role="dialog"]`).length > 0))
        ) {
            state.pageLoaded = false;
            return;
        }

        if (state.currentURL != location.href || !state.firstStarted || !state.pageLoaded) {
            console.log('Main Timer', 'trigging');

            clearInterval(state.GL_repeat);
            state.pageLoaded = false;
            state.firstStarted = true;
            state.currentURL = location.href;
            clearTimeout(state.homepageObserverDebounce);
            if (!state.currentURL.includes('/stories/') || !location.pathname.startsWith('/stories/')) {
                state.GL_observer.disconnect();
            }

            // Auto-skip "X shared this with you" dialog on any ?igsh= link
            if (USER_SETTING.SKIP_SHARED_WITH_YOU_DIALOG && window.location.search.includes("igsh")) {
                let tries = 0;
                const skipTimer = setInterval(() => {
                    tries += 1;

                    // stop early if URL no longer has ?igsh (navigation changed)
                    if (!window.location.search.includes("igsh")) {
                        clearInterval(skipTimer);
                        return;
                    }

                    skipSharedWithYouDialog();

                    if (tries >= 20) {
                        clearInterval(skipTimer);
                    }
                }, 200);
            }

            if (location.pathname.startsWith("/p/") || location.pathname.match(/^\/(.*?)\/(p|reel)\//ig) || location.pathname.startsWith("/reel/")) {
                state.GL_dataCache.stories = {};
                state.GL_dataCache.highlights = {};

                logger('isDialog');

                // This is a delayed function call that prevents the dialog element from appearing before the function is called.
                var dialogTimer = setInterval(() => {
                    // body > div[id^="mount"] section nav + div > article << (mobile page in single post) >>
                    // section:visible > main > div > div > div > div > div > hr << (single foreground post in page, non-floating // <hr> element here is literally the line beneath poster's username) >>
                    // section:visible > main > div > div > article > div > div > div > div > div > header (is the same as above, except that this is on the route of the /{username}/p/{shortcode} structure)
                    // section:visible > main > div > div.xdt5ytf << (former CSS selector for single foreground post in page, non-floating) >>
                    // <hr> is much more unique element than "div.xdt5ytf"
                    if ($(`body > div[class]:not([id^="mount"]) div div[role="dialog"] article,
                                section:visible > main > div > div > div > div > div > hr,
                                body > div[id^="mount"] section nav + div > article,
                                section:visible > main > div > div > article > div > div > div > div > div > header
                            `).length > 0) {
                        clearInterval(dialogTimer);

                        // This is to prevent the detection of the "Modify Video Volume" setting from being too slow.
                        setTimeout(() => {
                            clearInterval(state.GL_repeat);
                            state.GL_repeat = null;
                            onReadyMyDW(false);
                        }, 15);
                    }
                }, 100);

                state.pageLoaded = true;
            }

            if (location.pathname.startsWith("/reels/")) {
                logger('isReelsPage');
                setTimeout(() => {
                    onReels(false);
                }, 150);
                state.pageLoaded = true;
            }

            if (location.pathname === "/") {
                state.GL_dataCache.stories = {};
                state.GL_dataCache.highlights = {};

                let hasReferrer = state.GL_referrer?.match(/^\/(stories|highlights)\//ig) != null;

                logger('isHomepage', hasReferrer);
                setTimeout(() => {
                    onReadyMyDW(false, hasReferrer);

                    const element = $('div[id^="mount"] > div > div div > section > main div:not([class]):not([style]) > div > article')?.parent()[0];
                    if (element) {
                        state.GL_observer.disconnect();
                        state.GL_observer.observe(element, {
                            childList: true
                        });
                    }
                }, 150);

                state.pageLoaded = true;
            }

            if (
                $('header > *[class]:first-child img[alt]').length &&
                // eslint-disable-next-line no-useless-escape
                location.pathname.match(/^(\/)([0-9A-Za-z\.\-_]+)\/?(tagged|reels|saved)?\/?$/ig) &&
                !location.pathname.match(/^(\/explore\/?$|\/stories(\/.*)?$|\/p\/)/ig)
            ) {
                logger('isProfile');
                setTimeout(() => {
                    onProfileAvatar(false);
                }, 150);
                state.pageLoaded = true;
            }

            if (!state.pageLoaded) {
                // Call Instagram stories function
                if (location.pathname.startsWith("/stories/highlights/")) {
                    state.GL_dataCache.highlights = {};

                    logger('isHighlightsStory');

                    onHighlightsStory(false);
                    state.GL_repeat = setInterval(() => {
                        onHighlightsStoryThumbnail(false);
                    }, checkInterval);

                    if ($(".IG_DWHISTORY").length) {
                        setTimeout(() => {
                            if (USER_SETTING.SKIP_VIEW_STORY_CONFIRM) {
                                var $viewStoryButton = $('div[id^="mount"] section:last-child > div > div:not([class]) div:last-child > div[role="button"]').filter(function () {
                                    return $(this).children().length === 0 && this.textContent.trim() !== "";
                                });
                                $viewStoryButton?.trigger("click");
                            }

                            state.pageLoaded = true;
                        }, 150);
                    }
                }
                else if (location.pathname.startsWith("/stories/")) {
                    logger('isStory');

                    /*
                     *
                     *  $('body div[id^="mount"] > div > div > div[class]').length >= 2 &&
                     *  $('body div[id^="mount"] > div > div > div[class]').last().find('svg > path[d^="M16.792"], svg > path[d^="M34.6 3.1c-4.5"]').length > 0 &&
                     *  $('body div[id^="mount"] > div > div > div[class]').last().find('svg > polyline + line').length > 0
                     *
                     */
                    // ? detect logo element in left-top corner
                    if (
                        $('div[id^="mount"] section > div > a[href="/"]').length > 0 ||
                        $('div[id^="mount"] section > div > a[href^="/?hl="]').length > 0 ||
                        $('div[id^="mount"] section i[aria-label="Instagram"]').length > 0
                    ) {
                        $('.IG_DWSTORY').remove();
                        $('.IG_DWNEWTAB').remove();
                        if ($('.IG_DWSTORY_THUMBNAIL').length) {
                            $('.IG_DWSTORY_THUMBNAIL').remove();
                        }
                        if ($('.IG_DWSTORY_POSITION').length) {
                            $('.IG_DWSTORY_POSITION').remove();
                        }

                        onStory(false);

                        // Prevent buttons from being eaten by black holes sometimes
                        setTimeout(() => {
                            onStory(false);
                        }, 150);
                    }

                    if ($(".IG_DWSTORY").length) {
                        setTimeout(() => {
                            if (USER_SETTING.SKIP_VIEW_STORY_CONFIRM) {
                                var $viewStoryButton = $('div[id^="mount"] section:last-child > div > div:not([class]) div:last-child > div[role="button"]').filter(function () {
                                    return $(this).children().length === 0 && this.textContent.trim() !== "";
                                });
                                $viewStoryButton?.trigger("click");
                            }

                            state.pageLoaded = true;
                        }, 150);
                    }
                }
                else {
                    state.pageLoaded = false;
                    // Remove icons
                    // OPTIMIZATION: Single combined selector + .remove() — replaces 8 separate
                    // $('.CLASS').length checks + removes. Behavior is identical because
                    // .remove() is a no-op on an empty set.
                    $('.IG_DWSTORY, .IG_DWSTORY_ALL, .IG_DWNEWTAB, .IG_DWSTORY_THUMBNAIL, .IG_DWSTORY_POSITION, .IG_DWHISTORY, .IG_DWHISTORY_ALL, .IG_DWHINEWTAB, .IG_DWHISTORY_THUMBNAIL, .IG_DWHISTORY_POSITION').remove();
                }
            }

            checkingScriptUpdate(300);
            state.GL_referrer = new URL(location.href).pathname;
        }
    }, checkInterval);

    /* Main functions */

    /**
     * getHighlightsStoryUsername
     * @description Get the current highlight story owner's username.
     *
     * @return {?String}
     */
    function getHighlightsStoryUsername() {
        let href = $('body > div section:visible a[href^="/"]').filter(function () {
            return $(this).attr('href').split('/').filter(e => e.length > 0).length === 1
        }).first().attr('href');

        return href?.split('/').filter(e => e.length > 0).at(0);
    }

    /**
     * onHighlightsStoryAll
     * @description Trigger user's highlight all download event.
     *
     * @return {void}
     */
    async function onHighlightsStoryAll() {
        updateLoadingBar(true);

        let date = new Date().getTime();
        let timestamp = Math.floor(date / 1000);
        let highlightId = location.href.replace(/\/$/ig, '').split('/').at(-1);
        let highStories = await getHighlightStories(highlightId);
        let username = highStories.data.reels_media[0].owner.username;

        if (USER_SETTING.DIRECT_DOWNLOAD_STORY) {

            let complete = 0;
            // OPTIMIZATION: Cache items array — accessed inside per-item setTimeout closures,
            // avoids repeated .reels_media[0].items lookups (was 3 lookups per iteration).
            const items = highStories.data.reels_media[0].items;
            const totalItems = items.length;
            setDownloadProgress(complete, totalItems);

            items.forEach((item, idx) => {
                setTimeout(() => {
                    if (USER_SETTING.RENAME_PUBLISH_DATE) {
                        timestamp = item.taken_at_timestamp;
                    }

                    item.display_resources.sort(function (a, b) {
                        if (a.config_width < b.config_width) return 1;
                        if (a.config_width > b.config_width) return -1;
                        return 0;
                    });

                    if (item.is_video) {
                        (async () => {
                            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && USER_SETTING.PREFER_DASH_MANIFEST && !state.tempFetchRateLimit) {
                                const mi = await getMediaInfo(item.id);
                                if (mi?.status === 'ok') {
                                    const handled = await tryHandleDashFromMediaItem({
                                        mediaItem: mi.items[0],
                                        username,
                                        sourceType: "highlights",
                                        timestamp,
                                        shortcode: mi.items[0].id,
                                        isPreview: false,
                                    });
                                    if (handled) {
                                        setDownloadProgress(++complete, totalItems);
                                        return;
                                    }
                                } else if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED) {
                                    state.tempFetchRateLimit = true;
                                }
                            }

                            await saveFiles(
                                item.video_resources[0].src,
                                {
                                    username,
                                    sourceType: "highlights",
                                    timestamp,
                                    filetype: 'mp4',
                                    shortcode: item.id
                                }
                            );
                            setDownloadProgress(++complete, totalItems);
                        })();
                    }
                    else {
                        saveFiles(item.display_resources[0].src,
                            {
                                username,
                                sourceType: "highlights",
                                timestamp,
                                filetype: 'jpg',
                                shortcode: item.id
                            }).then(() => {
                                setDownloadProgress(++complete, totalItems);
                            });
                    }
                }, 100 * idx);
            });
        }
        else {
            IG_createDM(false, true);
            createStoryListDOM(highStories, 'highlights');
        }
    }

    /**
     * onHighlightsStory
     * @description Trigger user's highlight download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @param  {Boolean}  isPreview - Check if it is need to open new tab
     * @return {void}
     */
    async function onHighlightsStory(isDownload, isPreview) {
        var username = getHighlightsStoryUsername();

        if (isDownload) {
            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);
            let highlightId = location.href.replace(/\/$/ig, '').split('/').at(-1);
            let nowIndex = $("body > div section._ac0a header._ac0k > ._ac3r ._ac3n ._ac3p[style]").length ||
                $('body > div section:visible > div > div:not([class]) > div > div div.x1ned7t2.x78zum5 div.x1caxmr6').length ||
                $('body > div div:not([hidden]) section:visible > div div[style]:not([class]) > div').find('div div.x1ned7t2.x78zum5 div.x1caxmr6').length;
            let target = 0;

            updateLoadingBar(true);

            if (state.GL_dataCache.highlights[highlightId]) {
                logger('Fetch from memory cache:', highlightId);

                // OPTIMIZATION: cache items array — avoids 4 repeated property lookups
                const items = state.GL_dataCache.highlights[highlightId].data.reels_media[0].items;
                let totIndex = items.length;
                username = state.GL_dataCache.highlights[highlightId].data.reels_media[0].owner.username;
                target = items[totIndex - nowIndex];
            }
            else {
                let highStories = await getHighlightStories(highlightId);
                const items = highStories.data.reels_media[0].items;
                let totIndex = items.length;
                username = highStories.data.reels_media[0].owner.username;
                target = items[totIndex - nowIndex];

                state.GL_dataCache.highlights[highlightId] = highStories;
            }

            logger('onHighlightsStory', highlightId, state.GL_dataCache.highlights[highlightId]);

            if (USER_SETTING.RENAME_PUBLISH_DATE) {
                timestamp = target.taken_at_timestamp;
            }

            if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                const cached = getImageFromCache(target.id);
                if (cached && !state.GL_dataCache.highlights[highlightId].data.reels_media[0].items.filter(item => item.id === target.id).at(0).is_video) {
                    logger("[Restore Cached onHighlight]", target.id);
                    if (isPreview) {
                        openNewTab(cached);
                    }
                    else {
                        saveFiles(cached, {
                            username,
                            sourceType: "highlights",
                            timestamp,
                            filetype: 'jpg',
                            shortcode: target.id
                        });
                    }
                    return;
                }
            }

            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && !state.tempFetchRateLimit) {
                let result = await getMediaInfo(target.id);

                if (result.status === 'ok') {
                    // OPTIMIZATION: cache first media item — accessed 5+ times below
                    const mediaItem = result.items[0];
                    if (mediaItem.video_versions) {
                        const handled = await tryHandleDashFromMediaItem({
                            mediaItem: mediaItem,
                            username,
                            sourceType: "highlights",
                            timestamp,
                            shortcode: mediaItem.id,
                            isPreview,
                        });
                        if (handled) return;

                        if (isPreview) {
                            openNewTab(mediaItem.video_versions[0].url);
                        }
                        else {
                            saveFiles(mediaItem.video_versions[0].url,
                                {
                                    username,
                                    sourceType: "highlights",
                                    timestamp,
                                    filetype: 'mp4',
                                    shortcode: mediaItem.id
                                });
                        }
                    }
                    else {
                        if (isPreview) {
                            openNewTab(mediaItem.image_versions2.candidates[0].url);
                        }
                        else {
                            saveFiles(mediaItem.image_versions2.candidates[0].url, {
                                username,
                                sourceType: "highlights",
                                timestamp,
                                filetype: 'jpg',
                                shortcode: mediaItem.id
                            });
                        }
                    }
                }
                else {
                    if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED) {
                        delete state.GL_dataCache.highlights[highlightId];
                        state.tempFetchRateLimit = true;

                        onHighlightsStory(true, isPreview);
                    }
                    else {
                        alert('Fetch failed from Media API. API response message: ' + result.message);
                    }

                    logger(result);
                }
            }
            else {
                if (target.is_video) {
                    if (isPreview) {
                        openNewTab(target.video_resources.at(-1).src, username);
                    }
                    else {
                        saveFiles(target.video_resources.at(-1).src, {
                            username,
                            sourceType: "highlights",
                            timestamp,
                            filetype: 'mp4',
                            shortcode: target.id
                        });
                    }
                }
                else {
                    if (isPreview) {
                        openNewTab(target.display_resources.at(-1).src, username);
                    }
                    else {
                        saveFiles(target.display_resources.at(-1).src, {
                            username,
                            sourceType: "highlights",
                            timestamp,
                            filetype: 'jpg',
                            shortcode: target.id
                        });
                    }
                }

                state.tempFetchRateLimit = false;
            }

            updateLoadingBar(false);
        }
        else {
            // Add the stories download button
            if (!$('.IG_DWHISTORY').length) {
                let $element = null;

                // Default detecter (section layout mode)
                if ($('body > div section._ac0a').length > 0) {
                    $element = $('body > div section:visible._ac0a');
                }
                else {
                    $element = $('body > div section:visible > div > div[style]:not([class])');
                    $element.css('position', 'relative');
                }

                // Detecter for div layout mode
                if ($element.length === 0) {
                    let $$element = $('body > div div:not([hidden]) section:visible > div div[class][style] > div[style]:not([class])');
                    let nowSize = 0;

                    $$element.each(function () {
                        // OPTIMIZATION: cache $(this) — was wrapped 3 times per iteration
                        const $this = $(this);
                        const width = $this.width();
                        if (width > nowSize) {
                            nowSize = width;
                            $element = $this.children('div').first();
                        }
                    });
                }


                if ($element != null) {
                    //$element.css('position','relative');
                    $element.append(`<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_DWHISTORY">${SVG.DOWNLOAD}</div>`);
                    $element.append(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="IG_DWHINEWTAB">${SVG.NEW_TAB}</div>`);

                    let $header = getStoryProgress(username);
                    if ($header.length > 1) {
                        $element.append(`<div data-ih-locale-title="DW_ALL" title="${_i18n("DW_ALL")}" class="IG_DWHISTORY_ALL">${SVG.DOWNLOAD_ALL}</div>`);
                    }

                    setStoryProgressIndexText($element, $header, 'IG_DWHISTORY_POSITION');

                    // replace something times ago format to publish time in first init
                    setTimeElementDateAndLocaleTime(getHighlightCurrentTimeElement($header));

                    //// Modify video volume
                    //if(USER_SETTING.MODIFY_VIDEO_VOLUME){
                    //    $element.find('video').each(function(){
                    //        $(this).on('play playing', function(){
                    //            if(!$(this).data('modify')){
                    //                $(this).data('modify', true);
                    //                this.volume = VIDEO_VOLUME;
                    //                logger('(highlight) Added video event listener #modify');
                    //            }
                    //        });
                    //    });
                    //}

                    // Make sure to first remove thumbnail button if still exists and highlight is a picture
                    $element.find('img[referrerpolicy]').each(function () {
                        $(this).on('load', function () {
                            // OPTIMIZATION: cache $(this) (called 4 times in this handler)
                            const $img = $(this);
                            if (!$img.data('remove-thumbnail')) {
                                if ($element.find('.IG_DWHISTORY_THUMBNAIL').length === 0) {
                                    $img.data('remove-thumbnail', true);
                                    $('.IG_DWHISTORY_THUMBNAIL').remove();
                                    logger('(highlight) Manually removing thumbnail button');
                                }
                                else {
                                    $img.data('remove-thumbnail', true);
                                    logger('(highlight) Thumbnail button is not present for this picture');
                                }
                            }
                        });
                    });

                    // Try to use event listener 'timeupdate' in order to detect if highlight is a video
                    //$element.find('video').each(function(){
                    //    $(this).on('timeupdate',function(){
                    //        if(!$(this).data('modify-thumbnail')){
                    //            if($element.find('.IG_DWHISTORY_THUMBNAIL').length === 0){
                    //                $(this).data('modify-thumbnail', true);
                    //                onHighlightsStoryThumbnail(false);
                    //                logger('(highlight) Manually inserting thumbnail button');
                    //            }
                    //            else{
                    //                $(this).data('modify-thumbnail', true);
                    //                logger('(highlight) Thumbnail button already inserted');
                    //            }
                    //        }
                    //    });
                    //});
                }
            }
        }
    }

    /**
     * onHighlightsStoryThumbnail
     * @description Trigger user's highlight video thumbnail download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @return {void}
     */
    async function onHighlightsStoryThumbnail(isDownload) {
        if (isDownload) {
            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);
            let highlightId = location.href.replace(/\/$/ig, '').split('/').at(-1);
            let username = "";
            let nowIndex = $("body > div section._ac0a header._ac0k > ._ac3r ._ac3n ._ac3p[style]").length ||
                $('body > div section:visible > div > div:not([class]) > div > div div.x1ned7t2.x78zum5 div.x1caxmr6').length ||
                $('body > div div:not([hidden]) section:visible > div div[style]:not([class]) > div').find('div div.x1ned7t2.x78zum5 div.x1caxmr6').length;
            let target = "";

            updateLoadingBar(true);

            if (state.GL_dataCache.highlights[highlightId]) {
                logger('Fetch from memory cache:', highlightId);

                const items = state.GL_dataCache.highlights[highlightId].data.reels_media[0].items;
                let totIndex = items.length;
                username = state.GL_dataCache.highlights[highlightId].data.reels_media[0].owner.username;
                target = items[totIndex - nowIndex];
            }
            else {
                let highStories = await getHighlightStories(highlightId);
                const items = highStories.data.reels_media[0].items;
                let totIndex = items.length;
                username = highStories.data.reels_media[0].owner.username;
                target = items[totIndex - nowIndex];

                state.GL_dataCache.highlights[highlightId] = highStories;
            }

            if (USER_SETTING.RENAME_PUBLISH_DATE) {
                timestamp = target.taken_at_timestamp;
            }

            if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                const cached = getImageFromCache(target.id);
                if (cached) {
                    logger("[Restore Cached onHighlightsStoryThumbnail]", target.id);
                    saveFiles(cached, {
                        username,
                        sourceType: "highlights",
                        timestamp,
                        filetype: 'jpg',
                        shortcode: target.id
                    });
                    return;
                }
            }

            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && !state.tempFetchRateLimit) {
                let result = await getMediaInfo(target.id);

                if (result.status === 'ok') {
                    saveFiles(result.items[0].image_versions2.candidates[0].url, {
                        username,
                        sourceType: "highlights",
                        timestamp,
                        filetype: 'jpg',
                        shortcode: highlightId
                    });
                }
                else {
                    if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED) {
                        delete state.GL_dataCache.highlights[highlightId];
                        state.tempFetchRateLimit = true;

                        onHighlightsStoryThumbnail(true);
                    }
                    else {
                        alert('Fetch failed from Media API. API response message: ' + result.message);
                    }

                    logger(result);
                }
            }
            else {
                saveFiles(target.display_resources.at(-1).src, {
                    username,
                    sourceType: "highlights",
                    timestamp,
                    filetype: 'jpg',
                    shortcode: highlightId
                });
                state.tempFetchRateLimit = false;
            }

            updateLoadingBar(false);
        }
        else {
            setStoryProgressIndexByUsername($('.IG_DWHISTORY').parent(), getHighlightsStoryUsername(), 'IG_DWHISTORY_POSITION');

            if ($('body > div section video.xh8yej3').length) {
                // Add the stories thumbnail download button
                if (!$('.IG_DWHISTORY_THUMBNAIL').length) {
                    let $element = null;

                    // Default detecter (section layout mode)
                    if ($('body > div section._ac0a').length > 0) {
                        $element = $('body > div section:visible._ac0a');
                    }
                    else {
                        $element = $('body > div section:visible > div > div[style]:not([class])');
                        $element.css('position', 'relative');
                    }

                    // Detecter for div layout mode
                    if ($element.length === 0) {
                        let $$element = $('body > div div:not([hidden]) section:visible > div div[class][style] > div[style]:not([class])');
                        let nowSize = 0;

                        $$element.each(function () {
                            const $this = $(this);
                            const width = $this.width();
                            if (width > nowSize) {
                                nowSize = width;
                                $element = $this.children('div').first();
                            }
                        });
                    }

                    if ($element != null) {
                        $element.append(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="IG_DWHISTORY_THUMBNAIL">${SVG.THUMBNAIL}</div>`);
                    }
                }
            }
            else {
                $('.IG_DWHISTORY_THUMBNAIL').remove();
            }
        }
    }

    /**
     * onReadyMyDW
     * @description Create an event entry point for the download button for the post.
     *
     * @param  {Boolean}  NoDialog    - Check if it not showing the dialog
     * @param  {?Boolean}  hasReferrer - Check if the source of the previous page is a story page
     * @return {void}
     */
    function onReadyMyDW(NoDialog, hasReferrer) {
        if (hasReferrer === true) {
            logger('hasReferrer', 'regenerated');
            $('article[data-snig="canDownload"], div[data-snig="canDownload"]').filter(function () {
                return $(this).find('.IG_DW_MAIN').length === 0
            }).removeAttr('data-snig');
        }

        clearInterval(state.GL_repeat);
        state.GL_repeat = null;

        // Whether is Instagram dialog?
        if (NoDialog == false) {
            const maxCall = 100;
            let i = 0;
            state.GL_repeat = setInterval(() => {
                // section:visible > main > div > div[data-snig="canDownload"] > div > div > div > hr << (single foreground post in page, non-floating // <hr> element here is literally the line beneath poster's username) >>
                // section:visible > main > div > div.xdt5ytf[data-snig="canDownload"] << (former CSS selector for single foreground post in page, non-floating) >>
                // <hr> is much more unique element than "div.xdt5ytf"
                if (i > maxCall || $(`article[data-snig="canDownload"],
                    section:visible > main > div > div[data-snig="canDownload"] > div > div > div > hr,
                    div[id^="mount"] div div div.x1n2onr6.x1vjfegm div[data-snig="canDownload"]
                `).length > 0) {
                    clearInterval(state.GL_repeat);
                    state.GL_repeat = null;

                    if (i > maxCall) {
                        //alert('Trying to call button creation method reached to maximum try times. If you want to re-register method, please open script menu and press "Reload Script" button or hotkey "R" to reload main timer.');
                        console.warn('onReadyMyDW() Timer', 'maximum number of repetitions reached, terminated');
                    }
                }

                logger('onReadyMyDW() Timer', 'repeating to call detection createDownloadButton()');
                createDownloadButton();
                i++;
            }, 50);
        }
        else {
            createDownloadButton();
        }
    }


    /**
     * initPostVideoFunction
     * @description Initialize settings related to the video resources in the post.
     *
     * @param  {JQuery<HTMLElement>}  $mainElement
     * @return {Void}
     */
    function initPostVideoFunction($mainElement) {
        // OPTIMIZATION: cache $videos — used in 3-4 separate .find('video') traversals below
        const $videos = $mainElement.find('video');

        $videos.each(function () {
            $(this).off('fullscreenchange.IG_videoControl').on('fullscreenchange.IG_videoControl', function () {
                const $vid = $(this);
                if ($vid.attr('style').includes('object-fit')) {
                    if (document.fullscreenElement == this) {
                        $vid.css('object-fit', 'contain');
                    }
                    else {
                        $vid.css('object-fit', 'cover');
                    }
                }
            });
        });

        // Disable video autoplay
        if (USER_SETTING.DISABLE_VIDEO_LOOPING) {
            $videos.each(function () {
                $(this).on('ended', function () {
                    const $vid = $(this);
                    if (!$vid.data('loop')) {
                        $vid.data('loop', true);
                        this.pause();
                        logger('(post) Added video event listener #loop');
                    }
                });
            });
        }

        // Modify video volume
        if (USER_SETTING.MODIFY_VIDEO_VOLUME) {
            $videos.each(function () {
                $(this).on('play playing', function () {
                    const $vid = $(this);
                    if (!$vid.data('modify')) {
                        $vid.data('modify', true);
                        this.volume = state.videoVolume;
                        logger('(post) Added video event listener #modify');
                    }
                });
            });
        }

        if (USER_SETTING.HTML5_VIDEO_CONTROL) {
            const handleSwitchController = function (e) {
                e.preventDefault();
                e.stopPropagation();

                let $overlayElement = null;

                if ($overlayElement == null) {
                    $overlayElement = $(e.target).parents('div[aria-label][data-visualcompletion="ignore"]').first();
                }

                $videos.each(function () {
                    $(this).css('z-index', '2');
                    $(this).attr('controls', true);
                    state.GL_weakCache.overlay.set(this, $overlayElement);
                });

                $overlayElement.css('z-index', '-10');
                $mainElement.find('a[href^="/reels/"]').first().attr("draggable", false);
            };

            $mainElement.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', handleSwitchController);

            $videos.each(function () {
                const $video = $(this);
                if (!$video.data('controls')) {

                    logger('(post) Added video html5 contorller #modify');

                    if (USER_SETTING.MODIFY_VIDEO_VOLUME) {
                        this.volume = state.videoVolume;

                        $video.on('loadstart', function () {
                            this.volume = state.videoVolume;
                        });
                    }


                    let $mute_button_wrapper = $video.parent().find('video + div > div');
                    $mute_button_wrapper = $mute_button_wrapper.add($mainElement);

                    // eslint-disable-next-line no-unused-vars
                    let $element_mute_button = $mute_button_wrapper.find('button[type="button"], div[role="button"]').filter(function (idx) {
                        const $b = $(this);
                        // This is mute/unmute's icon
                        return $b.width() <= 64 && $b.height() <= 64 && $b.find('svg > path[d^="M16.636 7.028a1.5"], svg > path[d^="M1.5 13.3c-.8"]').length > 0;
                    });

                    state.GL_weakCache.mutedButton.set(this, $element_mute_button);

                    let $targets = $video.parent().find('video + div > div').first();

                    // Hide layout to show controller
                    $targets.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', handleSwitchController);

                    // Restore layout to show details interface
                    $video.on('contextmenu', function (e) {
                        e.preventDefault();
                        e.stopPropagation();

                        $video.css('z-index', '-1');
                        $video.removeAttr('controls');

                        $targets.css('z-index', '1');
                        state.GL_weakCache.overlay.get(this)?.css('z-index', '1');
                        $(this).parents('a[href^="/reels/"]').first().removeAttr("draggable");
                    });

                    $video.on('volumechange', function () {
                        let video = this;
                        let $element_mute_button = state.GL_weakCache.mutedButton.get(this) || {};
                        let is_element_muted = $element_mute_button.find && $element_mute_button.find('svg > path[d^="M16.636"]').length === 0;

                        if (this.muted != is_element_muted) {
                            this.volume = state.videoVolume;

                            if ($element_mute_button.length === 1) {
                                triggerReactClickHandler($element_mute_button.first()[0]);
                            }
                            else {
                                let $firstElementMuteButton = $element_mute_button.filter(function () {
                                    return $(this).closest(state.GL_weakCache.overlay.get(video)).length > 0;
                                }).first();

                                triggerReactClickHandler($firstElementMuteButton.first()[0]);
                            }
                        }

                        const $v = $(this);
                        if ($v.data('completed')) {
                            state.videoVolume = this.volume;
                            GM_setValue('G_VIDEO_VOLUME', this.volume);
                        }

                        if (this.volume == state.videoVolume) {
                            $v.data('completed', true);
                        }
                    });

                    $video.parents('a[href^="/reels/"]').first().on('click', function (e) {
                        if ($video.attr('controls')) {
                            e.preventDefault();
                            e.stopPropagation();
                        }
                    });

                    $video.css('position', 'absolute');
                    $video.data('controls', true);
                }
            });
        }

        var $buttonParent = $mainElement.find('video + div > div').first();
        toggleVolumeSilder($videos, $buttonParent, 'post', 'bottom');
    };


    /**
     * createDownloadButton
     * @description Create a download button in the upper right corner of each post.
     *
     * @return {void}
     */
    function createDownloadButton() {
        // Add download icon per each posts
        // eslint-disable-next-line no-unused-vars
        $('article, section:visible > main > div > div > div > div > div > hr').map(function (index) {
            return $(this).is('section:visible > main > div > div > div > div > div > hr') ? $(this).parent().parent().parent().parent()[0] : this;
        }).filter(function () {
            const $this = $(this);
            return $this.height() > 0 && $this.width() > 0
        })
            .each(function (index) {
                // OPTIMIZATION: cache $(this) — referenced 8+ times in this each() body
                const $self = $(this);
                // If it is have not download icon
                // class x1iyjqo2 mean user profile pages post list container
                if (!$self.attr('data-snig') && !$self.hasClass('x1iyjqo2') && !$self.children('article')?.hasClass('x1iyjqo2') && $self.parents('div#scrollview').length === 0) {
                    logger("Found post container", $self);

                    const $mainElement = $self;
                    const tagName = this.tagName;

                    // not loop each in single top post
                    if (tagName === "DIV" && index != 0) {
                        return;
                    }

                    const $childElement = $mainElement.children("div").children("div");

                    if ($mainElement.find('> .button_wrapper, .button_wrapper').length > 0) {
                        $mainElement.attr('data-snig', 'canDownload');
                        return;
                    }

                    if ($childElement.length === 0) return;

                    logger("Found insert point", $childElement);

                    // Modify carousel post counter's position to not interfere with our buttons
                    // OPTIMIZATION: cache repeated ._acay lookup
                    const $acay = $mainElement.find('._acay');
                    if ($acay.length > 0) {
                        const $acayX24 = $mainElement.find('._acay + .x24i39r');
                        if ($acayX24.length > 0) {
                            $acayX24.css('top', '37px');
                        }

                        const observeNode = $acay.first().parent()[0];
                        var observer = new MutationObserver(function () {
                            $mainElement.find('._acay + .x24i39r').css('top', '37px');
                        });

                        observer.observe(observeNode, {
                            childList: true
                        });
                    }

                    $childElement.eq((tagName === "DIV") ? 0 : $childElement.length - 2).append(`<div class="button_wrapper">`);

                    // Add icons
                    const DownloadElement = `<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_DW_MAIN">${SVG.DOWNLOAD}</div>`;
                    const NewTabElement = `<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="IG_NEWTAB_MAIN">${SVG.NEW_TAB}</div>`;
                    const ThumbnailElement = `<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="IG_THUMBNAIL_MAIN">${SVG.THUMBNAIL}</div>`;
                    const ViewerElement = `<div data-ih-locale-title="IMAGE_VIEWER" title="${_i18n("IMAGE_VIEWER")}" class="IG_IMAGE_VIEWER">${SVG.FULLSCREEN}</div>`;

                    // OPTIMIZATION: cache .button_wrapper inside $childElement (used 5+ times)
                    const $buttonWrapper = $childElement.find(".button_wrapper");
                    $buttonWrapper.append(DownloadElement);

                    const resource_count = $mainElement.find(resourceCountSelector).length;

                    if (resource_count > 1 && USER_SETTING.DIRECT_DOWNLOAD_VISIBLE_RESOURCE && !USER_SETTING.DIRECT_DOWNLOAD_ALL) {
                        const DownloadAllElement = `<div data-ih-locale-title="DW_ALL" title="${_i18n("DW_ALL")}" class="IG_DW_ALL_MAIN">${SVG.DOWNLOAD_ALL}</div>`;
                        $buttonWrapper.append(DownloadAllElement);
                    }

                    $buttonWrapper.append(NewTabElement);

                    let $resourceLayout = $childElement.filter(function () {
                        const $this = $(this);
                        return $this.width() > 100 && $this.height() > 100;
                    }).first();

                    let $isNewPostStyleLayout = $resourceLayout.find(`a[role="link"][tabindex="0"][href^="/"]`).filter(function () {
                        const href = $(this).attr('href');
                        return !href.startsWith("/p/") && !href.startsWith("/reels/");
                    }).length > 0;

                    // Make sure the button wrapper doesn't cover the "More Options" button.
                    if ($isNewPostStyleLayout) {
                        $buttonWrapper.css('top', '45px');
                    }

                    setTimeout(() => {
                        // eslint-disable-next-line no-unused-vars
                        const checkNodeCallback = (entries, observer) => {
                            entries.forEach((entry) => {
                                if (entry.isIntersecting) {
                                    var $targetNode = $(entry.target);
                                    // OPTIMIZATION: combined remove selector instead of 2 separate
                                    $childElement.find('.IG_THUMBNAIL_MAIN, .IG_IMAGE_VIEWER').remove();

                                    // Check if video?
                                    if ($targetNode.find('video').length > 0) {
                                        // FIX: clear any stale image URL when the visible item is a video
                                        $mainElement.removeData('igHelper_displayResourceURL');

                                        if ($childElement.find('.IG_THUMBNAIL_MAIN').length === 0) {
                                            $childElement.find(".button_wrapper").append(ThumbnailElement);
                                        }

                                        initPostVideoFunction($mainElement);
                                    }
                                    // is Image
                                    else {
                                        const imgSrc = $targetNode.find('img').attr('src');
                                        $mainElement.data('igHelper_displayResourceURL', imgSrc);

                                        $childElement.find(".button_wrapper").append(ViewerElement);
                                    }
                                }
                            });
                        };

                        const observer_i = new IntersectionObserver(checkNodeCallback, {
                            root: $childElement.find('.button_wrapper').parent()[0],
                            rootMargin: "0px",
                            threshold: 0.1,
                        });

                        // trigger when switching resources
                        // eslint-disable-next-line no-unused-vars
                        const observer = new MutationObserver(function (mutation, owner) {
                            var target = mutation.at(0)?.target;
                            observer_i.disconnect();

                            $(target).find('li').each(function () {
                                const $t = $(target);
                                if ($t.find('video').length > 0 || $t.find('img').length > 0) {
                                    observer_i.observe(this);
                                }
                            });
                        });

                        let $triggeredTarget = null;
                        // first onload
                        $childElement.find('.button_wrapper').parent().find('ul li, div[role="button"] > div, div[class] > div').each(function () {
                            const $li = $(this);
                            const $targetNode = $li.find('video').length > 0
                                ? $li.find('video')?.first()
                                : $li.find('img')?.first();

                            // Check if the node is visible and has size, 
                            // and not the same node as last triggered one to avoid duplicated trigger 
                            // when switching resources with same container
                            if (
                                $targetNode.length > 0 &&
                                $targetNode.is(':visible') &&
                                $targetNode.get(0).getBoundingClientRect().width > 0 &&
                                $targetNode.get(0).getBoundingClientRect().height > 0 &&
                                this.getBoundingClientRect().width > 64 &&
                                this.getBoundingClientRect().height > 64 &&
                                $triggeredTarget?.get(0) != $targetNode?.get(0)
                            ) {
                                // ignore the image without alt attribute, 
                                // because it is usually used for video thumbnail
                                if (
                                    $targetNode.get(0).tagName === "IMG" &&
                                    $targetNode.attr('alt')?.length == 0
                                ) {
                                        return;
                                }

                                $triggeredTarget = $targetNode;
                                observer_i.observe(this);
                            }
                        });

                        const $bwParent = $childElement.find('.button_wrapper').parent();
                        const listRoot =
                            $bwParent.find('ul li, div[role="button"] > div').first().parent()[0] ||
                            $bwParent.find('ul').first()[0];

                        if (listRoot) {
                            observer.observe(listRoot, {
                                attributes: true,
                                childList: true,
                            });
                        } else {
                            initPostVideoFunction($mainElement);
                            logger("Cannot find resource list root element, thumbnail and viewer button may not work.");
                        }

                    }, 50);

                    $childElement.css('position', 'relative');

                    // Add the mark that download is ready
                    var username = $self.find("header > div:last-child > div:first-child span a").first().text() || $self.find('a[href^="/"]').filter(function () {
                        return $(this)?.text()?.length > 0;
                    }).first().text();

                    $self.attr('data-snig', 'canDownload');
                    $self.data('username', username);
                }
            });
    }


    /**
     * registerPostClickHandlers
     * @description Registers delegated body-level handlers for post download/view actions.
     *
     * FIX: Registers all post-button click handlers exactly once on $('body') using
     * the event namespace ".igHelperPost". Body-level delegation means jQuery stores
     * only a single handler object per event type (not one per article), and the
     * handlers themselves never hold strong references to article DOM nodes —
     * they resolve the relevant article at click-time via $(this).closest().
     *
     * Cleanup is a single $('body').off('.igHelperPost') call in reloadScript().
     */
    function registerPostClickHandlers() {
        if (state.bodyEventsRegistered) return;
        state.bodyEventsRegistered = true;

        // OPTIMIZATION: All body-level delegated handlers now use cached $body reference
        $body.on('click.igHelperPost', '.IG_IMAGE_VIEWER', function () {
            const { $article } = getPostContextFromButton(this);
            let url = $article.data('igHelper_displayResourceURL');

            if (!url) {
                url = $article.find('img:visible').filter(function () {
                    const $img = $(this);
                    return (($img.attr('alt') || '').length > 0) && (($img.attr('src') || '').length > 0);
                }).first().attr('src');
            }

            if (url) {
                openImageViewer(url);
            } else {
                alert("Cannot find resource url.");
            }
        });

        $body.on('click.igHelperPost', '.IG_THUMBNAIL_MAIN', async function () {
            updateLoadingBar(true);

            try {
                const { $article, postPath } = getPostContextFromButton(this);
                if ($article.length === 0 || !postPath) {
                    alert('Cannot determine post path.');
                    return;
                }

                state.GL_username = $article.data('username');
                state.GL_postPath = postPath;
                const index = getVisibleNodeIndex($article);

                IG_createDM(true, false);

                const totalInserted = await createMediaListDOM(
                    state.GL_postPath,
                    ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                    ""
                );

                if (!totalInserted || totalInserted < 1) {
                    alert('Cannot find thumbnail URL.');
                    return;
                }

                const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY');
                const $videoThumbnail = $popupBody
                    .find('a[data-globalindex="' + (index + 1) + '"]')
                    .parent()
                    .find('.videoThumbnail')
                    .first();

                if ($videoThumbnail.length > 0) {
                    $videoThumbnail.trigger("click");
                }
                else {
                    alert('Cannot find thumbnail URL.');
                }
            }
            catch (err) {
                logger('registerPostClickHandlers .IG_THUMBNAIL_MAIN', err);
                alert('Cannot find thumbnail URL.');
            }
            finally {
                updateLoadingBar(false);
                $('.IG_POPUP_DIG').remove();
            }
        });

        $body.on('click.igHelperPost', '.IG_NEWTAB_MAIN', async function () {
            updateLoadingBar(true);

            try {
                const { $article, postPath } = getPostContextFromButton(this);
                if ($article.length === 0 || !postPath) {
                    alert('Cannot determine post path.');
                    return;
                }

                state.GL_username = $article.data('username');
                state.GL_postPath = postPath;
                const index = getVisibleNodeIndex($article);

                IG_createDM(true, false);

                const totalInserted = await createMediaListDOM(
                    state.GL_postPath,
                    ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                    ""
                );

                if (!totalInserted || totalInserted < 1) {
                    alert('Cannot find open tab URL.');
                    return;
                }

                const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY');
                const $linkElement = $popupBody.find('a[data-globalindex="' + (index + 1) + '"]');

                if ($linkElement.length === 0) {
                    alert('Cannot find open tab URL.');
                    return;
                }

                if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && USER_SETTING.NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST) {
                    triggerLinkElement($linkElement.first()[0], true);
                }
                else {
                    const href = $linkElement.data('href');
                    if (href) {
                        openNewTab(replaceSameOriginHost(href));
                    }
                    else {
                        alert('Cannot find open tab URL.');
                    }
                }
            }
            catch (err) {
                logger('registerPostClickHandlers .IG_NEWTAB_MAIN', err);
                alert('Cannot find open tab URL.');
            }
            finally {
                updateLoadingBar(false);
                $('.IG_POPUP_DIG').remove();
            }
        });

        $body.on('click.igHelperPost', '.IG_DW_ALL_MAIN', async function () {
            try {
                const { $article, postPath } = getPostContextFromButton(this);
                if ($article.length === 0 || !postPath) {
                    alert('Cannot determine post path.');
                    return;
                }

                state.GL_username = $article.data('username');
                state.GL_postPath = postPath;

                IG_createDM(USER_SETTING.DIRECT_DOWNLOAD_ALL, true);
                $("#article-id").html(`<a href="https://www.instagram.com/p/${state.GL_postPath}">${state.GL_postPath}</a>`);

                const totalInserted = await createMediaListDOM(
                    state.GL_postPath,
                    ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                    _i18n("LOAD_BLOB_MULTIPLE")
                );

                if (!totalInserted || totalInserted < 1) {
                    $('.IG_POPUP_DIG').remove();
                    return;
                }

                const links = [];
                $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY a').each(function () {
                    links.push($(this));
                });

                await batchDownloadPostFiles(links);
            }
            catch (err) {
                logger('registerPostClickHandlers .IG_DW_ALL_MAIN', err);
            }
            finally {
                $('.IG_POPUP_DIG').remove();
            }
        });

        $body.on('click.igHelperPost', '.IG_DW_MAIN', async function () {
            try {
                const { $article, postPath } = getPostContextFromButton(this);
                if ($article.length === 0 || !postPath) {
                    alert('Cannot determine post path.');
                    return;
                }

                state.GL_username = $article.data('username');
                state.GL_postPath = postPath;

                IG_createDM(USER_SETTING.DIRECT_DOWNLOAD_ALL, true);
                $("#article-id").html(`<a href="https://www.instagram.com/p/${state.GL_postPath}">${state.GL_postPath}</a>`);

                if (USER_SETTING.DIRECT_DOWNLOAD_VISIBLE_RESOURCE) {
                    updateLoadingBar(true);
                    IG_setDM(true);

                    try {
                        const index = getVisibleNodeIndex($article);

                        const totalInserted = await createMediaListDOM(
                            state.GL_postPath,
                            ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                            ""
                        );

                        if (!totalInserted || totalInserted < 1) {
                            alert('Cannot find download URL.');
                            return;
                        }

                        const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY');
                        const $targetLink = $popupBody.find('a[data-globalindex="' + (index + 1) + '"]');
                        const href = $targetLink.data('href');

                        if ($targetLink.length > 0 && href) {
                            $targetLink.trigger("click");
                        }
                        else {
                            alert('Cannot find download URL.');
                        }
                    }
                    catch (err) {
                        logger('registerPostClickHandlers .IG_DW_MAIN visibleResource', err);
                        alert('Cannot find download URL.');
                    }
                    finally {
                        updateLoadingBar(false);
                        $('.IG_POPUP_DIG').remove();
                    }

                    return;
                }

                if (!USER_SETTING.DIRECT_DOWNLOAD_ALL) {
                    let s = 0;
                    const $resourceItems = $article.find(resourceCountSelector);
                    let multiple = $resourceItems.length;
                    let blob = USER_SETTING.FORCE_FETCH_ALL_RESOURCES;
                    const publish_time = new Date(
                        $article.find('a[href] time[datetime]').filter(function () {
                            let href = $(this).parents("a[href]").attr("href");
                            return href?.startsWith("/p/") || href?.match(/\/([\w.\-_]+)\/(p|reel)\//ig) != null;
                        }).first().attr('datetime')
                    ).getTime();

                    if (multiple) {
                        $resourceItems.each(function () {
                            let element_videos = $(this).parent().parent().parent().find('video');
                            if (element_videos && element_videos.attr('src')) {
                                blob = true;
                            }
                        });

                        if (blob || USER_SETTING.FORCE_RESOURCE_VIA_MEDIA) {
                            await createMediaListDOM(
                                state.GL_postPath,
                                ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                                _i18n("LOAD_BLOB_MULTIPLE")
                            );
                        }
                        else {
                            const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY');
                            $resourceItems.each(function () {
                                s++;
                                const $this = $(this);
                                let element_videos = $this.find('video');
                                let element_images = $this.find('._aagv img');
                                let imgLink = (element_images.attr('srcset')) ? element_images.attr('srcset').split(" ")[0] : element_images.attr('src');

                                if (element_videos && element_videos.attr('src')) {
                                    blob = true;
                                }
                                if (element_images && imgLink) {
                                    $popupBody.append(`<a datetime="${publish_time}" data-needed="direct" data-path="${state.GL_postPath}" data-name="photo" data-type="jpg" data-globalIndex="${s}" href="javascript:;" data-href="${imgLink}"><img width="100" src="${imgLink}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${s} -</a>`);
                                }
                            });

                            if (blob) {
                                await createMediaListDOM(
                                    state.GL_postPath,
                                    ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                                    _i18n("LOAD_BLOB_RELOAD")
                                );
                            }
                        }
                    }
                    else {
                        if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA) {
                            await createMediaListDOM(
                                state.GL_postPath,
                                ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                                _i18n("LOAD_BLOB_MULTIPLE")
                            );
                        }
                        else {
                            s++;
                            let element_videos = $article.find('video');
                            let element_images = $article.find('._aagv img');
                            let imgLink = (element_images.attr('srcset')) ? element_images.attr('srcset').split(" ")[0] : element_images.attr('src');

                            if (element_videos && element_videos.attr('src')) {
                                await createMediaListDOM(
                                    state.GL_postPath,
                                    ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                                    _i18n("LOAD_BLOB_ONE")
                                );
                            }
                            if (element_images && imgLink) {
                                $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY').append(`<a datetime="${publish_time}" data-needed="direct" data-path="${state.GL_postPath}" data-name="photo" data-type="jpg" data-globalIndex="${s}" href="javascript:;" href="" data-href="${imgLink}"><img width="100" src="${imgLink}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${s} -</a>`);
                            }
                        }
                    }
                }

                $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY a').each(function () {
                    const $a = $(this);
                    if ($a.parent().is('div') && $a.prev('.inner_box_wrapper').length > 0) {
                        return;
                    }

                    $a.wrap('<div></div>');
                    $a.before('<label class="inner_box_wrapper"><input class="inner_box" type="checkbox"><span></span></label>');
                    $a.after(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="newTab">${SVG.NEW_TAB}</div>`);

                    if ($a.data('name') == 'video') {
                        $a.after(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="videoThumbnail">${SVG.THUMBNAIL}</div>`);
                    }
                });

                if (USER_SETTING.DIRECT_DOWNLOAD_ALL) {
                    const totalInserted = await createMediaListDOM(
                        state.GL_postPath,
                        ".IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY",
                        _i18n("LOAD_BLOB_MULTIPLE")
                    );

                    if (!totalInserted || totalInserted < 1) {
                        $('.IG_POPUP_DIG').remove();
                        return;
                    }

                    const links = [];
                    $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY a').each(function () {
                        links.push($(this));
                    });

                    await batchDownloadPostFiles(links);
                    $('.IG_POPUP_DIG').remove();
                }
            }
            catch (err) {
                logger('registerPostClickHandlers .IG_DW_MAIN', err);
                $('.IG_POPUP_DIG').remove();
            }
        });
    }


    /**
     * filterResourceData
     * @description Standardized resource object format.
     *
     * @param  {Object}  data
     * @return {Object}
     */
    function filterResourceData(data) {
        var resource = data.shortcode_media ?? data;
        if (resource.owner == null && resource.user != null) {
            resource.owner = resource.user;
        }

        if (resource.owner == null) {
            logger('carousel_media:', 'undefined username');
            alert('carousel_media: undefined username');
        }

        return resource;
    }


    /**
     * createMediaListDOM
     * @description Create a list of media elements from post URLs.
     *
     * @param  {String}  postURL
     * @param  {String}  selector - Use CSS element selectors to choose where it appears.
     * @param  {String}  message - i18n display loading message
     * @return {Promise<number>}  The number of <a> elements inserted into the DOM
     */
    async function createMediaListDOM(postURL, selector, message) {
        try {
            // OPTIMIZATION: cache the popup body selection used many times below
            const $target = $(selector);
            $target.find('a').remove();
            $target.append('<p id="_SNLOAD">' + message + '</p>');
            $('.IG_POPUP_DIG #batch_download_selected, .IG_POPUP_DIG #batch_download_direct').prop('disabled', true);
            let result = await getBlobMedia(postURL);
            let resource = filterResourceData(result.data);

            if (result.type === 'query_hash') {
                let idx = 1;

                // GraphVideo
                if (resource.__typename == "GraphVideo" && resource.video_url) {
                    $target.append(`<a media-id="${resource.id}" datetime="${resource.taken_at_timestamp}" data-blob="true" data-needed="direct" data-path="${resource.shortcode}" data-name="video" data-type="mp4" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${resource.video_url}"><img width="100" src="${resource.display_resources[1].src}" /><br/>- <span data-ih-locale="VID">${_i18n("VID")}</span> ${idx} -</a>`);
                    idx++;

                    if (resource.video_dash_manifest) {
                        state.GL_mediaDataCache[resource.id] = resource;
                    }
                }
                // GraphImage
                if (resource.__typename == "GraphImage") {
                    $target.append(`<a media-id="${resource.id}" datetime="${resource.taken_at_timestamp}" data-blob="true" data-needed="direct" data-path="${resource.shortcode}" data-name="photo" data-type="jpg" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${resource.display_resources[resource.display_resources.length - 1].src}"><img width="100" src="${resource.display_resources[1].src}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${idx} -</a>`);
                    idx++;
                }
                // GraphSidecar
                if (resource.__typename == "GraphSidecar" && resource.edge_sidecar_to_children) {
                    for (let e of resource.edge_sidecar_to_children.edges) {
                        if (e.node.__typename == "GraphVideo") {
                            $target.append(`<a media-id="${e.node.id}" datetime="${resource.taken_at_timestamp}" data-blob="true" data-needed="direct" data-path="${resource.shortcode}" data-name="video" data-type="mp4" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${e.node.video_url}"><img width="100" src="${e.node.display_resources[1].src}" /><br/>- <span data-ih-locale-title="VID">${_i18n("VID")}</span> ${idx} -</a>`);
                            if (e.node.video_dash_manifest) {
                                state.GL_mediaDataCache[e.node.id] = e.node;
                            }
                        }

                        if (e.node.__typename == "GraphImage") {
                            $target.append(`<a media-id="${e.node.id}" datetime="${resource.taken_at_timestamp}" data-blob="true" data-needed="direct" data-path="${resource.shortcode}" data-name="photo" data-type="jpg" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${e.node.display_resources[e.node.display_resources.length - 1].src}"><img width="100" src="${e.node.display_resources[1].src}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${idx} -</a>`);
                        }
                        idx++;
                    }
                }
            }
            else {
                if (resource.carousel_media) {
                    logger('carousel_media');

                    resource.carousel_media.forEach((mda, ind) => {
                        let idx = ind + 1;
                        // Image
                        if (mda.video_versions == null) {
                            mda.image_versions2.candidates.sort(function (a, b) {
                                let aSTP = new URL(a.url).searchParams.get('stp');
                                let bSTP = new URL(b.url).searchParams.get('stp');

                                if (aSTP && bSTP) {
                                    if (aSTP.length > bSTP.length) return 1;
                                    if (aSTP.length < bSTP.length) return -1;
                                }
                                else {
                                    if (a.width < b.width) return 1;
                                    if (a.width > b.width) return -1;
                                }

                                return 0;
                            });

                            $target.append(`<a media-id="${mda.pk}" datetime="${mda.taken_at}" data-blob="true" data-needed="direct" data-path="${resource.code}" data-name="photo" data-type="jpg" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${mda.image_versions2.candidates[0].url}"><img width="100" src="${mda.image_versions2.candidates[0].url}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${idx} -</a>`);
                        }
                        // Video
                        else {
                            $target.append(`<a media-id="${mda.pk}" datetime="${mda.taken_at}" data-blob="true" data-needed="direct" data-path="${resource.code}" data-name="video" data-type="mp4" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${mda.video_versions[0].url}"><img width="100" src="${mda.image_versions2.candidates[0].url}" /><br/>- <span data-ih-locale="VID">${_i18n("VID")}</span> ${idx} -</a>`);
                            if (mda.video_dash_manifest) {
                                state.GL_mediaDataCache[mda.pk] = mda;
                            }
                        }
                    });
                }
                else {
                    let idx = 1;
                    // Image
                    if (resource.video_versions == null) {
                        resource.image_versions2.candidates.sort(function (a, b) {
                            let aSTP = new URL(a.url).searchParams.get('stp');
                            let bSTP = new URL(b.url).searchParams.get('stp');

                            if (aSTP && bSTP) {
                                if (aSTP.length > bSTP.length) return 1;
                                if (aSTP.length < bSTP.length) return -1;
                            }
                            else {
                                if (a.width < b.width) return 1;
                                if (a.width > b.width) return -1;
                            }

                            return 0;
                        });

                        $target.append(`<a media-id="${resource.pk}" datetime="${resource.taken_at}" data-blob="true" data-needed="direct" data-path="${resource.code}" data-name="photo" data-type="jpg" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${resource.image_versions2.candidates[0].url}"><img width="100" src="${resource.image_versions2.candidates[0].url}" /><br/>- <span data-ih-locale="IMG">${_i18n("IMG")}</span> ${idx} -</a>`);
                    }
                    // Video
                    else {
                        if (resource.video_dash_manifest) {
                            state.GL_mediaDataCache[resource.pk] = resource;
                        }
                        $target.append(`<a media-id="${resource.pk}" datetime="${resource.taken_at}" data-blob="true" data-needed="direct" data-path="${resource.code}" data-name="video" data-type="mp4" data-username="${resource.owner.username}" data-globalIndex="${idx}" href="javascript:;" data-href="${resource.video_versions[0].url}"><img width="100" src="${resource.image_versions2.candidates[0].url}" /><br/>- <span data-ih-locale="VID">${_i18n("VID")}</span> ${idx} -</a>`);
                    }
                }
            }

            $("#_SNLOAD").remove();
            $('.IG_POPUP_DIG #batch_download_selected, .IG_POPUP_DIG #batch_download_direct').prop('disabled', false);
            $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY a').each(function () {
                const $a = $(this);
                $a.wrap('<div></div>');
                $a.before('<label class="inner_box_wrapper"><input class="inner_box" type="checkbox"><span></span></label>');
                $a.after(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="newTab">${SVG.NEW_TAB}</div>`);

                if ($a.data('name') == 'video') {
                    $a.after(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="videoThumbnail">${SVG.THUMBNAIL}</div>`);
                }
            });
            updatePopupSelectionSummary();

            return $target.find('a').length;
        }
        catch (err) {
            logger('createMediaListDOM', err);
            $("#_SNLOAD").remove();
            $('.IG_POPUP_DIG #batch_download_selected, .IG_POPUP_DIG #batch_download_direct').prop('disabled', false);
            return 0;
        }
    }


    /**
     * getVisibleNodeIndex
     * @description Get element visible node.
     *
     * @param  {Object}  $main
     * @return {Integer}
     */
    function getVisibleNodeIndex($main) {
        // 1. Prioritize the most efficient rule: check if the "back" button exists.
        const hasBackButton = $main.find('button._afxv._al46._al47').length > 0;

        // 2. If the "back" button does not exist, it is determined to be the first image, and the result is returned immediately.
        if (!hasBackButton) {
            return 0;
        }
        var index = 0;

        // 3. If the code execution reaches here, it means it is not the first image, and the final geometric algorithm is enabled.

        // a. Locate the "viewport" element: it is the grandparent of ul
        // "_acay" class of <ul> has been removed by Instagram; [class] added to <ul> to get much lesser matches in page
        // The parent of the parent of ul[class] always has the attributes "role"
        // '*:not([data-pagelet])>*:not([role]):not([data-pagelet])>*>*>*[role]>*>ul[class]' is useful for avoiding the homepage stories section, account highlights section, and notes section in Messages.
        const $viewport = $main.find('*:not([data-pagelet])>*:not([role]):not([data-pagelet])>*>*>*[role]>*>ul[class]').parent().parent('[role]');

        if ($viewport.length > 0) {
            const viewportRect = $viewport.get(0).getBoundingClientRect();
            // b. Get itemWidth: directly use the width of the viewport, this method is the most generalizable
            const itemWidth = viewportRect.width;

            // Must successfully obtain the width to continue, to prevent division by zero errors
            if (itemWidth > 0) {
                // STAGE 1: Visual positioning, find the currently displayed <li> element
                // "_acaz" class of <li> has been removed by Instagram; [class] added to <li> to get much lesser matches in page
                const viewportRight = viewportRect.right;
                let closestSlideElement = null;
                let minDistance = Infinity;

                $main.find('li[class]').each(function () {
                    if (this.getBoundingClientRect().width === 0) return;

                    const slideRect = this.getBoundingClientRect();
                    const distance = Math.abs(slideRect.right - viewportRight);

                    if (distance < minDistance) {
                        minDistance = distance;
                        closestSlideElement = this;
                    }
                });

                // STAGE 2: Index calculation, use the found <li> and itemWidth to calculate the global index
                if (closestSlideElement) {
                    const style = $(closestSlideElement).attr('style');
                    if (style && style.includes('translateX')) {
                        const offsetMatch = style.match(/translateX\(([^p]+)px\)/);
                        if (offsetMatch && offsetMatch[1]) {
                            const totalOffset = parseFloat(offsetMatch[1]);
                            // c. Execute the final calculation formula
                            index = Math.round(totalOffset / itemWidth);
                        }
                    }
                }
            }
        }
        return index;
    }


    /**
     * batchDownloadPostFiles
     * @description Batch download media files in posts to prevent browser crashes.
     * @param {jQuery} $elements
     * @return {Promise<void>}
     */
    async function batchDownloadPostFiles($elements) {
        let index = 0;
        const totalLen = $elements.length;
        setDownloadProgress(0, totalLen);

        for (const element of $elements) {
            try {
                await triggerLinkElement($(element), false);
            } catch (err) {
                console.error('batchDownloadPostFiles failed:', err, element?.dataset?.href);
            }

            index++;
            setDownloadProgress(index, totalLen);
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }


    /**
     * getPostContextFromButton
     * @description Resolve the current post container and shortcode safely across
     * homepage, dialog, /p/, /reel/, and changing Instagram layouts.
     *
     * @param {HTMLElement|JQuery} target
     * @return {{ $article: JQuery<HTMLElement>, postPath: (string|null) }}
     */
    function getPostContextFromButton(target) {
        const $article = $(target).closest('[data-snig="canDownload"], article, div[data-snig]');
        if ($article.length === 0) {
            return { $article: $(), postPath: null };
        }

        const candidates = [];
        const pushHref = (href) => {
            if (typeof href === 'string' && href.trim().length > 0) {
                candidates.push(href.trim());
            }
        };

        pushHref($article.find('a[href^="/p/"]').first().attr('href'));
        pushHref($article.find('a[href^="/reel/"]').first().attr('href'));
        pushHref($article.find('a[href*="/p/"]').first().attr('href'));
        pushHref($article.find('a[href*="/reel/"]').first().attr('href'));

        $article.find('a[role="link"][href], a[href]').each(function () {
            const href = $(this).attr('href') || '';
            if (href.startsWith('/p/') || href.startsWith('/reel/') || href.match(/^\/[^/]+\/(p|reel)\//i)) {
                pushHref(href);
                return false;
            }
        });

        let postPath = null;
        for (const href of candidates) {
            const parts = href.split('/').filter(Boolean);
            const idx = parts.findIndex(p => p === 'p' || p === 'reel');
            if (idx >= 0 && parts[idx + 1]) {
                postPath = parts[idx + 1];
                break;
            }
            if ((href.startsWith('/p/') || href.startsWith('/reel/')) && parts[1]) {
                postPath = parts[1];
                break;
            }
        }

        if (!postPath) {
            const pathParts = location.pathname.replace(/\/$/, '').split('/').filter(Boolean);
            if ((pathParts[0] === 'p' || pathParts[0] === 'reel') && pathParts[1]) {
                postPath = pathParts[1];
            }
            else {
                const routeIndex = pathParts.findIndex(p => p === 'p' || p === 'reel');
                if (routeIndex >= 0 && pathParts[routeIndex + 1]) {
                    postPath = pathParts[routeIndex + 1];
                }
            }
        }

        return { $article, postPath };
    }

    /**
     * onProfileAvatar
     * @description Trigger user avatar download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @return {void}
     */
    async function onProfileAvatar(isDownload) {
        if (isDownload) {
            updateLoadingBar(true);

            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);
            let username = location.pathname.replaceAll(/(reels|tagged)\/$/ig, '').split('/').filter(s => s.length > 0).at(-1);
            let userInfo = await getUserId(username);
            try {
                let dataURL = await getUserHighSizeProfile(userInfo.user.pk);
                saveFiles(dataURL, {
                    username,
                    sourceType: "avatar",
                    timestamp,
                    filetype: 'jpg',
                    uid: userInfo.user.id
                });
            }
            // eslint-disable-next-line no-unused-vars
            catch (err) {
                saveFiles(userInfo.user.profile_pic_url, {
                    username,
                    sourceType: "avatar",
                    timestamp,
                    filetype: 'jpg',
                    uid: userInfo.user.id
                });
            }

            updateLoadingBar(false);
        }
        else {
            // Add the profile download button
            if (!$('.IG_DWPROFILE').length) {
                let profileTimer = setInterval(() => {
                    if ($('.IG_DWPROFILE').length) {
                        clearInterval(profileTimer);
                        return;
                    }

                    const selector = 'header > *[class]:first-child > *[class]:first-child img[alt]';
                    const $draggableElements = $(`${selector}[draggable]`).parent().parent();
                    const $nonDraggableElements = $(`${selector}:not([draggable])`).parent().parent().parent();
                    $draggableElements.append(`<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_DWPROFILE">${SVG.DOWNLOAD}</div>`);
                    $draggableElements.css('position', 'relative');
                    $nonDraggableElements.append(`<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_DWPROFILE">${SVG.DOWNLOAD}</div>`);
                    $nonDraggableElements.css('position', 'relative');
                }, 150);
            }
        }
    }


    /**
     * skipSharedWithYouDialog
     * @description Auto-skip the "X shared this with you" dialog for ?igsh= links.
     *
     * @return {void}
     */
    function skipSharedWithYouDialog() {
        if (!USER_SETTING.SKIP_SHARED_WITH_YOU_DIALOG) return;

        let url;
        try {
            url = new URL(window.location.href);
        }
        catch (e) {
            logger("[skipSharedWithYouDialog] invalid URL", e);
            return;
        }

        // only for shared links with the tracking param ?igsh=...
        if (!url.searchParams || !url.searchParams.has("igsh")) return;

        const $dialogs = $("div[role=\"dialog\"]");
        if (!$dialogs || !$dialogs.length) {
            return;
        }

        const profileUsername = location.pathname
            .split("/")
            .filter(s => s.length > 0)
            .at(0)?.toLowerCase();

        $dialogs.each(function () {
            const $dialog = $(this);

            if (!$dialog.is(":visible")) {
                return;
            }

            const $headers = $dialog.find("h2");
            if (!$headers.length) {
                return;
            }

            // Heuristic: header text that looks like "profile_name shared this with you"
            const isSharedHeader = $headers.filter(function () {
                const rawText = (this.textContent || "").trim().toLowerCase();
                if (!rawText) return false;

                // Typical case
                if (rawText.includes("shared this with you")) return true;
                if (rawText.includes("shared with you")) return true;

                // Fallback: contains username + "shared"
                if (profileUsername &&
                    rawText.includes(profileUsername) &&
                    rawText.includes("shared")) {
                    return true;
                }

                return false;
            }).length > 0;

            if (!isSharedHeader) {
                return;
            }

            const $buttons = $dialog.find("div[role=\"button\"]");
            if (!$buttons.length) {
                logger("[skipSharedWithYouDialog] dialog has no buttons");
                return;
            }

            let $notNow = null;

            // Prefer a button whose text is exactly "Not now" (case-insensitive)
            $buttons.each(function () {
                const text = (this.textContent || "").trim().toLowerCase();
                if (!text) return;

                if (text === "not now") {
                    $notNow = $(this);
                    return false;
                }
            });

            // Fallback: if there are exactly 2 buttons, assume the second is "Not now"
            if ((!$notNow || !$notNow.length) && $buttons.length === 2) {
                $notNow = $buttons.last();
            }

            if (!$notNow || !$notNow.length) {
                logger("[skipSharedWithYouDialog] could not find \"Not now\" button");
                return;
            }

            logger("[skipSharedWithYouDialog] clicking \"Not now\" button");
            $notNow.trigger("click");
        });
    }

    /**
     * onReels
     * @description Trigger user's reels download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @param  {Boolean}  isVideo - Check if reel is a video element
     * @param  {Boolean}  isPreview - Check if it is need to open new tab
     * @return {void}
     */
    async function onReels(isDownload, isVideo, isPreview) {
        try {
            if (isDownload) {
                updateLoadingBar(true);

                let reelsPath = location.href.split('?').at(0).split('instagram.com/reels/').at(-1).replaceAll('/', '');
                let result = await getBlobMedia(reelsPath);
                let media = filterResourceData(result.data);

                let timestamp = new Date().getTime();

                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                    if (result.type === 'query_hash') {
                        timestamp = media.taken_at_timestamp;
                    }
                    else {
                        timestamp = media.taken_at;
                    }
                }

                if (result.type === 'query_hash') {
                    if (isVideo && media.is_video) {
                        if (isPreview) {
                            openNewTab(media.video_url);
                        }
                        else {
                            let type = 'mp4';
                            saveFiles(media.video_url, {
                                username: media.owner.username,
                                sourceType: "reels",
                                timestamp,
                                filetype: type,
                                shortcode: reelsPath
                            });
                        }
                    }
                    else {
                        if (isPreview) {
                            openNewTab(media.display_resources.at(-1).src);
                        }
                        else {
                            let type = 'jpg';
                            saveFiles(media.display_resources.at(-1).src, {
                                username: media.owner.username,
                                sourceType: "reels",
                                timestamp,
                                filetype: type,
                                shortcode: reelsPath
                            });
                        }
                    }
                }
                else {
                    if (isVideo && media.video_versions != null) {
                        if (isPreview) {
                            openNewTab(media.video_versions[0].url);
                        }
                        else {
                            let type = 'mp4';
                            saveFiles(media.video_versions[0].url, {
                                username: media.owner.username,
                                sourceType: "reels",
                                timestamp,
                                filetype: type,
                                shortcode: reelsPath
                            });
                        }
                    }
                    else {
                        if (isPreview) {
                            openNewTab(media.image_versions2.candidates[0].url);
                        }
                        else {
                            let type = 'jpg';
                            saveFiles(media.image_versions2.candidates[0].url, {
                                username: media.owner.username,
                                sourceType: "reels",
                                timestamp,
                                filetype: type,
                                shortcode: reelsPath
                            });
                        }
                    }
                }

                updateLoadingBar(false);
            }
            else {
                const svgClose = 'svg > polyline[points^="20.643 3.357 12 12 3.353 20.647"] ~ line';
                var timer = setInterval(() => {
                    const hasTiktokStyleLayout = $(svgClose).length > 0;
                    if (hasTiktokStyleLayout || $('section > main[role="main"] > div div.x1qjc9v5 video').length > 0) {
                        clearInterval(timer);

                        if (USER_SETTING.SCROLL_BUTTON) {
                            $('#scrollWrapper').remove();
                            // OPTIMIZATION: cache reels main element (used 5 times below)
                            const $reelsMain = $('section > main[role="main"]');
                            $reelsMain.append('<section id="scrollWrapper"></section>');
                            const $scrollWrapper = $reelsMain.find('> #scrollWrapper');
                            $scrollWrapper.append('<div class="button-up"><div></div></div>');
                            $scrollWrapper.append('<div class="button-down"><div></div></div>');

                            $scrollWrapper.find('> .button-up').on('click', function () {
                                $reelsMain.find('> div')[0].scrollBy({ top: -30, behavior: "smooth" });
                            });
                            $scrollWrapper.find('> .button-down').on('click', function () {
                                $reelsMain.find('> div')[0].scrollBy({ top: 30, behavior: "smooth" });
                            });
                        }

                        $('div[aria-busy][tabindex]').children('div').each(function () {
                            const $this = $(this);
                            if (
                                $this.children().length > 0 &&
                                $this.width() > window.innerWidth * 0.8 &&
                                $this.height() > window.innerHeight * 0.8 &&
                                $this.find('video').length > 0
                            ) {
                                appendReelsButton($this);
                            }
                        });
                    }
                }, 250);
            }
        }
        catch (err) {
            console.error("[reels]", err);
        }
    }

    function appendReelsButton($main) {
        // OPTIMIZATION: cache $main.children() and $main.find('video') usage
        const $mainChildren = $main.children();
        if (!$mainChildren.find('.IG_REELS').length) {
            $mainChildren.css('position', 'relative');

            $mainChildren.append(`<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_REELS">${SVG.DOWNLOAD}</div>`);
            $mainChildren.append(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="IG_REELS_NEWTAB">${SVG.NEW_TAB}</div>`);
            $mainChildren.append(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="IG_REELS_THUMBNAIL">${SVG.THUMBNAIL}</div>`);

            const $videos = $main.find('video');

            $videos.each(function () {
                $(this).off('fullscreenchange.IG_videoControl').on('fullscreenchange.IG_videoControl', function () {
                    const $vid = $(this);
                    if ($vid.attr('style').includes('object-fit')) {
                        if (document.fullscreenElement == this) {
                            $vid.css('object-fit', 'contain');
                        }
                        else {
                            $vid.css('object-fit', 'cover');
                        }
                    }
                });
            });

            // Disable video autoplay
            if (USER_SETTING.DISABLE_VIDEO_LOOPING) {
                $videos.each(function () {
                    $(this).on('ended', function () {
                        const $this = $(this);
                        if (!$this.data('loop')) {
                            let $element_play_button = $this.next().find('div[role="presentation"] > div svg > path[d^="M5.888"]').parents('button[role="button"], div[role="button"]');
                            if ($element_play_button.length > 0) {
                                $this.data('loop', true);
                                $element_play_button.trigger("click");
                                logger('Adding video event listener #loop, then paused click()');
                            }
                            else {
                                $this.data('loop', true);
                                $this.parent().find('.xpgaw4o').removeAttr('style');
                                this.pause();
                                logger('Adding video event listener #loop, then paused pause()');
                            }
                        }
                    });
                });
            }

            if (USER_SETTING.HTML5_VIDEO_CONTROL) {

                const handleSwitchController = function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    let $overlayElement = null;
                    if ($overlayElement == null) {
                        $overlayElement = $(e.target).parents('div[aria-label][data-visualcompletion="ignore"]').first();
                    }

                    $videos.each(function () {
                        const $v = $(this);
                        $v.css('z-index', '2');
                        $v.attr('controls', true);
                        state.GL_weakCache.overlay.set(this, $overlayElement);
                    });

                    $overlayElement.css('z-index', '-10');
                    $main.find('a[href^="/reels/"]').first().attr("draggable", false);
                };

                $main.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', handleSwitchController);
                $videos.each(function () {
                    const $video = $(this);
                    if (!$video.data('controls')) {

                        logger('(reel) Added video html5 contorller #modify');

                        if (USER_SETTING.MODIFY_VIDEO_VOLUME) {
                            this.volume = state.videoVolume;

                            $video.on('loadstart', function () {
                                this.volume = state.videoVolume;
                            });
                        }

                        let $mute_button_wrapper = $video.parent().find('video + div > div');
                        $mute_button_wrapper = $mute_button_wrapper.add($main);

                        // eslint-disable-next-line no-unused-vars
                        let $element_mute_button = $mute_button_wrapper.find('button[type="button"], div[role="button"]').filter(function (idx) {
                            const $b = $(this);
                            return $b.width() <= 64 && $b.height() <= 64 && $b.find('svg > path[d^="M16.636 7.028a1.5"], svg > path[d^="M1.5 13.3c-.8"]').length > 0;
                        });

                        state.GL_weakCache.mutedButton.set(this, $element_mute_button);

                        let $targets = $video.parent().find('video + div div[role="button"]').filter(function () {
                            const $t = $(this);
                            return $t.parent('div[role="presentation"]').length > 0 && $t.css('cursor') === 'pointer' && $t.attr('style') != null;
                        }).first();

                        $video.on('contextmenu', function (e) {
                            e.preventDefault();
                            e.stopPropagation();

                            $video.css('z-index', '-1');
                            $video.removeAttr('controls');
                            $targets.css('z-index', '1');
                            state.GL_weakCache.overlay.get(this)?.css('z-index', '1');
                        });

                        $targets.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', handleSwitchController);

                        $video.on('volumechange', function () {
                            let video = this;
                            let $element_mute_button = state.GL_weakCache.mutedButton.get(this) || {};
                            let is_element_muted = $element_mute_button.find && $element_mute_button.find('svg > path[d^="M16.636"]').length === 0;

                            if (this.muted != is_element_muted) {
                                this.volume = state.videoVolume;

                                if ($element_mute_button.length === 1) {
                                    triggerReactClickHandler($element_mute_button.first()[0]);
                                }
                                else {
                                    let $firstElementMuteButton = $element_mute_button.filter(function () {
                                        return $(this).closest(state.GL_weakCache.overlay.get(video)).length > 0;
                                    }).first();

                                    triggerReactClickHandler($firstElementMuteButton.first()[0]);
                                }
                            }

                            const $v = $(this);
                            if ($v.data('completed')) {
                                state.videoVolume = this.volume;
                                GM_setValue('G_VIDEO_VOLUME', this.volume);
                            }

                            if (this.volume == state.videoVolume) {
                                $v.data('completed', true);
                            }
                        });

                        $video.css('position', 'relative');
                        $video.data('controls', true);
                    }
                });
            }

            var $buttonParent = $main.find('div[role="presentation"] > div[role="button"] > div').first();
            toggleVolumeSilder($videos, $buttonParent, 'reel');
        }
    }

    /**
     * createStoryListDOM
     * @description Create a list of story items in the popup dialog.
     *
     * @return {void}
     */
    async function createStoryListDOM(obj, type) {
        try {
            $('.IG_POPUP_DIG #post_info').text(`${type} ID: ${obj.data.reels_media[0].id}`);
            const selector = '.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_BODY';
            // OPTIMIZATION: cache target once
            const $selector = $(selector);

            // OPTIMIZATION: cache reels_media[0] reference
            const reel = obj.data.reels_media[0];
            const items = reel.items;

            items.forEach((item, idx) => {
                let date = new Date().getTime();
                let timestamp = Math.floor(date / 1000);
                let username = reel?.user?.username || reel?.owner?.username;

                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                    timestamp = item.taken_at_timestamp;
                }

                item.display_resources.sort(function (a, b) {
                    if (a.config_width < b.config_width) return 1;
                    if (a.config_width > b.config_width) return -1;
                    return 0;
                });

                if (item.is_video) {
                    $selector.append(`<a media-id="${item.id}" datetime="${timestamp}" data-blob="true" data-needed="direct" data-name="${type}" data-type="mp4" data-username="${username}" data-path="${item.id}" data-globalIndex="${idx + 1}" href="javascript:;" data-href="${item.video_resources[0].src}"><img width="100" src="${item.display_resources[0].src}" /><br/>- <span data-ih-locale-title="VID">${_i18n("VID")}</span> ${idx} -</a>`);
                }
                else {
                    $selector.append(`<a media-id="${item.id}" datetime="${timestamp}" data-blob="true" data-needed="direct" data-name="${type}" data-type="jpg" data-username="${username}" data-path="${item.id}" data-globalIndex="${idx + 1}" href="javascript:;" data-href="${item.display_resources[0].src}"><img width="100" src="${item.display_resources[0].src}" /><br/>- <span data-ih-locale-title="IMG">${_i18n("IMG")}</span> ${idx} -</a>`);
                }
            });

            $selector.find('a').each(function () {
                const $a = $(this);
                $a.wrap('<div></div>');
                $a.before('<label class="inner_box_wrapper"><input class="inner_box" type="checkbox"><span></span></label>');
                $a.after(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="newTab">${SVG.NEW_TAB}</div>`);

                if ($a.data('type') == 'mp4') {
                    $a.after(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="videoThumbnail">${SVG.THUMBNAIL}</div>`);
                }
            });

            updatePopupSelectionSummary();
            $('.IG_POPUP_DIG #batch_download_selected, .IG_POPUP_DIG #batch_download_direct').prop('disabled', false);
            updateLoadingBar(false);
        }
        catch (err) {
            console.error('createStoryListDOM()', err);
        }
    }

    /**
     * onStoryAll
     * @description Trigger user's story all download event.
     *
     * @return {void}
     */
    async function onStoryAll() {
        updateLoadingBar(true);

        let date = new Date().getTime();
        let timestamp = Math.floor(date / 1000);
        let username = $("body > div section._ac0a header._ac0k ._ac0l a + div a").first().text() || location.pathname.split("/").filter(s => s.length > 0).at(1);

        let userInfo = await getUserId(username);
        let userId = userInfo.user.pk;
        let stories = await getStories(userId);

        if (USER_SETTING.DIRECT_DOWNLOAD_STORY) {
            let complete = 0;
            // OPTIMIZATION: cache items array — repeatedly accessed inside setTimeout closures
            const items = stories.data.reels_media[0].items;
            const totalItems = items.length;
            setDownloadProgress(complete, totalItems);

            items.forEach((item, idx) => {
                setTimeout(() => {
                    if (USER_SETTING.RENAME_PUBLISH_DATE) {
                        timestamp = item.taken_at_timestamp;
                    }

                    item.display_resources.sort(function (a, b) {
                        if (a.config_width < b.config_width) return 1;
                        if (a.config_width > b.config_width) return -1;
                        return 0;
                    });

                    if (item.is_video) {
                        saveFiles(item.video_resources[0].src,
                            {
                                username,
                                sourceType: "stories",
                                timestamp,
                                filetype: 'mp4',
                                shortcode: item.id
                            }).then(() => {
                                setDownloadProgress(++complete, totalItems);
                            });
                    }
                    else {
                        saveFiles(item.display_resources[0].src, {
                            username,
                            sourceType: "stories",
                            timestamp,
                            filetype: 'jpg',
                            shortcode: item.id
                        }).then(() => {
                            setDownloadProgress(++complete, totalItems);
                        });
                    }
                }, 100 * idx);
            });
        }
        else {
            IG_createDM(false, true);
            createStoryListDOM(stories, 'stories');
        }
    }

    /**
     * resolveStoryMediaIdByTimestamp
     * @description Identifies the currently visible story by comparing the
     *              <time datetime> element in the viewer with taken_at_timestamp
     *              from the API items array. More reliable than index-based DOM
     *              mapping because it does not depend on CSS class names or
     *              progress-bar structure.
     *
     * @param  {Object}  stories  - Full getStories() / getHighlightStories() response
     * @return {?String}          - Best-matching item id, or null if undetermined
     */
    function resolveStoryMediaIdByTimestamp(stories) {
        const items = stories?.data?.reels_media?.[0]?.items;
        if (!items || items.length === 0) return null;

        // Reuse the same multi-layout time-element selection that the rest of the
        // script already relies on; exclude highlight-nav links and role="button"
        // to avoid picking up unrelated timestamps.
        const $time = $(
            'body > div section:visible time[datetime]'
        ).filter(function () {
            const $this = $(this);
            return (
                $this.is(':visible') &&
                $this.closest('a[href^="/stories/highlights/"]').length === 0 &&
                $this.closest('[role="button"]').length === 0
            );
        }).first();

        if ($time.length === 0) return null;

        const visibleTs = Math.floor(new Date($time.attr('datetime')).getTime() / 1000);
        if (!Number.isFinite(visibleTs) || visibleTs === 0) return null;

        let bestId = null;
        let minDiff = Infinity;

        items.forEach(item => {
            const diff = Math.abs((item.taken_at_timestamp || 0) - visibleTs);
            if (diff < minDiff) {
                minDiff = diff;
                bestId = item.id;
            }
        });

        logger('[resolveStoryMediaIdByTimestamp]', 'best match:', bestId, 'diff(s):', minDiff);
        return bestId;  // always return best match — better than any index heuristic
    }

    /**
     * onStory
     * @description Trigger user's story download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @param  {Boolean}  isForce - Check if downloading directly from API instead of cache
     * @param  {Boolean}  isPreview - Check if it is need to open new tab
     * @return {void}
     */
    async function onStory(isDownload, isForce, isPreview) {
        var username = $("body > div section._ac0a header._ac0k ._ac0l a + div a").first().text() || location.pathname.split("/").filter(s => s.length > 0).at(1);
        if (isDownload) {
            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);

            updateLoadingBar(true);
            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && !state.tempFetchRateLimit) {
                let mediaId = null;

                let userInfo = await getUserId(username);
                let userId = userInfo.user.pk;
                let stories = await getStories(userId);
                let urlID = location.pathname.split('/').filter(s => s.length > 0 && s.match(/^([0-9]{10,})$/)).at(-1);

                // OPTIMIZATION: cache items reference (used 4+ times)
                const items = stories.data.reels_media[0].items;

                items.forEach(item => {
                    if (item.id == urlID) {
                        mediaId = item.id;
                    }
                });

                // FIX: timestamp-based match before fragile index/CSS fallbacks
                if (mediaId == null) {
                    mediaId = resolveStoryMediaIdByTimestamp(stories);
                }

                if (mediaId == null) {
                    let $header = getStoryProgress(username);

                    $header.each(function (index) {
                        if ($(this).children().length > 0) {
                            mediaId = items[index].id;
                        }
                    });
                }

                if (mediaId == null) {
                    // appear in from profile page to story page
                    $('body > div section:visible div.x1ned7t2.x78zum5 > div').each(function (index) {
                        const $this = $(this);
                        if ($this.hasClass('x1lix1fw')) {
                            if ($this.children().length > 0) {
                                mediaId = items[index].id;
                            }
                        }
                    });

                    // appear in from home page to story page
                    $('body > div section:visible ._ac0k > ._ac3r > div').each(function (index) {
                        if ($(this).children().hasClass('_ac3q')) {
                            mediaId = items[index].id;
                        }
                    });
                }

                if (mediaId == null) {
                    mediaId = location.pathname.split('/').filter(s => s.length > 0 && s.match(/^([0-9]{10,})$/)).at(-1);
                }

                if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                    const cached = getImageFromCache(mediaId);
                    if (cached && !items.filter(item => item.id === mediaId).at(0).is_video) {
                        logger("[Restore Cached onStory]", mediaId);
                        if (isPreview) {
                            openNewTab(cached);
                        }
                        else {
                            saveFiles(cached, {
                                username,
                                sourceType: "stories",
                                timestamp,
                                filetype: 'jpg',
                                shortcode: mediaId
                            });
                        }
                        return;
                    }
                }

                let result = await getMediaInfo(mediaId);

                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                    timestamp = result.items[0].taken_at;
                }

                if (result.status === 'ok') {
                    // OPTIMIZATION: cache result.items[0]
                    const mediaItem = result.items[0];
                    if (mediaItem.video_versions) {
                        const handled = await tryHandleDashFromMediaItem({
                            mediaItem: mediaItem,
                            username,
                            sourceType: "stories",
                            timestamp,
                            shortcode: mediaId,
                            isPreview,
                        });
                        if (handled) {
                            updateLoadingBar(false);
                            return;
                        }

                        if (isPreview) {
                            openNewTab(mediaItem.video_versions[0].url);
                        }
                        else {
                            saveFiles(mediaItem.video_versions[0].url, {
                                username,
                                sourceType: "stories",
                                timestamp,
                                filetype: 'mp4',
                                shortcode: mediaId
                            });
                        }
                    }
                    else {
                        if (isPreview) {
                            openNewTab(mediaItem.image_versions2.candidates[0].url);
                        }
                        else {
                            saveFiles(mediaItem.image_versions2.candidates[0].url, {
                                username,
                                sourceType: "stories",
                                timestamp,
                                filetype: 'jpg',
                                shortcode: mediaId
                            });
                        }
                    }
                }
                else {
                    if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED) {
                        state.tempFetchRateLimit = true;
                        onStory(isDownload, isForce, isPreview);
                    }
                    else {
                        alert('Fetch failed from Media API. API response message: ' + result.message);
                    }
                    logger(result);
                }

                updateLoadingBar(false);
                return;
            }

            if ($('body > div section:visible video[playsinline]').length > 0) {
                // Download stories if it is video
                let type = "mp4";
                let videoURL = "";
                let targetURL = location.pathname.replace(/\/$/ig, '').split("/").at(-1);
                let mediaId = null;

                if (state.GL_dataCache.stories[username] && !isForce) {
                    logger('Fetch from memory cache:', username);
                    state.GL_dataCache.stories[username].data.reels_media[0].items.forEach(item => {
                        if (item.id == targetURL) {
                            videoURL = item.video_resources[0].src;
                            if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                timestamp = item.taken_at_timestamp;
                                mediaId = item.id;
                            }
                        }
                    });

                    if (videoURL.length == 0) {
                        logger('Memory cache not found, try fetch from API:', username);
                        onStory(true, true);
                        return;
                    }
                }
                else {
                    let userInfo = await getUserId(username);
                    let userId = userInfo.user.pk;
                    let stories = await getStories(userId);
                    // OPTIMIZATION: cache items
                    const items = stories.data.reels_media[0].items;

                    items.forEach(item => {
                        if (item.id == targetURL) {
                            videoURL = item.video_resources[0].src;
                            if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                timestamp = item.taken_at_timestamp;
                                mediaId = item.id;
                            }
                        }
                    });

                    // GitHub issue #4: thinkpad4
                    if (videoURL.length == 0) {

                        let $header = getStoryProgress(username);

                        $header.each(function (index) {
                            if ($(this).children().length > 0) {
                                videoURL = items[index].video_resources[0].src;
                                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                    timestamp = items[index].taken_at_timestamp;
                                    mediaId = items[index].id;
                                }
                            }
                        });


                        if (videoURL.length == 0) {
                            // appear in from profile page to story page
                            $('body > div section:visible div.x1ned7t2.x78zum5 > div').each(function (index) {
                                const $this = $(this);
                                if ($this.hasClass('x1lix1fw')) {
                                    if ($this.children().length > 0) {
                                        videoURL = items[index].video_resources[0].src;
                                        if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                            timestamp = items[index].taken_at_timestamp;
                                            mediaId = items[index].id;
                                        }
                                    }
                                }
                            });

                            // appear in from home page to story page
                            $('body > div section:visible ._ac0k > ._ac3r > div').each(function (index) {
                                if ($(this).children().hasClass('_ac3q')) {
                                    videoURL = items[index].video_resources[0].src;
                                    if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                        timestamp = items[index].taken_at_timestamp;
                                        mediaId = items[index].id;
                                    }
                                }
                            });
                        }
                    }

                    state.GL_dataCache.stories[username] = stories;
                }

                if (videoURL.length == 0) {
                    alert(_i18n("NO_VID_URL"));
                }
                else {
                    if (isPreview) {
                        openNewTab(videoURL);
                    }
                    else {
                        saveFiles(videoURL, {
                            username,
                            sourceType: "stories",
                            timestamp,
                            filetype: type,
                            shortcode: mediaId
                        });
                    }
                }
            }
            else {
                // Download stories if it is image
                let srcset = $('body > div section:visible img[referrerpolicy][class], body > div section:visible img[crossorigin][class]:not([alt])').attr('srcset')?.split(',')[0]?.split(' ')[0];
                let link = (srcset) ? srcset : $('body > div section:visible img[referrerpolicy][class], body > div section:visible img[crossorigin][class]:not([alt])').filter(function () {
                    const $this = $(this);
                    return $this.parents('a').length === 0 && $this.width() === $this.parent().width();
                }).attr('src');

                if (!link) {
                    // _aa63 mean stories picture in stories page (not avatar)
                    let $element = $('body > div section:visible img._aa63');
                    link = ($element.attr('srcset')) ? $element.attr('srcset')?.split(',')[0]?.split(' ')[0] : $element.attr('src');
                }

                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                    timestamp = new Date($('body > div section:visible time[datetime][class]').first().attr('datetime')).getTime();
                }

                let downloadLink = link;
                let type = 'jpg';

                const mediaId = getImageFromCache(getStoryId(downloadLink) ?? "-");

                if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                    const cached = getImageFromCache(mediaId);
                    if (cached) {
                        if (isPreview) {
                            openNewTab(cached);
                        }
                        else {
                            saveFiles(cached, {
                                username,
                                sourceType: "stories",
                                timestamp,
                                filetype: 'jpg',
                                shortcode: mediaId
                            });
                        }
                        return;
                    }
                }

                if (isPreview) {
                    openNewTab(downloadLink);
                }
                else {
                    saveFiles(downloadLink, {
                        username,
                        sourceType: "stories",
                        timestamp,
                        filetype: type,
                        shortcode: mediaId
                    });
                }
            }

            state.tempFetchRateLimit = false;
            updateLoadingBar(false);
        }
        else {
            // Add the stories download button
            if (!$('.IG_DWSTORY').length) {
                state.GL_dataCache.stories = {};
                let $element = null;
                // Default detecter (section layout mode)
                if ($('body > div section._ac0a').length > 0) {
                    $element = $('body > div section:visible._ac0a');
                }
                // detecter (single story layout mode)
                else {
                    $element = $('body > div section:visible > div > div[style]:not([class])');
                    $element.css('position', 'relative');
                }


                if ($element.length === 0) {
                    $element = $('div[id^="mount"] section > div > a[href="/"]').parent().parent().parent().find('section:visible > div > div[style]:not([class])');
                    $element.css('position', 'relative');
                }

                if ($element.length === 0) {
                    $element = $('div[id^="mount"] section > div > a[href="/"]').parent().parent().parent().find('section:visible > div div[style]:not([class]) > div:not([data-visualcompletion="loading-state"])');
                    $element.css('position', 'relative');
                }

                if ($element.length === 0) {
                    $element = $('div[id^="mount"] section > div a[href="/"]').parents('section:visible').find('div[style]:not([class])');
                    $element.css('position', 'relative');
                }


                // Detecter for div layout mode
                if ($element.length === 0) {
                    let $$element = $('body > div div:not([hidden]) section:visible > div div[class][style] > div[style]:not([class])');
                    let nowSize = 0;

                    $$element.each(function () {
                        const $this = $(this);
                        const width = $this.width();
                        if (width > nowSize) {
                            nowSize = width;
                            $element = $this.children('div').first();
                        }
                    });
                }


                if ($element != null) {
                    // OPTIMIZATION: cache .first() once
                    const $firstEl = $element.first();
                    $firstEl.css('position', 'relative');
                    $firstEl.append(`<div data-ih-locale-title="DW" title="${_i18n("DW")}" class="IG_DWSTORY">${SVG.DOWNLOAD}</div>`);
                    $firstEl.append(`<div data-ih-locale-title="NEW_TAB" title="${_i18n("NEW_TAB")}" class="IG_DWNEWTAB">${SVG.NEW_TAB}</div>`);

                    let $header = getStoryProgress(username);
                    if ($header.length > 1) {
                        $firstEl.append(`<div data-ih-locale-title="DW_ALL" title="${_i18n("DW_ALL")}" class="IG_DWSTORY_ALL">${SVG.DOWNLOAD_ALL}</div>`);
                    }

                    setStoryProgressIndexText($firstEl, $header, 'IG_DWSTORY_POSITION');

                    // Modify video volume
                    //if(USER_SETTING.MODIFY_VIDEO_VOLUME){
                    //    $element.find('video').each(function(){
                    //        $(this).on('play playing', function(){
                    //            if(!$(this).data('modify')){
                    //                $(this).data('modify', true);
                    //                this.volume = VIDEO_VOLUME;
                    //                logger('(story) Added video event listener #modify');
                    //            }
                    //        });
                    //    });
                    //}

                    // Make sure to first remove thumbnail button if still exists and story is a picture
                    $element.find('img[referrerpolicy]').each(function () {
                        $(this).on('load', function () {
                            const $img = $(this);
                            if (!$img.data('remove-thumbnail')) {
                                if ($element.find('.IG_DWSTORY_THUMBNAIL').length === 0) {
                                    $img.data('remove-thumbnail', true);
                                    $('.IG_DWSTORY_THUMBNAIL').remove();
                                    logger('(story) Manually removing thumbnail button');
                                }
                                else {
                                    $img.data('remove-thumbnail', true);
                                    logger('(story) Thumbnail button is not present for this picture');
                                }
                            }
                        });
                    });

                    // Try to use event listener 'timeupdate' in order to detect if story is a video
                    //$element.find('video').each(function(){
                    //    $(this).on('timeupdate',function(){
                    //        if(!$(this).data('modify-thumbnail')){
                    //            if($element.find('.IG_DWSTORY_THUMBNAIL').length === 0){
                    //                $(this).data('modify-thumbnail', true);
                    //                onStoryThumbnail(false);
                    //                logger('(story) Manually inserting thumbnail button');
                    //            }
                    //            else{
                    //                $(this).data('modify-thumbnail', true);
                    //                logger('(story) Thumbnail button already inserted');
                    //            }
                    //        }
                    //    });
                    //});
                }
            }
            else {
                setStoryProgressIndexByUsername($('.IG_DWSTORY').parent(), username, 'IG_DWSTORY_POSITION');
            }
        }
    }

    /**
     * onStoryThumbnail
     * @description Trigger user's story video thumbnail download event or button display event.
     *
     * @param  {Boolean}  isDownload - Check if it is a download operation
     * @param  {Boolean}  isForce - Check if downloading directly from API instead of cache
     * @return {void}
     */
    async function onStoryThumbnail(isDownload, isForce) {
        if (isDownload) {
            // Download stories if it is video
            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);
            let type = 'jpg';
            let username = $("body > div section._ac0a header._ac0k ._ac0l a + div a").first().text() || location.pathname.split('/').at(2);
            // Download thumbnail
            let targetURL = location.pathname.replace(/\/$/ig, '').split("/").at(-1);
            let videoThumbnailURL = "";
            let mediaId = null;

            updateLoadingBar(true);

            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && !state.tempFetchRateLimit) {
                let userInfo = await getUserId(username);
                let userId = userInfo.user.pk;
                let stories = await getStories(userId);
                let urlID = location.pathname.split('/').filter(s => s.length > 0 && s.match(/^([0-9]{10,})$/)).at(-1);
                // OPTIMIZATION: cache items reference
                const items = stories.data.reels_media[0].items;

                items.forEach(item => {
                    if (item.id == urlID) {
                        mediaId = item.id;
                    }
                });

                // FIX: timestamp-based match before fragile index/CSS fallbacks
                if (mediaId == null) {
                    mediaId = resolveStoryMediaIdByTimestamp(stories);
                }

                if (mediaId == null) {
                    let $header = getStoryProgress(username);

                    $header.each(function (index) {
                        if ($(this).children().length > 0) {
                            mediaId = items[index].id;
                        }
                    });
                }

                if (mediaId == null) {
                    // appear in from profile page to story page
                    $('body > div section:visible div.x1ned7t2.x78zum5 > div').each(function (index) {
                        const $this = $(this);
                        if ($this.hasClass('x1lix1fw')) {
                            if ($this.children().length > 0) {
                                mediaId = items[index].id;
                            }
                        }
                    });

                    // appear in from home page to story page
                    $('body > div section:visible ._ac0k > ._ac3r > div').each(function (index) {
                        if ($(this).children().hasClass('_ac3q')) {
                            mediaId = items[index].id;
                        }
                    });
                }

                if (mediaId == null) {
                    mediaId = location.pathname.split('/').filter(s => s.length > 0 && s.match(/^([0-9]{10,})$/)).at(-1);
                }

                if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                    const cached = getImageFromCache(mediaId);
                    if (cached) {
                        logger("[Restore Cached onStoryThumbnail]", mediaId);
                        saveFiles(cached, {
                            username,
                            sourceType: "stories",
                            timestamp,
                            filetype: 'jpg',
                            shortcode: mediaId
                        });
                        return;
                    }
                }

                let result = await getMediaInfo(mediaId);

                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                    timestamp = result.items[0].taken_at;
                }

                if (result.status === 'ok') {
                    saveFiles(result.items[0].image_versions2.candidates[0].url, {
                        username,
                        sourceType: "stories",
                        timestamp,
                        filetype: 'jpg',
                        shortcode: mediaId
                    });

                }
                else {
                    if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED) {
                        state.tempFetchRateLimit = true;
                        onStoryThumbnail(true, isForce);
                    }
                    else {
                        alert('Fetch failed from Media API. API response message: ' + result.message);
                    }

                    logger(result);
                }

                updateLoadingBar(false);
                return;
            }

            if (state.GL_dataCache.stories[username] && !isForce) {
                logger('Fetch from memory cache:', username);
                state.GL_dataCache.stories[username].data.reels_media[0].items.forEach(item => {
                    if (item.id == targetURL) {
                        videoThumbnailURL = item.display_url;
                        if (USER_SETTING.RENAME_PUBLISH_DATE) {
                            timestamp = item.taken_at_timestamp;
                            mediaId = item.id;
                        }
                    }
                });

                if (videoThumbnailURL.length == 0) {
                    logger('Memory cache not found, try fetch from API:', username);
                    onStoryThumbnail(true, true);
                    return;
                }
            }
            else {
                let userInfo = await getUserId(username);
                let userId = userInfo.user.pk;
                let stories = await getStories(userId);
                // OPTIMIZATION: cache items
                const items = stories.data.reels_media[0].items;

                items.forEach(item => {
                    if (item.id == targetURL) {
                        videoThumbnailURL = item.display_url;
                        if (USER_SETTING.RENAME_PUBLISH_DATE) {
                            timestamp = item.taken_at_timestamp;
                            mediaId = item.id;
                        }
                    }
                });

                // GitHub issue #4: thinkpad4
                if (videoThumbnailURL.length == 0) {
                    let $header = getStoryProgress(username);

                    $header.each(function (index) {
                        if ($(this).children().length > 0) {
                            videoThumbnailURL = items[index].display_url;
                            if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                timestamp = items[index].taken_at_timestamp;
                                mediaId = items[index].id;
                            }
                        }
                    });

                    if (videoThumbnailURL.length == 0) {
                        // appear in from profile page to story page
                        $('body > div section:visible div.x1ned7t2.x78zum5 > div').each(function (index) {
                            const $this = $(this);
                            if ($this.hasClass('x1lix1fw')) {
                                if ($this.children().length > 0) {
                                    videoThumbnailURL = items[index].display_url;
                                    if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                        timestamp = items[index].taken_at_timestamp;
                                        mediaId = items[index].id;
                                    }
                                }
                            }
                        });

                        // appear in from home page to story page
                        $('body > div section:visible ._ac0k > ._ac3r > div').each(function (index) {
                            if ($(this).children().hasClass('_ac3q')) {
                                videoThumbnailURL = items[index].display_url;
                                if (USER_SETTING.RENAME_PUBLISH_DATE) {
                                    timestamp = items[index].taken_at_timestamp;
                                    mediaId = items[index].id;
                                }
                            }
                        });
                    }
                }
            }

            saveFiles(videoThumbnailURL, {
                username,
                sourceType: "thumbnail",
                timestamp,
                filetype: type,
                shortcode: mediaId
            });
            state.tempFetchRateLimit = false;
            updateLoadingBar(false);
        }
        else {
            if ($('body > div div.IG_DWSTORY').parent().find('video').length) {
                // Add the stories download button
                let $element = null;
                // Default detecter (section layout mode)
                if ($('body > div section._ac0a').length > 0) {
                    $element = $('body > div section:visible._ac0a');
                }
                // detecter (single story layout mode)
                else {
                    $element = $('body > div section:visible > div > div[style]:not([class])');
                    $element.css('position', 'relative');
                }

                if ($element.length === 0) {
                    $element = $('div[id^="mount"] section > div > a[href="/"]').parent().parent().parent().find('section:visible > div > div[style]:not([class])');
                    $element.css('position', 'relative');
                }

                if ($element.length === 0) {
                    $element = $('div[id^="mount"] section > div > a[href="/"]').parent().parent().parent().find('section:visible > div div[style]:not([class]) > div:not([data-visualcompletion="loading-state"])');
                    $element.css('position', 'relative');
                }

                // Detecter for div layout mode
                if ($element.length === 0) {
                    let $$element = $('body > div div:not([hidden]) section:visible > div div[class][style] > div[style]:not([class])');
                    let nowSize = 0;

                    $$element.each(function () {
                        const $this = $(this);
                        const width = $this.width();
                        if (width > nowSize) {
                            nowSize = width;
                            $element = $this.children('div').first();
                        }
                    });
                }


                if ($element != null) {
                    const $firstEl = $element.first();
                    $firstEl.css('position', 'relative');
                    $firstEl.append(`<div data-ih-locale-title="VIDEO_THUMBNAIL" title="${_i18n("VIDEO_THUMBNAIL")}" class="IG_DWSTORY_THUMBNAIL">${SVG.THUMBNAIL}</div>`);
                }

            }
        }
    }

    /* utils */

    /**
     * getHighlightStories
     * @description Get a list of all stories in highlight Id.
     *
     * @param  {Integer}  highlightId
     * @return {Object}
     */
    function getHighlightStories(highlightId) {
        return new Promise((resolve, reject) => {
            const getURL = `https://www.instagram.com/graphql/query/?query_hash=45246d3fe16ccc6577e0bd297a5db1ab&variables=%7B%22highlight_reel_ids%22:%5B%22${highlightId}%22%5D,%22precomposed_overlay%22:false%7D`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        resolve(obj);
                    }
                    catch (err) {
                        logger('getHighlightStories()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getHighlightStories()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getStories
     * @description Get a list of all stories in user Id.
     *
     * @param  {Integer}  userId
     * @return {Object}
     */
    function getStories(userId) {
        return new Promise((resolve, reject) => {
            const getURL = `https://www.instagram.com/graphql/query/?query_hash=15463e8449a83d3d60b06be7e90627c7&variables=%7B%22reel_ids%22:%5B%22${userId}%22%5D,%22precomposed_overlay%22:false%7D`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        logger('getStories()', obj);
                        resolve(obj);
                    }
                    catch (err) {
                        logger('getStories()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getStories()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getUserId
     * @description Get user's id with username.
     *
     * @param  {String}  username
     * @return {Promise<Integer>}
     */
    function getUserId(username) {
        return new Promise((resolve, reject) => {
            if (userIdCache.has(username)) {
                logger('getUserId()', 'return from cache:', userIdCache.get(username));
                resolve(userIdCache.get(username));
                return;
            }

            let getURL = `https://www.instagram.com/web/search/topsearch/?query=${username}`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                onload: function (response) {
                    // Fix search issue by Discord: sno_w_
                    let obj = JSON.parse(response.response);
                    let result = null;
                    obj.users.forEach(pos => {
                        if (pos.user.username?.toLowerCase() === username?.toLowerCase()) {
                            result = pos;
                        }
                    });

                    if (result != null) {
                        logger('getUserId()', result);
                        userIdCache.set(username, result);
                        resolve(result);
                    }
                    else {
                        getUserIdWithAgent(username).then((result) => {
                            userIdCache.set(username, result);
                            resolve(result);
                            // eslint-disable-next-line no-unused-vars
                        }).catch((err) => {
                            userIdCache.delete(username);
                            alert("Cannot find user info from getUserId()");
                        });
                    }
                },
                onerror: function (err) {
                    logger('getUserId()', 'reject', err);
                    userIdCache.delete(username);
                    reject(err);
                }
            });
        });
    }

    /**
     * getUserIdWithAgent
     * @description Get user's id with username.
     *
     * @param  {String}  username
     * @return {Integer}
     */
    function getUserIdWithAgent(username) {
        return new Promise((resolve, reject) => {
            const getURL = `https://i.instagram.com/api/v1/users/web_profile_info/?username=${username}`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                headers: {
                    'X-IG-App-ID': getAppID()
                },
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        let hasUser = obj?.data?.user;

                        if (hasUser != null) {
                            let userInfo = obj?.data;
                            userInfo.user.pk = userInfo.user.id;
                            logger('getUserIdWithAgent()', obj);
                            resolve(userInfo);
                        }
                        else {
                            logger('getUserIdWithAgent()', 'reject', 'undefined');
                            reject('undefined');
                        }
                    }
                    catch (err) {
                        logger('getUserIdWithAgent()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getUserIdWithAgent()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getUserHighSizeProfile
     * @description Get user's high quality avatar image.
     *
     * @param  {Integer}  userId
     * @return {String}
     */
    function getUserHighSizeProfile(userId) {
        return new Promise((resolve, reject) => {
            const getURL = `https://www.instagram.com/api/v1/users/${userId}/info/`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Pixel 7 XL)Build/RP1A.20845.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Chrome/117.0.5938.60 Mobile Safari/537.36 Instagram 307.0.0.34.111'
                },
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        if (obj.status !== 'ok') {
                            logger('getUserHighSizeProfile()', 'reject', obj);
                            reject('faild');
                        }
                        else {
                            logger('getUserHighSizeProfile()', obj);
                            resolve(obj.user.hd_profile_pic_url_info?.url);
                        }
                    }
                    catch (err) {
                        logger('getUserHighSizeProfile()', 'reject', err);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getUserHighSizeProfile()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getPostOwner
     * @description Get post's author with post shortcode.
     *
     * @param  {String}  postPath
     * @return {String}
     */
    function getPostOwner(postPath) {
        return new Promise((resolve, reject) => {
            if (!postPath) reject("NOPATH");
            const postShortCode = postPath;
            const getURL = `https://www.instagram.com/graphql/query/?query_hash=2c4c2e343a8f64c625ba02b2aa12c7f8&variables=%7B%22shortcode%22:%22${postShortCode}%22}`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        logger('getPostOwner()', obj);
                        resolve(obj.data.shortcode_media.owner.username);
                    }
                    catch (err) {
                        logger('getPostOwner()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getPostOwner()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getBlobMedia
     * @description Get list of all media files in post with post shortcode.
     *
     * @param  {String}  postPath
     * @return {Object}
     */
    function getBlobMedia(postPath) {
        return new Promise((resolve, reject) => {
            if (!postPath) reject("NOPATH");
            const postShortCode = postPath;
            const getURL = `https://www.instagram.com/graphql/query/?query_hash=2c4c2e343a8f64c625ba02b2aa12c7f8&variables=%7B%22shortcode%22:%22${postShortCode}%22}`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; Pixel 7 XL)Build/RP1A.20845.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Chrome/117.0.5938.60 Mobile Safari/537.36 Instagram 307.0.0.34.111"
                },
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        logger(obj);

                        if (obj.status === 'fail') {
                            // alert(`Request failed with API response:\n${obj.message}: ${obj.feedback_message}`);
                            logger('Request with:', 'getBlobMediaWithQuery()', postShortCode);
                            getBlobMediaWithQueryID(postShortCode).then((res) => {
                                resolve({ type: 'query_id', data: res.xdt_api__v1__media__shortcode__web_info.items[0] });
                            }).catch((err) => {
                                reject(err);
                            })
                        }
                        else {
                            resolve({ type: 'query_hash', data: obj.data });
                        }
                    }
                    catch (err) {
                        logger('getBlobMedia()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getBlobMedia()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getBlobMediaWithQueryID
     * @description Get list of all media files in post with post shortcode.
     *
     * @param  {String}  postPath
     * @return {Object}
     */
    function getBlobMediaWithQueryID(postPath) {
        return new Promise((resolve, reject) => {
            if (!postPath) reject("NOPATH");
            const postShortCode = postPath;
            const getURL = `https://www.instagram.com/graphql/query/?query_id=9496392173716084&variables={%22shortcode%22:%22${postShortCode}%22,%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22:true,%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22:true}`;

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; Pixel 7 XL)Build/RP1A.20845.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Chrome/117.0.5938.60 Mobile Safari/537.36 Instagram 307.0.0.34.111",
                    'X-IG-App-ID': getAppID()
                },
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        logger(obj);

                        if (obj.status === 'fail') {
                            alert(`getBlobMediaWithQueryID(): Request failed with API response:\n${obj.message}: ${obj.feedback_message}`);
                            logger(`Request failed with API response ${obj.message}: ${obj.feedback_message}`);
                            reject(response);
                        }
                        else {
                            logger('getBlobMediaWithQueryID()', obj.data);
                            resolve(obj.data);
                        }
                    }
                    catch (err) {
                        logger('getBlobMediaWithQueryID()', 'reject', err.message);
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getBlobMediaWithQueryID()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * getMediaInfo
     * @description Get Instagram Media object.
     *
     * @param  {String}  mediaId
     * @return {Object}
     */
    function getMediaInfo(mediaId) {
        return new Promise((resolve, reject) => {
            const getURL = `https://i.instagram.com/api/v1/media/${mediaId}/info/`;

            if (mediaId == null) {
                alert("Cannot call Media API because of the media id is invalid.");
                logger('getMediaInfo()', 'reject', 'Cannot call Media API because of the media id is invalid.');

                updateLoadingBar(false);
                reject(-1);
                return;
            }
            if (getAppID() == null) {
                alert("Cannot call Media API because of the app id is invalid.");
                logger('getMediaInfo()', 'reject', 'Cannot call Media API because of the app id is invalid.');
                updateLoadingBar(false);
                reject(-1);
                return;
            }

            GM_xmlhttpRequest({
                method: "GET",
                url: getURL,
                headers: {
                    "User-Agent": window.navigator.userAgent,
                    "Accept": "*/*",
                    'X-IG-App-ID': getAppID()
                },
                onload: function (response) {
                    if (response.finalUrl == getURL) {
                        let obj = JSON.parse(response.response);
                        logger('getMediaInfo()', obj);
                        resolve(obj);
                    }
                    else {
                        let finalURL = new URL(response.finalUrl);
                        if (finalURL.pathname.startsWith('/accounts/login')) {
                            logger('getMediaInfo()', 'reject', 'The account must be logged in to access Media API.');
                            alert("The account must be logged in to access Media API.");
                        }
                        else {
                            logger('getMediaInfo()', 'reject', 'Unable to retrieve content because the API was redirected to "' + response.finalUrl + '"');
                            alert('Unable to retrieve content because the API was redirected to "' + response.finalUrl + '"');
                        }
                        updateLoadingBar(false);
                        reject(-1);
                    }
                },
                onerror: function (err) {
                    logger('getMediaInfo()', 'reject', err);
                    resolve(err);
                }
            });
        });
    }

    function isMacOS() {
        return /Macintosh|Mac OS/i.test(navigator.userAgent);
    }

    function getPlatformModifierKey() {
        return isMacOS() ? '⌥' : 'Alt';
    }

    /**
     * getStoryId
     * @description Obtain the media id through the resource URL.
     *
     * @param  {string}  url
     * @return {string}
     */
    function getStoryId(url) {
        let obj = new URL(url);
        let base64 = obj?.searchParams?.get('ig_cache_key')?.split('.').at(0);
        if (base64) {
            return atob(base64);
        }
        else {
            return null;
        }
    }

    /**
     * getAppID
     * @description Get Instagram App ID.
     *
     * @return {?string}
     */
    function getAppID() {
        let result = null;
        $('script[type="application/json"]').each(function () {
            const regexp = /"APP_ID":"([0-9]+)"/ig;
            const $this = $(this);
            const text = $this.text();
            const matcher = text.match(regexp);
            if (matcher != null && result == null) {
                result = [...text.matchAll(regexp)];
            }
        })

        return (result) ? result.at(0).at(-1) : null;
    }

    /**
     * getTimeElementBaseDateSource
     * @description Get the base date text source and cache key from a time element.
     *
     * @param  {JQuery}  $time
     * @return {{dateText: ?string, cacheKey: ?string}}
     */
    function getTimeElementBaseDateSource($time) {
        const titleText = $time.attr('title')?.trim();
        if (titleText) {
            return {
                dateText: titleText,
                cacheKey: `title:${titleText}`
            };
        }

        const datetime = $time.attr('datetime')?.trim();
        if (datetime) {
            const date = new Date(datetime);
            if (!Number.isNaN(date.getTime())) {
                return {
                    dateText: new Intl.DateTimeFormat(undefined, {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                    }).format(date),
                    cacheKey: `datetime:${datetime}`
                };
            }
        }

        return {
            dateText: null,
            cacheKey: null
        };
    }

    /**
     * getTimeElementBaseDateText
     * @description Get the preserved absolute date text from a time element.
     *
     * @param  {JQuery}  $time
     * @return {?string}
     */
    function getTimeElementBaseDateText($time) {
        const preservedText = $time.attr('data-ih-original-date')?.trim();
        const preservedKey = $time.attr('data-ih-original-date-key')?.trim();
        const { dateText, cacheKey } = getTimeElementBaseDateSource($time);

        if (preservedText && preservedKey && cacheKey && preservedKey === cacheKey) {
            return preservedText;
        }

        if (dateText && cacheKey) {
            $time.attr('data-ih-original-date', dateText);
            $time.attr('data-ih-original-date-key', cacheKey);
            return dateText;
        }

        return null;
    }

    /**
     * setTimeElementDateAndLocaleTime
     * @description Replace time element text with absolute date and localized time.
     *
     * @param  {JQuery}  $time
     * @return {void}
     */
    function setTimeElementDateAndLocaleTime($time) {
        if ($time == null || $time.length === 0) {
            return;
        }

        const datetime = $time.attr('datetime');
        if (!datetime) {
            return;
        }

        const date = new Date(datetime);
        if (Number.isNaN(date.getTime())) {
            return;
        }

        const dateText = getTimeElementBaseDateText($time);
        if (!dateText) {
            return;
        }

        const localeTime = new Intl.DateTimeFormat(undefined, {
            hour: 'numeric',
            minute: '2-digit'
        }).format(date);

        if (!localeTime) {
            return;
        }

        const finalText = `${dateText} ${localeTime}`;

        if ($time.text()?.trim() !== finalText) {
            $time.text(finalText);
            $time.css('white-space', 'break-spaces');
        }
    }

    /**
     * getHighlightCurrentTimeElement
     * @description Get the publish time element in the current highlight view.
     *
     * @param  {JQuery}  $element
     * @return {JQuery}
     */
    function getHighlightCurrentTimeElement($element) {
        if ($element == null || $element.length === 0) {
            $element = $body;
        }

        let $section = $element.closest('section:visible');
        if ($section.length === 0) {
            $section = $('body > div section:visible').last();
        }

        if ($section.length === 0) {
            return $();
        }

        let $times = $section.find('time[datetime]').filter(function () {
            const $time = $(this);

            return (
                $time.is(':visible') &&
                $time.closest('a[href^="/stories/highlights/"]').length === 0 &&
                $time.closest('[role="button"]').length === 0
            );
        });

        if ($times.length === 0) {
            return $();
        }

        return $times.first();
    }

    /**
     * updateLoadingBar
     * @description Update loading state.
     *
     * @param  {Boolean}  isLoading - Check if loading state
     * @return {void}
     */
    function updateLoadingBar(isLoading) {
        // OPTIMIZATION: cache the mount root selection (called every time)
        const $mountDiv = $('div[id^="mount"] > div > div > div:first');
        if (isLoading) {
            $mountDiv.removeClass('x1s85apg');
            $mountDiv.css('z-index', '20000');
        }
        else {
            $mountDiv.addClass('x1s85apg');
            $mountDiv.css('z-index', '');
        }
    }

    /**
     * getStoryProgress
     * @description Get the story progress of the username (post several stories).
     *
     * @param  {String}  username - Get progress of username
     * @return {Object}
     */
    function getStoryProgress(username) {
        const lowerUsername = username?.toLowerCase();
        let $header = $('body > div section:visible a[href^="/' + (username) + '"] span').filter(function () {
            const $this = $(this);
            return $this.children().length === 0 && $this.find('svg').length === 0 && $this.text()?.toLowerCase() === lowerUsername;
        }).parents('div:not([class]):not([style])').filter(function () {
            return $(this).text()?.toLowerCase() !== lowerUsername
        }).filter(function () {
            return $(this).children().length > 1
        }).first();

        if ($header.length === 0) {
            $header = $('body > div section:visible a[href^="/' + (username) + '"]').filter(function () {
                return $(this).find('img').length > 0
            }).parents('div:not([class]):not([style])').filter(function () {
                return $(this).text()?.toLowerCase() !== lowerUsername
            }).filter(function () {
                return $(this).children().length > 1
            }).first();
        }

        return $header.children().filter(function () {
            return $(this).height() < 10
        }).first().children();
    }

    /**
     * getStoryProgressIndex
     * @description Get the current story index and total count from Instagram's progress bar.
     *
     * @param  {Object}  $header - Progress bar items returned by getStoryProgress
     * @return {?Object}
     */
    function getStoryProgressIndex($header) {
        let current = 0;
        let total = $header.length;

        if (total === 0) {
            return null;
        }

        $header.each(function (index) {
            if ($(this).children().length > 0) {
                current = index + 1;
            }
        });

        if (current === 0) {
            return null;
        }

        return { current, total };
    }

    /**
     * setStoryProgressIndexText
     * @description Render the current story index and total count.
     *
     * @param  {Object}  $element - Element to append the counter to
     * @param  {Object}  $header - Progress bar items returned by getStoryProgress
     * @param  {String}  className - Counter class name
     * @return {void}
     */
    function setStoryProgressIndexText($element, $header, className) {
        let progress = getStoryProgressIndex($header);
        let $counter = $element.find('.' + className).first();

        if (progress == null || progress.total < 2) {
            if ($counter.length > 0) {
                $counter.remove();
            }
            return;
        }

        let text = progress.current + '/' + progress.total;
        let title = _i18n('ITEM_POSITION')
            .replace('%CURRENT%', progress.current)
            .replace('%TOTAL%', progress.total);

        if ($counter.length === 0) {
            $counter = $('<div>').addClass(className);
            $element.append($counter);
        }

        if ($counter.text() !== text) {
            $counter.text(text);
        }

        if ($counter.attr('title') !== title) {
            $counter.attr('title', title);
        }

        if ($counter.attr('aria-label') !== title) {
            $counter.attr('aria-label', title);
        }
    }

    /**
     * setStoryProgressIndexByUsername
     * @description Render current story index and total count from a username.
     *
     * @param  {Object}  $element - Element to append the counter to
     * @param  {String}  username - Story owner's username
     * @param  {String}  className - Counter class name
     * @return {void}
     */
    function setStoryProgressIndexByUsername($element, username, className) {
        if ($element == null || $element.length === 0 || username == null) {
            return;
        }

        let $header = getStoryProgress(username);
        setStoryProgressIndexText($element, $header, className);
    }

    /**
     * setDownloadProgress
     * @description Show and set download circle progress.
     *
     * @param  {Integer}  now
     * @param  {Integer}  total
     * @return {Void}
     */
    function setDownloadProgress(now, total) {
        // OPTIMIZATION: cache the circle wrapper lookup
        const $circle = $('.circle_wrapper');
        if ($circle.length) {
            $circle.find('span').text(`${now}/${total}`);

            if (now >= total) {
                $circle.fadeOut(250, function () {
                    $(this).remove();
                });
            }
        }
        else {
            $body.append(`<div class="circle_wrapper"><circle></circle><span>${now}/${total}</span></div>`);
        }
    }

    /**
     * saveFiles
     * @description Download the specified media URL to the computer.
     *
     * @param  {String}  downloadLink
     * @param  {Object}  metadata
     * @param  {String}  metadata.username
     * @param  {String}  metadata.sourceType
     * @param  {Integer}  metadata.timestamp
     * @param  {String}  metadata.filetype
     * @param  {String}  metadata.shortcode
     * @param  {Integer|null}  metadata.index
     * @param  {String|null}  metadata.uid
     * @return {Promise}
     */
    function saveFiles(downloadLink, metadata) {
        return new Promise((resolve) => {
            setTimeout(() => {
                updateLoadingBar(true);
                fetch(downloadLink)
                    .then(res => res.blob())
                    .then(dwel => {
                        updateLoadingBar(false);
                        return createSaveFileElement(downloadLink, dwel, metadata);
                    })
                    .then(() => resolve(true))
                    .catch(err => {
                        updateLoadingBar(false);
                        console.error('saveFiles failed:', err);
                        resolve(false);
                    });
            }, 50);
        });
    }

    /**
     * fetchArrayBuffer
     * @description Download URL as ArrayBuffer.
     *
     * @param {string} url
     * @return {Promise<ArrayBuffer>}
     */
    async function fetchArrayBuffer(url) {
        updateLoadingBar(true);
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return await res.arrayBuffer();
        } finally {
            updateLoadingBar(false);
        }
    }

    /**
     * parseDashManifest
     * @description Parse Media API video_dash_manifest (MPD XML).
     *              Returns best video/audio representation URLs.
     *
     * @param  {string} mpdXml
     * @return {{ video: any|null, audio: any|null }}
     */
    function parseDashManifest(mpdXml) {
        try {
            if (!mpdXml || typeof mpdXml !== 'string') return { video: null, audio: null };

            const xml = new DOMParser().parseFromString(mpdXml, 'application/xml');
            if (xml.querySelector('parsererror')) return { video: null, audio: null };

            const reps = Array.from(xml.querySelectorAll('Representation'));
            const candidates = reps.map((rep) => {
                const base = rep.querySelector('BaseURL')?.textContent?.trim();
                if (!base) return null;

                const set = rep.closest('AdaptationSet');
                const mimeType = rep.getAttribute('mimeType') || set?.getAttribute('mimeType') || '';
                const contentType = set?.getAttribute('contentType') || '';
                const codecs = rep.getAttribute('codecs') || set?.getAttribute('codecs') || '';
                const bandwidth = parseInt(rep.getAttribute('bandwidth') || '0', 10) || 0;
                const width = parseInt(rep.getAttribute('width') || '0', 10) || 0;
                const height = parseInt(rep.getAttribute('height') || '0', 10) || 0;
                const id = rep.getAttribute('id') || '';

                return { id, url: base, mimeType, contentType, codecs, bandwidth, width, height };
            }).filter(Boolean);

            const isVideo = (c) => ((c.contentType || '').includes('video') || (c.mimeType || '').startsWith('video'));
            const isAudio = (c) => ((c.contentType || '').includes('audio') || (c.mimeType || '').startsWith('audio'));

            const bestVideo = candidates
                .filter(isVideo)
                .sort((a, b) => (b.height - a.height) || (b.bandwidth - a.bandwidth) || (b.width - a.width))[0] || null;

            const bestAudio = candidates
                .filter(isAudio)
                .sort((a, b) => (b.bandwidth - a.bandwidth))[0] || null;

            return { video: bestVideo, audio: bestAudio };
        } catch (e) {
            logger('[DASH]', 'parseDashManifest() error:', e);
            return { video: null, audio: null };
        }
    }

    /**
     * muxDashVideoAudioToMp4
     * @description Mux DASH video+audio into one MP4 using Mediabunny (demux + mux).
     *
     * @param {ArrayBuffer} videoBuf
     * @param {ArrayBuffer} audioBuf
     * @return {Promise<ArrayBuffer>}
     */
    async function muxDashVideoAudioToMp4(videoBuf, audioBuf) {
        const MB = Mediabunny;

        const videoInput = new MB.Input({
            formats: [MB.MP4],
            source: new MB.BufferSource(videoBuf),
        });
        const audioInput = new MB.Input({
            formats: [MB.MP4],
            source: new MB.BufferSource(audioBuf),
        });

        const vTrack = await videoInput.getPrimaryVideoTrack();
        if (!vTrack || !vTrack.codec) throw new Error('No video track found');

        const aTrack = await audioInput.getPrimaryAudioTrack();
        if (!aTrack || !aTrack.codec) throw new Error('No audio track found');

        const vSink = new MB.EncodedPacketSink(vTrack);
        const aSink = new MB.EncodedPacketSink(aTrack);

        const output = new MB.Output({
            format: new MB.Mp4OutputFormat({ fastStart: 'in-memory' }),
            target: new MB.BufferTarget(),
        });

        const vSource = new MB.EncodedVideoPacketSource(vTrack.codec);
        const aSource = new MB.EncodedAudioPacketSource(aTrack.codec);

        output.addVideoTrack(vSource, { rotation: vTrack.rotation || 0 });
        output.addAudioTrack(aSource);

        await output.start();

        const vDecoderConfig = await vTrack.getDecoderConfig();
        const aDecoderConfig = await aTrack.getDecoderConfig();

        const vMeta = vDecoderConfig ? { decoderConfig: vDecoderConfig } : undefined;
        const aMeta = aDecoderConfig ? { decoderConfig: aDecoderConfig } : undefined;

        const vIter = vSink.packets();
        const aIter = aSink.packets();

        let vNext = await vIter.next();
        let aNext = await aIter.next();
        let vSentMeta = false;
        let aSentMeta = false;

        while (!vNext.done || !aNext.done) {
            const takeVideo = (() => {
                if (vNext.done) return false;
                if (aNext.done) return true;
                return vNext.value.timestamp <= aNext.value.timestamp;
            })();

            if (takeVideo) {
                await vSource.add(vNext.value, vSentMeta ? undefined : vMeta);
                vSentMeta = true;
                vNext = await vIter.next();
            } else {
                await aSource.add(aNext.value, aSentMeta ? undefined : aMeta);
                aSentMeta = true;
                aNext = await aIter.next();
            }
        }

        await output.finalize();

        const outBuf = output.target.buffer;
        if (outBuf instanceof ArrayBuffer) return outBuf;
        if (outBuf && outBuf.buffer) {
            return outBuf.buffer.slice(outBuf.byteOffset, outBuf.byteOffset + outBuf.byteLength);
        }
        throw new Error('Unexpected output buffer type');
    }

    async function downloadDashStreams(videoUrl, audioUrl, username, sourceType, timestamp, shortcode) {
        logger('[DASH]', 'downloadDashStreams()', {
            videoUrl: videoUrl,
            audioUrl: audioUrl || null,
            sourceType,
            shortcode
        });

        if (!audioUrl) {
            logger('[DASH]', 'Downloaded DASH video only (no audio rep / has_audio=false).');
            await saveFiles(videoUrl, {
                username,
                sourceType,
                timestamp,
                filetype: 'mp4',
                shortcode
            });
            return true;
        }

        try {
            logger('[DASH]', 'Fetching DASH streams for mux...');
            const [vBuf, aBuf] = await Promise.all([
                fetchArrayBuffer(videoUrl),
                fetchArrayBuffer(audioUrl)
            ]);

            logger('[DASH]', 'Muxing DASH video+audio into one MP4 (mp4box main thread)...');
            const mergedBuf = await muxDashVideoAudioToMp4(vBuf, aBuf);
            const mergedBlob = new Blob([mergedBuf], { type: 'video/mp4' });

            await createSaveFileElement(videoUrl, mergedBlob, { username, sourceType, timestamp, filetype: 'mp4', shortcode });
            logger('[DASH]', 'Merged MP4 download triggered.');
            return true;
        } catch (e) {
            logger('[DASH]', 'Mux failed -> fallback to separate downloads', e?.message || e);
            await saveFiles(videoUrl, {
                username,
                sourceType,
                timestamp,
                filetype: 'mp4',
                shortcode
            });
            await saveFiles(audioUrl, {
                username,
                sourceType,
                timestamp,
                filetype: 'm4a',
                shortcode
            });
            return true;
        }
    }

    /**
     * tryHandleDashFromMediaItem
     * @description Centralized DASH handling for Media API items.
     *              Uses video_dash_manifest when present.
     *              Picks best video by resolution (height/width), then bandwidth.
     *              Audio is optional.
     *
     * @return {Promise<boolean>} true if DASH path handled it, false to let caller fallback.
     */
    async function tryHandleDashFromMediaItem({
        mediaItem,
        username,
        sourceType,
        timestamp,
        shortcode,
        isPreview,
        index
    }) {
        try {
            if (!USER_SETTING.PREFER_DASH_MANIFEST) return false;
            if (!USER_SETTING.FORCE_RESOURCE_VIA_MEDIA) return false;
            if (!mediaItem?.video_dash_manifest) return false;
            if (!mediaItem?.video_versions) return false;

            const best = parseDashManifest(mediaItem.video_dash_manifest);
            const vUrl = best?.video?.url || '';
            const aUrl = best?.audio?.url || '';

            if (!vUrl) {
                return false;
            }

            logger('[DASH]', 'best reps selected', {
                video: best.video ? { height: best.video.height, width: best.video.width, bandwidth: best.video.bandwidth, codecs: best.video.codecs } : null,
                audio: best.audio ? { bandwidth: best.audio.bandwidth, codecs: best.audio.codecs } : '(none)'
            });

            if (isPreview) {
                openNewTab(vUrl);
                return true;
            }

            if (!aUrl) {
                logger('[DASH]', 'download mode -> VIDEO-ONLY DASH (no audio rep)');
                await saveFiles(vUrl, {
                    username,
                    sourceType,
                    timestamp,
                    filetype: 'mp4',
                    shortcode,
                    index
                });
                return true;
            }

            logger('[DASH]', 'download mode -> DASH video+audio');
            await downloadDashStreams(vUrl, aUrl, username, sourceType, timestamp, shortcode);
            return true;
        } catch (e) {
            logger('[DASH]', 'tryHandleDashFromMediaItem failed -> fallback', e?.message || e);
            return false;
        }
    }

    /**
     * triggerDownload
     * @description Trigger download from Blob with filename.
     * 
     * @param {Blob} blob
     * @param {string} filename
     */
    function triggerDownload(blob, filename) {
        return new Promise((resolve) => {
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = filename;
            link.rel = "noopener";
            link.style.display = "none";
            document.body.appendChild(link);
            link.click();
            setTimeout(() => {
                // eslint-disable-next-line no-unused-vars
                try { document.body.removeChild(link); } catch (e) { /* noop */ }
                URL.revokeObjectURL(url);
                resolve();
            }, 250);
        });
    }

    /**
     * getSaveFileName
     * @description Get the file name for downloaded media according to the user settings and resource information.
     *
     * @param  {String}  downloadLink
     * @param  {Object}  metadata
     * @param  {String}  metadata.username
     * @param  {String}  metadata.sourceType
     * @param  {Integer}  metadata.timestamp
     * @param  {String}  metadata.filetype
     * @param  {String}  metadata.shortcode
     * @param  {Integer|null}  metadata.index
     * @param  {String|null}  metadata.uid
     * @return {String}  The generated filename
     */
    function getSaveFileName(downloadLink, metadata) {
        let { username, sourceType, timestamp, filetype, shortcode, index, uid } = metadata;
        timestamp = parseInt(timestamp.toString().padEnd(13, '0'));
        index = (index != null) ? index : 0;

        const date = new Date(timestamp);

        const original_name = new URL(downloadLink).pathname.split('/').at(-1).split('.').slice(0, -1).join('.');
        const year = date.getFullYear().toString();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        const hour = date.getHours().toString().padStart(2, '0');
        const minute = date.getMinutes().toString().padStart(2, '0');
        const second = date.getSeconds().toString().padStart(2, '0');

        var filename = state.fileRenameFormat.replace(/%([^%]+)%/g, (match, content) => {
            return `%${content.toUpperCase()}%`;
        });

        var replacements = {
            '%USERNAME%': username,
            '%SOURCE_TYPE%': sourceType,
            '%SHORTCODE%': shortcode || '',
            '%YEAR%': year,
            '%2-YEAR%': year.substr(-2),
            '%MONTH%': month,
            '%DAY%': day,
            '%HOUR%': hour,
            '%MINUTE%': minute,
            '%SECOND%': second,
            '%ORIGINAL_NAME%': original_name,
            '%ORIGINAL_NAME_FIRST%': original_name.split('_').at(0),
            '%INDEX%': index.toString(),
            '%UID%': uid || '',
        };

        // eslint-disable-next-line no-useless-escape
        filename = filename.replace(/%[\w\-]+%/g, function (str) {
            if (replacements[str] == null) {
                return str;
            }

            return replacements[str];
        });

        const originally = username + '_' + original_name + '.' + filetype;
        const downloadName = USER_SETTING.AUTO_RENAME ? filename + '.' + filetype : originally;

        return downloadName;
    }


    /**
     * createSaveFileElement
     * @description Download the specified media with link element.
     *
     * @param  {String}  downloadLink
     * @param  {Object}  object
     * @param  {Object}  metadata
     * @param  {String}  metadata.username
     * @param  {String}  metadata.sourceType
     * @param  {Integer}  metadata.timestamp
     * @param  {String}  metadata.filetype
     * @param  {String}  metadata.shortcode
     * @param  {Integer|null}  metadata.index
     * @param  {String|null}  metadata.uid
     * @return {void}
     */
    async function createSaveFileElement(downloadLink, object, metadata) {
        let { username, sourceType, filetype, shortcode } = metadata;

        if (metadata.uid == null && username) {
            if (!userIdCache.has(username)) {
                userIdCache.set(username, getUserId(username));
            }

            try {
                const userInfo = await userIdCache.get(username);
                metadata.uid = userInfo?.user?.id || null;
                // eslint-disable-next-line no-unused-vars
            } catch (err) {
                userIdCache.delete(username);
                metadata.uid = null;
            }
        }

        const downloadName = getSaveFileName(downloadLink, metadata);

        if (
            USER_SETTING.MODIFY_RESOURCE_EXIF &&
            filetype === 'jpg' &&
            shortcode &&
            sourceType === 'photo' &&
            (object.type === 'image/jpeg' || object.type === 'image/webp')
        ) {
            try {
                const newBlob = await changeExifData(object, metadata);
                await triggerDownload(newBlob, downloadName);
            } catch (err) {
                console.error('Failed to strip EXIF and/or attach post URL to EXIF.', err);
                await triggerDownload(object, downloadName);
            }
        } else {
            await triggerDownload(object, downloadName);
        }
    }

    /**
     * changeExifData
     * @description Strips EXIF metadata and attaches post URLs to the EXIF of downloaded image resources.
     *
     * @param  {Object}  blob
     * @param  {Object}  metadata
     * @param  {String}  metadata.username
     * @param  {String}  metadata.sourceType
     * @param  {Integer}  metadata.timestamp
     * @param  {String}  metadata.filetype
     * @param  {String}  metadata.shortcode
     * @param  {Integer|null}  metadata.index
     * @param  {String}  metadata.uid
     * @return {Blob}
     */
    async function changeExifData(blob, metadata) {
        const concat = (...arr) => {
            const len = arr.reduce((s, a) => s + a.length, 0);
            const out = new Uint8Array(len);
            let p = 0;
            for (const a of arr) {
                out.set(a, p);
                p += a.length;
            }
            return out;
        };
        const u32le = v => {
            const b = new Uint8Array(4);
            new DataView(b.buffer).setUint32(0, v, true);
            return b;
        };
        const u16le = v => {
            const b = new Uint8Array(2);
            new DataView(b.buffer).setUint16(0, v, true);
            return b;
        };
        const enc = s => new TextEncoder().encode(s);
        const encUtf16le = s => {
            const out = new Uint8Array(s.length * 2);
            for (let i = 0; i < s.length; i++) {
                const code = s.charCodeAt(i);
                out[i * 2] = code & 0xFF;
                out[i * 2 + 1] = (code >> 8) & 0xFF;
            }
            return out;
        };
        const formatExifDate = ts => {
            let parsed = Number(ts);
            if (!Number.isFinite(parsed)) {
                parsed = Date.now();
            }
            if (parsed < 1e12) {
                parsed *= 1000;
            }

            const date = new Date(parsed);
            if (Number.isNaN(date.getTime())) {
                return '1970:01:01 00:00:00';
            }

            const y = String(date.getFullYear()).padStart(4, '0');
            const m = String(date.getMonth() + 1).padStart(2, '0');
            const d = String(date.getDate()).padStart(2, '0');
            const hh = String(date.getHours()).padStart(2, '0');
            const mm = String(date.getMinutes()).padStart(2, '0');
            const ss = String(date.getSeconds()).padStart(2, '0');
            return `${y}:${m}:${d} ${hh}:${mm}:${ss}`;
        };
        const makeIFDEntry = (tag, type, count, valueOrOffset) =>
            concat(u16le(tag), u16le(type), u32le(count), u32le(valueOrOffset));
        const fourCC = (dv, o) =>
            String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));

        const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
        const isJPEG = head[0] === 0xFF && head[1] === 0xD8;
        const isWEBP = head.length >= 12 &&
            String.fromCharCode(...head.subarray(0, 4)) === 'RIFF' &&
            String.fromCharCode(...head.subarray(8, 12)) === 'WEBP';
        if (!isJPEG && !isWEBP) throw new Error('Not a JPEG or WEBP');

        const exifDateString = `${formatExifDate(metadata.timestamp)}\0`;
        const username = `${(metadata.username || 'unknown').toString()}\0`;
        const url = `https://www.instagram.com/p/${metadata.shortcode}/`;
        const commentUrl = `https://www.instagram.com/uid/${metadata.uid || 'unknown'}`;

        const dateBytes = enc(exifDateString);
        const artistBytes = enc(username);
        const keywordBytes = encUtf16le(`${url}\0`);
        const xpCommentBytes = encUtf16le(`${commentUrl}\0`);

        const exifPrefix = enc('Exif\0\0');
        const tiffHeader = Uint8Array.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00]);

        const ifd0Count = 4;
        const exifIfdCount = 1;

        const ifd0Size = 2 + (ifd0Count * 12) + 4;
        const exifIfdOffset = 8 + ifd0Size;
        const exifIfdSize = 2 + (exifIfdCount * 12) + 4;
        const dataStartOffset = 8 + ifd0Size + exifIfdSize;

        const artistOffset = dataStartOffset;
        const keywordOffset = artistOffset + artistBytes.length;
        const xpCommentOffset = keywordOffset + keywordBytes.length;
        const dateOffset = xpCommentOffset + xpCommentBytes.length;

        const ifd0 = concat(
            u16le(ifd0Count),
            makeIFDEntry(0x013B, 2, artistBytes.length, artistOffset),                 // Artist
            makeIFDEntry(0x8769, 4, 1, exifIfdOffset),                                 // Exif Offset
            makeIFDEntry(0x9C9C, 1, xpCommentBytes.length, xpCommentOffset),           // XPComment
            makeIFDEntry(0x9C9E, 1, keywordBytes.length, keywordOffset),               // XPKeywords
            u32le(0)
        );

        const exifIfd = concat(
            u16le(exifIfdCount),
            makeIFDEntry(0x9003, 2, dateBytes.length, dateOffset),
            u32le(0)
        );

        const tiffBody = concat(tiffHeader, ifd0, exifIfd, artistBytes, keywordBytes, xpCommentBytes, dateBytes);

        if (isJPEG) {
            const ab = await blob.arrayBuffer();
            const dv = new DataView(ab);
            const app1Body = concat(exifPrefix, tiffBody);
            const app1Header = new Uint8Array(4);
            new DataView(app1Header.buffer).setUint16(0, 0xFFE1);
            new DataView(app1Header.buffer).setUint16(2, app1Body.length + 2);
            const newAPP1 = concat(app1Header, app1Body);

            const parts = [new Uint8Array(ab, 0, 2)];
            let off = 2,
                added = false;
            while (off < dv.byteLength) {
                const marker = dv.getUint16(off);
                if ((marker & 0xFF00) !== 0xFF00) break;
                if (marker === 0xFFDA) {
                    if (!added) parts.push(newAPP1);
                    parts.push(new Uint8Array(ab, off));
                    break;
                }
                const len = dv.getUint16(off + 2) + 2;
                if (marker === 0xFFE1) {
                    off += len;
                    continue;
                }
                parts.push(new Uint8Array(ab, off, len));
                off += len;
            }
            const total = parts.reduce((s, a) => s + a.length, 0);
            const out = new Uint8Array(total);
            let p = 0;
            parts.forEach(a => {
                out.set(a, p);
                p += a.length;
            });
            return new Blob([out], {
                type: 'image/jpeg'
            });
        }

        const ab = await blob.arrayBuffer();
        const dv = new DataView(ab);
        const chunks = [];
        let vp8xIdx = -1;
        let offset = 12;
        while (offset < dv.byteLength) {
            const cc = fourCC(dv, offset);
            const sz = dv.getUint32(offset + 4, true);
            const pad = sz & 1;
            const full = 8 + sz + pad;
            if (cc !== 'EXIF' && cc !== 'XMP ') {
                chunks.push(new Uint8Array(ab, offset, full));
                if (cc === 'VP8X') vp8xIdx = chunks.length - 1;
            }
            offset += full;
        }
        let exifChunk = concat(
            enc('EXIF'),
            u32le(exifPrefix.length + tiffBody.length),
            exifPrefix,
            tiffBody
        );
        if (exifChunk.length & 1) exifChunk = concat(exifChunk, Uint8Array.of(0));
        if (vp8xIdx !== -1) {
            const vp8x = new Uint8Array(chunks[vp8xIdx]);
            vp8x[8] |= 0x10;
            chunks[vp8xIdx] = vp8x;
            chunks.splice(vp8xIdx + 1, 0, exifChunk);
        } else {
            chunks.push(exifChunk);
        }
        const payload = chunks.reduce((s, c) => s + c.length, 0);
        const riffHeader = concat(enc('RIFF'), u32le(payload + 4), enc('WEBP'));
        const finalBuf = concat(riffHeader, ...chunks);
        return new Blob([finalBuf], {
            type: 'image/webp'
        });
    }

    /**
     * triggerLinkElement
     * @description Trigger the link element to start downloading or previewing the resource.
     *
     * @param  {Object}   element     - The element containing resource link metadata.
     * @param  {Boolean}  [isPreview] - True to preview in a new tab instead of downloading.
     * @return {void}
     */
    async function triggerLinkElement($element, isPreview = false) {
        try {
            const $el = $($element);

            let date = new Date().getTime();
            let timestamp = Math.floor(date / 1000);
            let username = $el.data('username') ? $el.data('username') : state.GLusername;
            let index = parseInt($el.attr('data-globalindex') || 0, 10) || 0;

            if (!username && $el.data('path')) {
                logger('catching owner name from shortcode', $el.data('href'));
                username = await getPostOwner($el.data('path')).catch(err => {
                    logger('get username failed, replace with default string, error message', err?.message);
                    return null;
                });
            }

            if (username == null) username = 'NONE';

            if (USER_SETTING.RENAME_PUBLISH_DATE && $el.attr('datetime')) {
                timestamp = parseInt($el.attr('datetime'), 10) || timestamp;
            }

            const mediaId = $el.attr('media-id') || $el.attr('data-media-id') || null;
            const sourceType = $el.data('name');
            const filetype = $el.data('type') || 'jpg';
            const shortcode = $el.data('path');
            const href = $el.data('href');

            const downloadOnly = !isPreview;

            if (!isPreview && index < 0) {
                alert(_i18n('NO_CHECK_RESOURCE'));
                return;
            }

            if (USER_SETTING.PREFER_DASH_MANIFEST && state.GL_mediaDataCache[mediaId]) {
                logger('Video Dash Stream, Processing video with DASH manifest', 'mediaId', mediaId);

                const handled = await tryHandleDashFromMediaItem(
                    state.GL_mediaDataCache[mediaId],
                    username,
                    sourceType,
                    timestamp,
                    shortcode,
                    downloadOnly ? false : isPreview,
                    index
                );

                if (handled) return;
            }

            if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                const cached = getImageFromCache(mediaId);

                if (cached && filetype !== 'mp4') {
                    if (!downloadOnly && isPreview) {
                        openNewTab(cached);
                    } else {
                        await saveFiles(cached, {
                            username,
                            sourceType,
                            timestamp,
                            filetype: filetype || 'jpg',
                            shortcode,
                            index
                        });
                    }
                    return;
                }
            }

            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && mediaId) {
                updateLoadingBar(true);
                let result = await getMediaInfo(mediaId);
                updateLoadingBar(false);

                if (result?.status === 'ok') {
                    let resource_url = null;
                    // OPTIMIZATION: cache result.items[0]
                    const mediaItem = result.items?.[0];

                    if (mediaItem?.video_versions?.length) {
                        resource_url = mediaItem.video_versions[0].url;
                    } else if (mediaItem?.image_versions2?.candidates?.length) {
                        mediaItem.image_versions2.candidates.sort(function (a, b) {
                            let aSTP = new URL(a.url).searchParams.get('stp');
                            let bSTP = new URL(b.url).searchParams.get('stp');

                            if (aSTP && bSTP) {
                                if (aSTP.length > bSTP.length) return 1;
                                if (aSTP.length < bSTP.length) return -1;
                            } else {
                                if ((a.width || 0) > (b.width || 0)) return 1;
                                if ((a.width || 0) < (b.width || 0)) return -1;
                            }

                            return 0;
                        });

                        resource_url = mediaItem.image_versions2.candidates[0].url;
                    }

                    if (!resource_url) {
                        alert('Cannot find download URL.');
                        return;
                    }

                    if (!downloadOnly && isPreview) {
                        openNewTab(replaceSameOriginHost(resource_url));
                    } else {
                        await saveFiles(resource_url, {
                            username,
                            sourceType,
                            timestamp,
                            filetype,
                            shortcode,
                            index
                        });
                    }
                    return;
                }

                if (USER_SETTING.FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED && href) {
                    if (!downloadOnly && isPreview) {
                        openNewTab(replaceSameOriginHost(href));
                    } else {
                        await saveFiles(href, {
                            username,
                            sourceType,
                            timestamp,
                            filetype,
                            shortcode,
                            index
                        });
                    }
                    return;
                }

                alert(`Fetch failed from Media API. API response message: ${result?.message}`);
                logger(result);
                return;
            }

            if (href) {
                if (!downloadOnly && isPreview) {
                    openNewTab(replaceSameOriginHost(href));
                } else {
                    await saveFiles(href, {
                        username,
                        sourceType,
                        timestamp,
                        filetype,
                        shortcode,
                        index
                    });
                }
                return;
            }

            alert('Cannot find download URL.');
        } catch (err) {
            console.error('Occur error in triggerLinkElement:', err);
            logger('Occur error in triggerLinkElement:', err);
        }
    }

    /**
     * replaceSameOriginHost
     * @description Replace the host of the URL to bypass the same-origin policy for certain video resources that cannot be downloaded directly.
     *
     * @param  {string}  url
     * @return {string}
     */
    function replaceSameOriginHost(url) {
        // replace https://instagram.ftpe8-2.fna.fbcdn.net/ to https://scontent.cdninstagram.com/ becase of same origin policy (some video)
        var urlObj = new URL(url);
        urlObj.host = 'scontent.cdninstagram.com';

        return urlObj.href;
    }

    /**
     * checkingScriptUpdate
     * @description Check if there is a new version of the script and push notification.
     *
     * @param  {Integer}  interval
     * @return {void}
     */
    function checkingScriptUpdate(interval) {
        if (!USER_SETTING.CHECK_FOR_UPDATE) return;

        const check_timestamp = GM_getValue('G_CHECK_TIMESTAMP') ?? new Date().getTime();
        const now_time = new Date().getTime();

        if (now_time > (parseInt(check_timestamp) + (interval * 1000))) {
            GM_setValue('G_CHECK_TIMESTAMP', new Date().getTime());
            callNotification();
        }
    }

    /**
     * callNotification
     * @description Call desktop notification by browser.
     *
     * @return {void}
     */
    function callNotification() {
        const currentVersion = GM_info.script.version;
        const remoteScriptURL = 'https://raw.githubusercontent.com/SN-Koarashi/ig-helper/refs/heads/master/main.js';

        GM_xmlhttpRequest({
            method: "GET",
            url: remoteScriptURL,
            onload: function (response) {
                const remoteScript = response.responseText;
                const match = remoteScript.match(/\/\/\s+@version\s+([0-9.\-a-zA-Z]+)/i);

                if (match && match[1]) {
                    const remoteVersion = match[1];
                    logger('Current version: ', currentVersion, '|', 'Remote version: ', remoteVersion);

                    if (remoteVersion !== currentVersion) {
                        GM_notification({
                            text: _i18n("NOTICE_UPDATE_CONTENT"),
                            title: _i18n("NOTICE_UPDATE_TITLE"),
                            tag: 'ig_helper_notice',
                            highlight: true,
                            timeout: 5000,
                            zombieTimeout: 5000,
                            image: "https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://www.instagram.com&size=64",
                            onclick: (event) => {
                                event?.preventDefault();
                                var w = GM_openInTab(GM_info.script.downloadURL);
                                setTimeout(() => {
                                    w.close();
                                }, 250);
                            }
                        });
                    } else {
                        logger('there is no new update');
                    }
                } else {
                    console.error('Could not find version in the remote script.');
                }
            }
        });
    }

    /**
     * openNewTab
     * @description Open URL in new tab.
     *
     * @param  {String}  link
     * @return {void}
     */
    function openNewTab(link) {
        var a = document.createElement('a');
        a.href = link;
        a.target = '_blank';

        document.body.appendChild(a);
        a.click();
        a.remove();

        setTimeout(() => { updateLoadingBar(false); }, 125);
    }

    /**
     * reloadScript
     * @description Re-register main timer.
     *
     * @return {void}
     */
    function reloadScript() {
        clearInterval(state.GL_repeat);

        // OPTIMIZATION: use cached $body and combine .off() calls
        $body.off('.igHelperPost');
        state.bodyEventsRegistered = false;

        $('.button_wrapper').remove();
        $('.IG_DWPROFILE, .IG_DWPROFILE, .IG_DWSTORY, .IG_DWSTORY_ALL, .IG_DWSTORY_THUMBNAIL, .IG_DWSTORY_POSITION, .IG_DWNEWTAB, .IG_DWHISTORY, .IG_DWHISTORY_ALL, .IG_DWHINEWTAB, .IG_DWHISTORY_THUMBNAIL, .IG_DWHISTORY_POSITION, .IG_REELS, .IG_REELS_NEWTAB, .IG_REELS_THUMBNAIL').remove();
        $('[data-snig]').removeAttr('data-snig');

        state.pageLoaded = false;
        state.firstStarted = false;
        state.currentURL = location.href;
        state.GL_observer?.disconnect();

        logger('main timer re-register completed');
    }

    /**
     * logger
     * @description Event record.
     *
     * @return {void}
     */
    function logger(...messages) {
        var dd = new Date();
        state.GL_logger.push({
            time: dd.getTime(),
            content: [...messages]
        });

        if (state.GL_logger.length > 1000) {
            state.GL_logger = [{
                time: dd.getTime(),
                content: ['logger sliced']
            }, ...state.GL_logger.slice(-999)];
        }

        console.log(`[${dd.toISOString()}]`, ...messages);
    }

    /**
     * initSettings
     * @description Initialize preferences.
     *
     * @return {void}
     */
    function initSettings() {
        for (let name in USER_SETTING) {
            if (GM_getValue(name) != null && typeof GM_getValue(name) === 'boolean') {
                USER_SETTING[name] = GM_getValue(name);

                if (name === "MODIFY_VIDEO_VOLUME" && GM_getValue(name) !== true) {
                    state.videoVolume = 1;
                }
            }
        }
    }


    /**
     * toggleVolumeSilder
     * @description Toggle display of custom volume slider.
     *
     * @param  {object}  $videos
     * @param  {object}  $buttonParent
     * @param  {string}  loggerType
     * @param  {string}  customClass
     * @return {void}
     */
    function toggleVolumeSilder($videos, $buttonParent, loggerType, customClass = "") {
        // OPTIMIZATION: cache the volume_slider lookup
        let $existingSlider = $buttonParent.find('div.volume_slider');
        if ($existingSlider.length === 0) {
            $buttonParent.append(`<div class="volume_slider ${customClass}" />`);
            const $newSlider = $buttonParent.find('div.volume_slider');
            $newSlider.append(`<div><input type="range" max="1" min="0" step="0.05" value="${state.videoVolume}" /></div>`);
            const $sliderInput = $newSlider.find('input');
            $sliderInput.attr('style', `--ig-track-progress: ${(state.videoVolume * 100) + '%'}`);
            $sliderInput.on('input', function () {
                const $this = $(this);
                var percent = ($this.val() * 100) + '%';

                state.videoVolume = $this.val();
                GM_setValue('G_VIDEO_VOLUME', $this.val());

                $this.attr('style', `--ig-track-progress: ${percent}`);

                $videos.each(function () {
                    logger(`(${loggerType})`, 'video volume changed #slider');
                    this.volume = state.videoVolume;
                });
            });

            $sliderInput.on('mouseenter', function () {
                const $this = $(this);
                var percent = (state.videoVolume * 100) + '%';
                $this.attr('style', `--ig-track-progress: ${percent}`);
                $this.val(state.videoVolume);


                $videos.each(function () {
                    logger(`(${loggerType})`, 'video volume changed #slider');
                    this.volume = state.videoVolume;
                });
            });

            $newSlider.on('click', function (e) {
                e.stopPropagation();
                e.preventDefault();
            });
        }
        else {
            $existingSlider.remove();
        }
    }

    /**
     * @description Trigger React onClick event handler for the given element.
     * @param {HTMLElement} el 
     */
    function triggerReactClickHandler(el) {
        const reactKey = Object.keys(el).find(k => k.startsWith('__reactProps') || k.startsWith('__reactEventHandlers'));
        const props = el[reactKey];

        if (props && typeof props.onClick === 'function') {
            const mockEvent = {
                target: el,
                currentTarget: el,
                preventDefault: () => { },
                stopPropagation: () => { },
                nativeEvent: new MouseEvent('click')
            };

            props.onClick(mockEvent);
        } else {
            logger('No React click handler found for the element:', el);
        }
    };

    // /**
    //  * @description Get the element at the pointer position and check if it is the target element or if it is covered by another element.
    //  * @param {JQuery<HTMLElement>} $target 
    //  * @param {number} clientX
    //  * @param {number} clientY
    //  */
    // export function getPointerElement($target, clientX, clientY) {
    //     let element = $target.get(0);
    //     const rect = element.getBoundingClientRect();

    //     const viewportWidth = window.innerWidth;
    //     const viewportHeight = window.innerHeight;

    //     const visibleX = Math.max(rect.left, 0) + (Math.min(rect.right, viewportWidth) - Math.max(rect.left, 0)) / 2;
    //     const visibleY = Math.max(rect.top, 0) + (Math.min(rect.bottom, viewportHeight) - Math.max(rect.top, 0)) / 2;

    //     if (visibleX < 0 || visibleX > viewportWidth || visibleY < 0 || visibleY > viewportHeight) {
    //         if (clientX == null || clientY == null) {
    //             return { self: false, topElement: null, target: $target, error: 'out_of_viewport', rect };
    //         }
    //     }

    //     const topElement = document.elementFromPoint(clientX || visibleX, clientY || visibleY);

    //     if ($(topElement).height() > document.body.clientHeight) {
    //         return { self: false, topElement: null, target: $target, error: 'oversize_element', rect };
    //     }

    //     if ($(topElement).width() < 100 || $(topElement).height() < 100) {
    //         return { self: false, topElement: null, target: $target, error: 'small_element', rect };
    //     }

    //     if (topElement && topElement !== element && !element.contains(topElement)) {
    //         if ($(topElement).find($target).length > 0) {
    //             // return { self: false, topElement, target: $target };
    //             return { self: false, topElement: null, target: $target, error: 'covered_by_element', rect };
    //         }

    //         if ($(topElement).width() != $target.width() || $(topElement).height() != $target.height()) {
    //             return { self: false, topElement: null, target: $target, error: 'different_dimensions', rect };
    //         }


    //         // return { self: false, topElement: null, target: $target, error: 'none_of_element', rect };
    //         return { self: false, topElement, target: $target };
    //     } else {
    //         return { self: true, topElement, target: $target };
    //     }
    // }

    /**
     * updatePopupSelectionSummary
     * @description Update selection summary in popup dialog.
     *
     * @param {string|JQuery} root
     * @return {void}
     */
    function updatePopupSelectionSummary(root = '.IG_POPUP_DIG') {
        const $root = (typeof root === 'string') ? $(root) : root;
        if (!$root || $root.length === 0) return;

        const $titleCheckbox = $root.find('.IG_POPUP_DIG_TITLE .checkbox');
        const $countSpan = $titleCheckbox.find('.item-count');
        if ($titleCheckbox.length === 0 || $countSpan.length === 0) return;

        const $items = $root.find('.IG_POPUP_DIG_BODY .inner_box');
        const total = $items.length;
        const selected = $items.filter(':checked').length;

        $titleCheckbox.find('input').prop('checked', total > 0 && selected === total);

        const formatCount = (count, singularKey, pluralKey) => {
            const key = count === 1 ? singularKey : pluralKey;
            const template = _i18n(key);
            return (typeof template === 'string')
                ? template.replace('%COUNT%', count)
                : String(count);
        };

        const totalLabel = formatCount(total, 'ITEM_COUNT_SINGULAR', 'ITEM_COUNT_PLURAL');
        const selectedLabel = formatCount(selected, 'SELECTED_COUNT_SINGULAR', 'SELECTED_COUNT_PLURAL');

        $countSpan.text(` (${selectedLabel} / ${totalLabel})`);
    }

    /**
     * IG_createDM
     * @description A dialog showing a list of all media files in the post.
     *
     * @param  {Boolean}  hasHidden
     * @param  {Boolean}  hasCheckbox
     * @return {void}
     */
    function IG_createDM(hasHidden, hasCheckbox) {
        let isHidden = (hasHidden) ? "hidden" : "";
        $body.append('<div class="IG_POPUP_DIG ' + isHidden + '"><div class="IG_POPUP_DIG_BG"></div><div class="IG_POPUP_DIG_MAIN"><div class="IG_POPUP_DIG_TITLE"></div><div class="IG_POPUP_DIG_BODY"></div></div></div>');
        // OPTIMIZATION: cache popup title element used 3+ times in this function
        const $title = $('.IG_POPUP_DIG .IG_POPUP_DIG_MAIN .IG_POPUP_DIG_TITLE');
        $title.append(`<div style="position:relative;min-height:36px;text-align:center;margin-bottom: 7px;"><div style="position:absolute;left:0px;line-height: 18px;"><kbd>${getPlatformModifierKey()}</kbd>+<kbd>Q</kbd> [<span data-ih-locale="CLOSE">${_i18n("CLOSE")}</span>]</div><div style="line-height: 18px;">IG Helper v${GM_info.script.version}</div><div id="post_info" style="line-height: 14px;font-size:14px;">Post ID: <span id="article-id"></span></div><div class="IG_POPUP_DIG_BTN">${SVG.CLOSE}</div></div>`);

        if (hasCheckbox) {
            $title.append(`<div style="text-align: center;" id="button_group"></div>`);
            const $btnGroup = $title.find('> div#button_group');
            $btnGroup.append(`<button id="batch_download_selected" disabled data-ih-locale="BATCH_DOWNLOAD_SELECTED">${_i18n('BATCH_DOWNLOAD_SELECTED')}</button>`);
            $btnGroup.append(`<button id="batch_download_direct" disabled data-ih-locale="BATCH_DOWNLOAD_DIRECT">${_i18n('BATCH_DOWNLOAD_DIRECT')}</button>`);
            $title.append(`<label class="checkbox"><input value="yes" type="checkbox" /><span data-ih-locale="ALL_CHECK">${_i18n('ALL_CHECK')}</span><span class="item-count"></span></label>`);
        }
    }

    /**
     * IG_setDM
     * @description Set a dialog status.
     *
     * @param  {Boolean}  hasHidden
     * @return {void}
     */
    function IG_setDM(hasHidden) {
        const $popup = $('.IG_POPUP_DIG');
        if ($popup.length) {
            if (hasHidden) {
                $popup.addClass("hidden");
            }
            else {
                $popup.removeClass("hidden");
            }
        }
    }


    /**
     * registerMenuCommand
     * @description Register script menu command.
     *
     * @return {void}
     */
    function registerMenuCommand() {
        for (let id of state.registerMenuIds) {
            logger('GM_unregisterMenuCommand', id);
            GM_unregisterMenuCommand(id);
        }

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('SETTING'), () => {
            showSetting();
        }, {
            accessKey: "w"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('HOTKEY_KEY_SETTINGS_KEY'), () => {
            showHotkeySetting();
        }, {
            accessKey: "q"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('DONATE'), () => {
            GM_openInTab("https://ko-fi.com/snkoarashi", { active: true });
        }, {
            accessKey: "d"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('DEBUG'), () => {
            showDebugDOM();
        }, {
            accessKey: "z"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('FEEDBACK'), () => {
            showFeedbackDOM();
        }, {
            accessKey: "f"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('CHECK_FOR_UPDATE'), () => {
            callNotification();
        }, {
            accessKey: "c"
        }));

        state.registerMenuIds.push(GM_registerMenuCommand(_i18n('RELOAD_SCRIPT'), () => {
            reloadScript();
        }, {
            accessKey: "r"
        }));
    }

    function showHotkeySetting() {
        $('.IG_POPUP_DIG').remove();
        IG_createDM();

        $('.IG_POPUP_DIG #post_info').text('Hotkey Settings');

        const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY');

        const hotkeyOptions = [
            { value: '87', label: 'Alt+W' },
            { value: '90', label: 'Alt+Z' },
            { value: '88', label: 'Alt+X' },
            { value: '68', label: 'Alt+D' },
            { value: '75', label: 'Alt+K' },
            { value: '67', label: 'Alt+C' },
            { value: '83', label: 'Alt+S' },
            { value: '192', label: 'Alt+~' },
            { value: '49', label: 'Alt+1' },
            { value: '50', label: 'Alt+2' },
            { value: '51', label: 'Alt+3' },
            { value: '52', label: 'Alt+4' },
            { value: '53', label: 'Alt+5' }
        ];

        const hotkeyConfigs = [
            { name: 'HOTKEY_SETTINGS', key: 'HOTKEY_SETTINGS_KEY', stateKey: 'settingsHotkeyKeyCode', storageKey: 'G_HOTKEY_SETTINGS_KEYCODE', defaultKeyCode: 87 },
            { name: 'HOTKEY_KEY_SETTINGS', key: 'HOTKEY_KEY_SETTINGS_KEY', stateKey: 'keySettingsHotkeyKeyCode', storageKey: 'G_HOTKEY_KEY_SETTINGS_KEYCODE', defaultKeyCode: 67 },
            { name: 'HOTKEY_DEBUG', key: 'HOTKEY_DEBUG_KEY', stateKey: 'debugHotkeyKeyCode', storageKey: 'G_HOTKEY_DEBUG_KEYCODE', defaultKeyCode: 90 },
            { name: 'HOTKEY_DOWNLOAD_STORY', key: 'HOTKEY_DOWNLOAD_STORY_KEY', stateKey: 'downloadStoryHotkeyKeyCode', storageKey: 'G_HOTKEY_DOWNLOAD_STORY_KEYCODE', defaultKeyCode: 83 },
        ];

        function checkHotkeyConflict(keyCode, excludeStateKey) {
            for (const config of hotkeyConfigs) {
                if (config.stateKey !== excludeStateKey && state[config.stateKey] === keyCode) {
                    return true;
                }
            }
            return false;
        }

        function createHotkeySetting(name, key, stateKey, storageKey, defaultKeyCode) {
            const currentKeyCode = state[stateKey];
            const $container = $(`
                <label class="globalSettings hotkey-setting-item" data-hotkey="${name}" style="position: relative;display: flex; align-items: center; padding-right: 5px;">
                    <span>${_i18n(key)}</span>
                    <div class="hotkey-select-wrapper" style="display: flex; align-items: center; gap: 8px; justify-content: flex-end; flex: 1;">
                        <select class="hotkey-preset" data-storage="${storageKey}" data-state="${stateKey}" data-default="${defaultKeyCode}" style="padding: 4px 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px;">
                            ${hotkeyOptions.filter(o => o.value != defaultKeyCode.toString()).map(o => `<option value="${o.value}" ${o.value == currentKeyCode ? 'selected' : ''}>${o.label}</option>`).join('')}
                            <option value="${defaultKeyCode}" ${currentKeyCode == defaultKeyCode ? 'selected' : ''}>Alt+${String.fromCharCode(defaultKeyCode)}</option>
                        </select>
                        <button class="hotkey-reset" title="${_i18n('HOTKEY_RESET')}" style="padding: 4px 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; color: #1f1f1f; background: #fff; cursor: pointer;">${_i18n('HOTKEY_RESET')}</button>
                    </div>
                    <div class="hotkey-conflict-warning" style="pointer-events: none; position: absolute; bottom: -10px; display: none; font-size: 11px; color: #e74c3c;">▲ ${_i18n('HOTKEY_CONFLICT_WARNING')}</div>
                </label>
            `);

            $container.find('.hotkey-reset').on('click', function () {
                const $preset = $container.find('.hotkey-preset');
                const defaultCode = parseInt($preset.data('default'));
                const stateKeyName = $preset.data('state');
                const storage = $preset.data('storage');

                state[stateKeyName] = defaultCode;
                GM_setValue(storage, defaultCode);
                $preset.val(defaultCode);
                $container.find('.hotkey-conflict-warning').hide();
            });

            $container.find('.hotkey-preset').on('change', function () {
                const $this = $(this);
                const val = $this.val();
                const storage = $this.data('storage');
                const stateKeyName = $this.data('state');
                const defaultCode = parseInt($this.data('default'));
                const keyCode = parseInt(val);

                if (checkHotkeyConflict(keyCode, stateKeyName)) {
                    state[stateKeyName] = defaultCode;
                    GM_setValue(storage, defaultCode);
                    $this.val(defaultCode);
                    $container.find('.hotkey-conflict-warning').show().delay(2000).fadeOut(500);
                } else {
                    state[stateKeyName] = keyCode;
                    GM_setValue(storage, keyCode);
                    $container.find('.hotkey-conflict-warning').hide();
                }
            });

            return $container;
        }

        $popupBody.append('<span style="display: block; margin-bottom: 15px;" class="hotkey-settings-container"></span>');
        const $container = $popupBody.find('.hotkey-settings-container');

        hotkeyConfigs.forEach((config) => {
            $container.append(
                createHotkeySetting(config.name, config.key, config.stateKey, config.storageKey, config.defaultKeyCode)
            );
        });
    }

    /**
     * showSetting
     * @description Show script settings window.
     *
     * @return {void}
     */
    function showSetting() {
        $('.IG_POPUP_DIG').remove();
        IG_createDM();

        $('.IG_POPUP_DIG #post_info').text('Preference Settings');
        $('.IG_POPUP_DIG .IG_POPUP_DIG_TITLE > div')
            .append(`
                <select id="langSelect"></select>
                <div style="font-size: 12px;">
                    Some texts are machine-translated and may be inaccurate; translation contributions are welcome on GitHub.
                </div>
            `);

        // OPTIMIZATION: cache the lang select once
        const $langSelect = $('#langSelect');
        for (const o in locale_manifest) {
            $langSelect.append(
                `<option value="${o}" ${(state.lang === o) ? 'selected' : ''}>${locale_manifest[o]}</option>`
            );
        }

        const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY');

        for (const name in USER_SETTING) {
            $popupBody.append(`
                <label class="globalSettings"
                       title="${_i18n(name + '_INTRO')}"
                       data-ih-locale-title="${name + '_INTRO'}">

                    <span data-ih-locale="${name}">${_i18n(name)}</span>
                    <input id="${name}" value="box" type="checkbox"
                           ${USER_SETTING[name] === true ? 'checked' : ''}>
                    <div class="chbtn"><div class="rounds"></div></div>
                </label>`
            );

            if (name === 'MODIFY_VIDEO_VOLUME') {
                $popupBody.find(`input[id="${name}"]`).parent('label').on('contextmenu', function (e) {
                    e.preventDefault();
                    const $this = $(this);
                    if (!$this.find('#tempWrapper').length) {
                        $this.append('<div id="tempWrapper"></div>')
                            .children('#tempWrapper')
                            .append(`<input value="${state.videoVolume}" type="range" min="0" max="1" step="0.05" />`)
                            .append(`<input value="${state.videoVolume}" step="0.05" type="number" />`)
                            .append(`<div class="IG_POPUP_DIG_BTN">${SVG.CLOSE}</div>`);
                    }
                });
            }

            if (name === 'AUTO_RENAME') {
                $popupBody.find(`input[id="${name}"]`).parent('label').on('contextmenu', function (e) {
                    e.preventDefault();
                    const $this = $(this);
                    if (!$this.find('#tempWrapper').length) {
                        $this.append('<div id="tempWrapper"></div>')
                            .children('#tempWrapper')
                            .append(`<input id="date_format" value="${state.fileRenameFormat}" />`)
                            .append(`<div class="IG_POPUP_DIG_BTN">${SVG.CLOSE}</div>`);
                    }
                });
            }
        }

        $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY input#CHECK_FOR_UPDATE').closest('label').prependTo('.IG_POPUP_DIG .IG_POPUP_DIG_BODY');

        arrangeSettingHierarchy();
    }

    /**
     * arrangeSettingHierarchy
     * @description Arrange specific settings under the corresponding setting. 
     *
     * @return {void}
     */
    function arrangeSettingHierarchy() {
        Object.entries(PARENT_CHILD_MAPPING).forEach(([parent, children]) => {

            let $prev = $(`.IG_POPUP_DIG .IG_POPUP_DIG_BODY input#${parent}`).closest('label');

            children.forEach(child => {
                const $childLbl = $(`.IG_POPUP_DIG .IG_POPUP_DIG_BODY input#${child}`).closest('label').detach();
                $childLbl.addClass("child");
                $prev.after($childLbl);
                $prev = $childLbl;
            });
        });
    }

    /**
     * showDebugDOM
     * @description Show full DOM tree.
     *
     * @return {void}
     */
    function showDebugDOM() {
        $('.IG_POPUP_DIG').remove();
        IG_createDM();
        $('.IG_POPUP_DIG #post_info').text('IG Debug DOM Tree');

        // OPTIMIZATION: cache popup body
        const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY');
        $popupBody.append(`<textarea style="font-family: monospace;width:100%;box-sizing: border-box;height:300px;background: transparent;" readonly></textarea>`);
        $popupBody.append(`<span style="display:block;text-align:center;">`);
        const $span = $popupBody.find('span').last();
        $span.append(`<button style="margin: 3px;" class="IG_DISPLAY_DOM_TREE"><a>${_i18n('SHOW_DOM_TREE')}</a></button>`);
        $span.append(`<button style="margin: 3px;" class="IG_SELECT_DOM_TREE"><a>${_i18n('SELECT_AND_COPY')}</a></button>`);
        $span.append(`<button style="margin: 3px;" class="IG_DOWNLOAD_DOM_TREE"><a>${_i18n('DOWNLOAD_DOM_TREE')}</a></button><br/>`);
        $span.append(`<button style="margin: 3px;" class="IG_REPORT_GITHUB"><a href="https://github.com/SN-Koarashi/ig-helper/issues" target="_blank">${_i18n('REPORT_GITHUB')}</a></button>`);
        $span.append(`<button style="margin: 3px;" class="IG_REPORT_DISCORD"><a href="https://discord.gg/q3KT4hdq8x" target="_blank">${_i18n('REPORT_DISCORD')}</a></button>`);
    }

    /**
     * showFeedbackDOM
     * @description Show feedback options.
     *
     * @return {void}
     */
    function showFeedbackDOM() {
        $('.IG_POPUP_DIG').remove();
        IG_createDM();
        $('.IG_POPUP_DIG #post_info').text('Feedback Options');

        const $popupBody = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY');
        $popupBody.append(`<span style="display:block;text-align:center;">`);
        const $span = $popupBody.find('span').last();
        $span.append(`<button style="margin: 3px;" class="IG_REPORT_FORK"><a href="https://greasyfork.org/en/scripts/404535-ig-helper/feedback" target="_blank">${_i18n('REPORT_FORK')}</a></button>`);
        $span.append(`<button style="margin: 3px;" class="IG_REPORT_GITHUB"><a href="https://github.com/SN-Koarashi/ig-helper/issues" target="_blank">${_i18n('REPORT_GITHUB')}</a></button>`);
        $span.append(`<button style="margin: 3px;" class="IG_REPORT_DISCORD"><a href="https://discord.gg/q3KT4hdq8x" target="_blank">${_i18n('REPORT_DISCORD')}</a></button>`);
    }

    var detectMovingViewerTimer = null;

    function openImageViewer(imageUrl) {
        removeImageViewer();

        $body.append(
            `<div id="imageViewer">
    	<div id="iv_header">
    		<div style="flex:1;">Image Viewer</div>
    		<div style="display: flex;filter: invert(1);gap: 8px;margin-right: 8px;">
                <div id="rotate_left" style="cursor: pointer;">${SVG.TURN_DEG}</div>
                <div id="rotate_right" style="transform: scaleX(-1);cursor: pointer;">${SVG.TURN_DEG}</div>
            </div>
    		<div id="iv_close">${SVG.CLOSE}</div>
    	</div>
        <section>
            <div id="iv_transform">
                <div id="iv_rotate">
                    <img id="iv_image" src="" />
                </div>
            </div>
        </section>
    </div>`);

        const $container = $('#imageViewer');
        const $section = $('#imageViewer > section');
        const $wrapT = $('#iv_transform');
        const $wrapR = $('#iv_rotate');
        const $header = $('#iv_header');
        const $closeIcon = $('#iv_close');
        const $image = $('#iv_image');
        const $rotateLeft = $('#rotate_left');
        const $rotateRight = $('#rotate_right');

        $image.attr('src', imageUrl);
        $container.css('display', 'flex');
        $wrapT.css('transform-origin', '0 0');
        $wrapT.css('transition', `transform 0.15s ease`);
        $wrapR.css('transform-origin', 'center');
        $wrapR.css('transition', `transform 0.15s ease`);
        $wrapT.css('will-change', 'transform');
        $wrapR.css('will-change', 'transform');

        let rotate = 0;
        let scale = 1;
        let posX = 0, posY = 0;
        let isDragging = false;
        let isMovingPhoto = false;
        let startX, startY;
        var previousPosition = {
            x: 0,
            y: 0
        };

        detectMovingViewerTimer = setInterval(() => {
            const currentPosition = {
                x: posX,
                y: posY
            };
            if (currentPosition.x !== previousPosition.x || currentPosition.y !== previousPosition.y) {
                isMovingPhoto = true;
            } else {
                isMovingPhoto = false;
            }
            previousPosition = currentPosition;
        }, 100);


        $image.on('load', () => {
            posX = 0;
            posY = 0;
            updateImageStyle();
        });

        $image.on('dragstart drop', (e) => {
            e.preventDefault();
        });

        $image.on('click', (e) => {
            e.preventDefault();
            e.stopPropagation();

            if (!isMovingPhoto) {
                if (scale <= 1) {
                    makeZoomAction(e, Math.min(Math.max(1, scale + 1.25), 5));
                }
                else {
                    scale = 1;
                    posX = 0;
                    posY = 0;
                }

                updateImageStyle();
            }
        });

        $section.on('wheel', (e) => {
            e.preventDefault();
            makeZoomAction(e);
        });

        $container.on('wheel', (e) => {
            e.preventDefault();
        });

        $image.on('mousedown', (e) => {
            if (scale == 1) return;

            isDragging = true;

            startX = e.pageX - posX;
            startY = e.pageY - posY;
            $image.css('cursor', 'grabbing');
        });

        $image.on('mouseup', () => {
            if (scale == 1) return;

            isDragging = false;
            $image.css('cursor', 'grab');
        });

        $rotateLeft.on('click', function () {
            rotate -= 90;
            updateImageStyle();
        });

        $rotateRight.on('click', function () {
            rotate += 90;
            updateImageStyle();
        });

        $(document).on('mousemove.igHelper', (e) => {
            if (!isDragging) return;
            e.preventDefault();

            posX = e.pageX - startX;
            posY = e.pageY - startY;

            updateImageStyle();
        });

        $container.on('click', () => {
            removeImageViewer();
        });

        $closeIcon.on('click', () => {
            removeImageViewer();
        });

        $header.on('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
        });

        function updateImageStyle() {
            $wrapT.css('transition', isMovingPhoto ? "none" : `transform 0.15s ease`);
            $wrapT.css('transform', `translate(${posX}px, ${posY}px) scale(${scale})`);
            $wrapR.css('transform', `rotate(${rotate}deg)`);

            if (scale == 1) {
                $image.css('cursor', 'zoom-in');
            }
            else {
                $image.css('cursor', 'grabbing');
            }
        }


        function makeZoomAction(e, newScale) {
            e.preventDefault();

            let prevScale = scale;

            // newScale should be null when passing by wheel event
            if (newScale == null) {
                let factor = 0.1;
                let delta = e.originalEvent.deltaY < 0 ? 1 : -1;
                scale = Math.min(5, Math.max(1, scale + delta * factor * scale));
            }
            else {
                scale = newScale;
            }


            let rect = $section[0].getBoundingClientRect();
            let mx = e.clientX - rect.left;
            let my = e.clientY - rect.top;

            let zoomTargetX = (mx - posX) / prevScale;
            let zoomTargetY = (my - posY) / prevScale;

            posX = -zoomTargetX * scale + mx;
            posY = -zoomTargetY * scale + my;

            updateImageStyle();
        }
    }

    function removeImageViewer() {
        clearInterval(detectMovingViewerTimer);
        $('#imageViewer').remove();
        $(document).off('mousemove.igHelper');
    }

    let mediaCacheDirty = false;
    let mediaCacheSaveTimer = null;

    /**
     * purgeCache
     * @description Purge image cache entries older than 12 hours.
     *
     * @return {void}
     */
    function purgeCache() {
        const now = Date.now();
        for (const id in state.GL_imageCache) {
            if ((now - state.GL_imageCache[id].ts) > IMAGE_CACHE_MAX_AGE) delete state.GL_imageCache[id];
        }
        GM_setValue(IMAGE_CACHE_KEY, state.GL_imageCache);
    }


    /**
     * mediaIdFromURL
     * @description Decode mediaId from ig_cache_key parameter that Instagram includes in the URL.
     *
     * @param  {string}  url
     * @return {?string}
     */
    function mediaIdFromURL(url) {
        try {
            const u = new URL(url);
            const key = u.searchParams.get('ig_cache_key');
            if (!key) return null;
            const b64 = key.split('.')[0];          // Part before “.3-ccb7…”
            return atob(b64);                       // e.g., “3670776772828545770”
        } catch { return null; }
    }

    /**
     * putInCache
     * @description Save URL to image cache.
     *
     * @param  {string}  mediaId
     * @param  {string}  url
     * @return {void}
     */
    function putInCache(mediaId, url) {
        if (!mediaId) return;

        const keys = Object.keys(state.GL_imageCache);
        if (keys.length >= IMAGE_MAX_CACHE_ITEMS) {
            keys.sort((a, b) => state.GL_imageCache[a].ts - state.GL_imageCache[b].ts);
            delete state.GL_imageCache[keys[0]];
        }

        mediaCacheDirty = true;
        state.GL_imageCache[mediaId] = { url, ts: Date.now() };

        if (!mediaCacheSaveTimer) {
            mediaCacheSaveTimer = setTimeout(() => {
                if (mediaCacheDirty) {
                    GM_setValue(IMAGE_CACHE_KEY, state.GL_imageCache);
                    mediaCacheDirty = false;
                }
                mediaCacheSaveTimer = null;
            }, 500); // write in script storage per 500 ms
        }
    }

    /**
     * getImageFromCache
     * @description Read image URL from cache; returns null if not found or expired.
     *
     * @param  {string}  mediaId
     * @return {?string}
     */
    function getImageFromCache(mediaId) {
        if (!mediaId) return null;
        const entry = state.GL_imageCache[mediaId];
        if (!entry) return null;
        if ((Date.now() - entry.ts) > IMAGE_CACHE_MAX_AGE) { delete state.GL_imageCache[mediaId]; return null; }
        return entry.url;
    }

    /**
     * registerPerformanceObserver
     * @description Register performance observer to document, captures any loaded image resource.
     *
     * @return {void}
     */
    function registerPerformanceObserver() {
        const perfObs = new PerformanceObserver(list => {
            if (!USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) return;

            list.getEntries().forEach(entry => {
                if (entry.initiatorType === 'img') {
                    const u = entry.name;

                    if (
                        !(u.includes('_e35') || u.includes('_e15') || u.includes('.webp?')) ||
                        u.includes('_e35_s') ||
                        u.match(/_[sp](\d+)x\1(?!\d)/)
                    ) {
                        return;
                    }

                    const id = mediaIdFromURL(u);
                    if (id && !state.GL_imageCache[id]) putInCache(id, u);
                }
            });
        });
        perfObs.observe({ entryTypes: ['resource'] });
    }

    /**
     * translateText
     * @description i18n translation text.
     *
     * @return {void}
     */
    function translateText() {
        var eLocale = {
            "en-US": {
                "NOTICE_UPDATE_TITLE": "Wololo! New version released.",
                "NOTICE_UPDATE_CONTENT": "IG-Helper has released a new version, click here to update.",
                "CHECK_FOR_UPDATE": "Check for Script Updates",
                "RELOAD_SCRIPT": "Reload Script",
                "DONATE": "Donate",
                "FEEDBACK": "Feedback",
                "IMAGE_VIEWER": "Open Image In Viewer",
                "NEW_TAB": "Open in New Tab",
                "SHOW_DOM_TREE": "Show DOM Tree",
                "SELECT_AND_COPY": "Select All and Copy from the Input Box",
                "DOWNLOAD_DOM_TREE": "Download DOM Tree as a Text File",
                "REPORT_GITHUB": "Report an Issue on GitHub",
                "REPORT_DISCORD": "Report an Issue on Discord Support Server",
                "REPORT_FORK": "Report an Issue on Greasy Fork",
                "DEBUG": "Debug Window",
                "CLOSE": "Close",
                "ALL_CHECK": "Select All",
                "ITEM_COUNT_SINGULAR": "%COUNT% item",
                "ITEM_COUNT_PLURAL": "%COUNT% items",
                "ITEM_POSITION": "Item %CURRENT% of %TOTAL%",
                "SELECTED_COUNT_SINGULAR": "%COUNT% selected",
                "SELECTED_COUNT_PLURAL": "%COUNT% selected",
                "BATCH_DOWNLOAD_SELECTED": "Download Selected Resources",
                "BATCH_DOWNLOAD_DIRECT": "Download All Resources",
                "IMG": "Image",
                "VID": "Video",
                "DW": "Download",
                "DW_ALL": "Download All Resources",
                "VIDEO_THUMBNAIL": "Download Video Thumbnail",
                "LOAD_BLOB_ONE": "Loading Blob Media...",
                "LOAD_BLOB_MULTIPLE": "Loading Blob Media and Others...",
                "LOAD_BLOB_RELOAD": "Detecting Blob Media, reloading...",
                "NO_CHECK_RESOURCE": "You need to select a resource to download.",
                "NO_VID_URL": "Cannot find video URL.",
                "SETTING": "Settings",
                "AUTO_RENAME": "Automatically Rename Files (Right-Click to Set)",
                "RENAME_PUBLISH_DATE": "Set Renamed File Timestamp to Resource Publish Date",
                "RENAME_LOCATE_DATE": "Modify Renamed File Timestamp Date Format (Right-Click to Set)",
                "DISABLE_VIDEO_LOOPING": "Disable Video Auto-looping",
                "HTML5_VIDEO_CONTROL": "Display HTML5 Video Controller",
                "REDIRECT_CLICK_USER_STORY_PICTURE": "Redirect When Clicking on User's Story Picture",
                "FORCE_FETCH_ALL_RESOURCES": "Force Fetch All Resources in the Post",
                "DIRECT_DOWNLOAD_VISIBLE_RESOURCE": "Directly Download the Visible Resources in the Post",
                "DIRECT_DOWNLOAD_ALL": "Directly Download All Resources in the Post",
                "DIRECT_DOWNLOAD_STORY": "Directly Download All Resources in the Story/Highlight",
                "MODIFY_VIDEO_VOLUME": "Modify Video Volume (Right-Click to Set)",
                "MODIFY_RESOURCE_EXIF": "Modify Resource EXIF Properties",
                "SCROLL_BUTTON": "Enable Scroll Buttons for Reels Page",
                "FORCE_RESOURCE_VIA_MEDIA": "Force Fetch Resource via Media API",
                "PREFER_DASH_MANIFEST": "Prefer DASH Manifest (Higher-Quality Video via Media API)",
                "FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED": "Use Alternative Methods to Download When the Media API is Not Accessible",
                "NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST": "Always Use Media API for [Open in New Tab] in Posts",
                "SKIP_VIEW_STORY_CONFIRM": "Skip the Confirmation Page for Viewing a Story/Highlight",
                "SKIP_SHARED_WITH_YOU_DIALOG": "Skip \"shared this with you\" dialog on shared profile links",
                "CAPTURE_IMAGE_VIA_MEDIA_CACHE": "Capture Image Resource Using Media Cache",
                "AUTO_RENAME_INTRO": [
                    "Auto rename file to custom format:",
                    "Custom Format List:",
                    "%USERNAME% - Username",
                    "%SOURCE_TYPE% - Download Source",
                    "%SHORTCODE% - Post Shortcode",
                    "%YEAR% - Year when downloaded/published",
                    "%2-YEAR% - Year (last two digits) when downloaded/published",
                    "%MONTH% - Month when downloaded/published",
                    "%DAY% - Day when downloaded/published",
                    "%HOUR% - Hour when downloaded/published",
                    "%MINUTE% - Minute when downloaded/published",
                    "%SECOND% - Second when downloaded/published",
                    "%ORIGINAL_NAME% - Original name of downloaded file",
                    "%ORIGINAL_NAME_FIRST% - Original name of downloaded file (first part of name)",
                    "%INDEX% - Resource index",
                    "%UID% - User account unique ID",
                    "",
                    "If set to false, the file name will remain unchanged.",
                    "Example: instagram_321565527_679025940443063_4318007696887450953_n.jpg"
                ],
                "RENAME_PUBLISH_DATE_INTRO": "Sets the timestamp in the file rename format to the resource publish date (browser time zone).\n\nThis feature only works when [Automatically Rename Files] is set to TRUE.",
                "RENAME_LOCATE_DATE_INTRO": "Modify the renamed file timestamp date format to the browser's local time, and format it to your preferred regional date format.\n\nThis feature only works when [Automatically Rename Files] is set to TRUE.",
                "DISABLE_VIDEO_LOOPING_INTRO": "Disable video auto-looping in Reels and posts.",
                "HTML5_VIDEO_CONTROL_INTRO": "Display the HTML5 video controller in video resource.\n\nThis will hide the custom video volume slider and replace it with the HTML5 controller. The HTML5 controller can be hidden by right-clicking on the video to reveal the original details.",
                "REDIRECT_CLICK_USER_STORY_PICTURE_INTRO": "Redirect to a user's profile page when right-clicking on their avatar in the story area on the homepage.\nIf you use the middle mouse button to click, it will open in a new tab.",
                "FORCE_FETCH_ALL_RESOURCES_INTRO": "Force fetching of all resources (photos and videos) in a post via the Instagram API to remove the limit of three resources per post.",
                "DIRECT_DOWNLOAD_VISIBLE_RESOURCE_INTRO": "Directly download the current resources available in the post.",
                "DIRECT_DOWNLOAD_ALL_INTRO": "When you click the download button, all resources in the post will be forcibly fetched and downloaded.",
                "MODIFY_VIDEO_VOLUME_INTRO": "Modify the video playback volume in Reels and posts (right-click to open the volume setting slider).",
                "SCROLL_BUTTON_INTRO": "Enable scroll buttons for the lower right corner of the Reels page.",
                "FORCE_RESOURCE_VIA_MEDIA_INTRO": "The Media API will try to get the highest quality photo or video possible, but it may take longer to load.",
                "PREFER_DASH_MANIFEST_INTRO": "Prefer the DASH manifest for video resources via the Media API. If a DASH manifest is available, it will download the video and audio streams SEPARATELY for the best possible quality.",
                "FALLBACK_TO_BLOB_FETCH_IF_MEDIA_API_THROTTLED_INTRO": "When the Media API reaches its rate limit or cannot be used for other reasons, the Forced Fetch API will be used to download resources (the resource quality may be slightly lower).",
                "NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST_INTRO": "The [Open in New Tab] button in posts will always use the Media API to obtain high-resolution resources.",
                "CHECK_FOR_UPDATE_INTRO": "Check for updates when the script is triggered (check every 300 seconds).\nUpdate notifications will be sent as desktop notifications through the browser.",
                "SKIP_VIEW_STORY_CONFIRM_INTRO": "Automatically skip when confirmation page is shown in story or highlight.",
                "SKIP_SHARED_WITH_YOU_DIALOG_INTRO": "Automatically click \"Not now\" on the \"X shared this with you\" dialog when opening any ?igsh= links.",
                "MODIFY_RESOURCE_EXIF_INTRO": "Modify the EXIF attribute of the image resource to include metadata such as post link, shooting date, and author.",
                "DIRECT_DOWNLOAD_STORY_INTRO": "When you click [Download All Resources], all stories/highlights are downloaded directly, without showing the image selection dialog.",
                "CAPTURE_IMAGE_VIA_MEDIA_CACHE_INTRO": "Use a watcher to capture any high-quality image URLs in the DOM tree into the script's storage so that they can be extracted when available and upon user input.",
                "HOTKEY_DEBUG_KEY": "Debug Window",
                "HOTKEY_SETTINGS_KEY": "Preference Settings",
                "HOTKEY_KEY_SETTINGS_KEY": "Hotkey Settings",
                "HOTKEY_DOWNLOAD_STORY_KEY": "Download Story",
                "HOTKEY_CONFLICT_WARNING": "This hotkey may conflict with other settings.",
                "HOTKEY_RESET": "Reset"
            }
        };

        var resultUnsorted = Object.assign({}, eLocale, state.locale);
        var resultSorted = Object.keys(resultUnsorted).sort().reduce(
            (obj, key) => {
                obj[key] = resultUnsorted[key];
                return obj;
            }, {}
        );

        var result = Object.assign({}, resultSorted);
        for (const lang in result) {
            const translations = result[lang];
            if (!translations || typeof translations !== "object") {
                continue;
            }

            Object.keys(translations).forEach((key) => {
                const value = translations[key];
                if (Array.isArray(value)) {
                    translations[key] = value.join("\n");
                }
            });
        }

        return result;
    }

    /**
     * getTranslationText
     * @description i18n translation text.
     *
     * @param  {String}  lang
     * @return {Object}
     */
    async function getTranslationText(lang) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: "GET",
                url: `https://cdn.jsdelivr.net/gh/SN-Koarashi/ig-helper@master/locale/translations/${lang}.json?v${GM_info.script.version}`,
                onload: function (response) {
                    try {
                        let obj = JSON.parse(response.response);
                        resolve(obj);
                    }
                    catch (err) {
                        reject(err);
                    }
                },
                onerror: function (err) {
                    logger('getTranslationText()', 'reject', err);
                    reject(err);
                }
            });
        });
    }

    /**
     * _i18n
     * @description Perform i18n translation.
     *
     * @param  {String}  text
     * @return {void}
     */
    function _i18n(text) {
        const translate = translateText();

        if (translate[state.lang] != undefined && translate[state.lang][text] != undefined) {
            return translate[state.lang][text];
        }
        else {
            return translate["en-US"][text];
        }
    }

    /**
     * repaintingTranslations
     * @description Perform i18n translation.
     *
     * @return {void}
     */
    function repaintingTranslations() {
        $('[data-ih-locale]').each(function () {
            const $this = $(this);
            $this.text(_i18n($this.data('ih-locale')));
        });
        $('[data-ih-locale-title]').each(function () {
            const $this = $(this);
            $this.attr('title', _i18n($this.data('ih-locale-title')));
        });
    }

    /* register all events */

    // Running if document is ready
    $(function () {
        function ConvertDOM(domEl) {
            var obj = [];
            for (var ele of domEl) {
                obj.push({
                    tagName: ele.tagName,
                    id: ele.id,
                    className: ele.className
                });
            }

            return obj;
        }

        function setDOMTreeContent() {
            let text = $('div[id^="mount"]')[0];
            var loggerStr = "";
            state.GL_logger.forEach(log => {
                var jsonData = JSON.stringify(log.content, function (key, value) {
                    if (Array.isArray(this)) {
                        if (typeof value === "object" && value instanceof jQuery) {
                            return ConvertDOM(value);
                        }
                        return value;
                    }
                    else {
                        return value;
                    }
                }, "\t");
                loggerStr += `${new Date(log.time).toISOString()}: ${jsonData}\n`
            });
            $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY textarea').text("Logger:\n" + loggerStr + "\n-----\n\nLocation: " + location.pathname + "\nDOM Tree with div#mount:\n" + text.innerHTML);
        }

        $body.on('click', '.IG_POPUP_DIG .IG_POPUP_DIG_BODY .IG_DISPLAY_DOM_TREE', function () {
            setDOMTreeContent();
        });

        // OPTIMIZATION: replace deprecated document.execCommand('copy') with modern
        // navigator.clipboard.writeText() API. Falls back to execCommand on browsers
        // that don't support it (unlikely on Chrome/Firefox/Edge >= 100).
        $body.on('click', '.IG_POPUP_DIG .IG_POPUP_DIG_BODY .IG_SELECT_DOM_TREE', function () {
            const $textarea = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY textarea');
            const textContent = $textarea.val() || $textarea.text();
            $textarea.trigger('select');

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(textContent).catch(err => {
                    logger('Clipboard API failed, falling back to execCommand:', err);
                    try { document.execCommand('copy'); } catch (e) { logger('execCommand fallback failed:', e); }
                });
            }
            else {
                try { document.execCommand('copy'); } catch (e) { logger('execCommand failed:', e); }
            }
        });

        $body.on('click', '.IG_POPUP_DIG .IG_POPUP_DIG_BODY .IG_DOWNLOAD_DOM_TREE', function () {
            const $textarea = $('.IG_POPUP_DIG .IG_POPUP_DIG_BODY textarea');
            if ($textarea.text().length === 0) {
                setDOMTreeContent();
            }

            var text = $textarea.text();
            var a = document.createElement("a");
            var file = new Blob([text], { type: "text/plain" });
            a.href = URL.createObjectURL(file);
            a.download = "DOMTree-" + new Date().getTime() + ".txt";

            document.body.appendChild(a);
            a.click();
            a.remove();
        });

        // Close the download dialog if user click the close icon
        $body.on('click', '.IG_POPUP_DIG_BTN, .IG_POPUP_DIG_BG', function () {
            const $this = $(this);
            if ($this.parent('#tempWrapper').length > 0) {
                $this.parent('#tempWrapper').fadeOut(250, function () {
                    $(this).remove();
                });
            }
            else {
                $('.IG_POPUP_DIG').remove();
            }
        });

        $(window).on('keydown', function (e) {
            // Hot key [Alt+Q] to close the download dialog - fixed
            if (e.altKey && e.which == 81) {
                $('.IG_POPUP_DIG').remove();
                e.preventDefault();
            }
            // Hot key [Alt+W] to open/close the settings dialog - use custom keycode if enabled, fallback to default Alt+W(87)
            let settingsKeyCode = state.settingsHotkeyKeyCode || 87;
            if (e.altKey && e.which == settingsKeyCode) {
                const $popup = $('.IG_POPUP_DIG');
                if ($popup.length > 0 && $popup.find('#post_info').text() === 'Preference Settings') {
                    $popup.remove();
                } else {
                    showSetting();
                }
                e.preventDefault();
            }

            // Hot key [Alt+W] to open/close the key settings dialog - use custom keycode if enabled, fallback to default Alt+C(67)
            let keySettingsHotkeyKeyCode = state.keySettingsHotkeyKeyCode || 67;
            if (e.altKey && e.which == keySettingsHotkeyKeyCode) {
                const $popup = $('.IG_POPUP_DIG');
                if ($popup.length > 0 && $popup.find('#post_info').text() === 'Hotkey Settings') {
                    $popup.remove();
                } else {
                    showHotkeySetting();
                }
                e.preventDefault();
            }

            // Hot key [Alt+Z] to open the debug DOM - use custom keycode if enabled, fallback to default Alt+Z(90)
            let debugKeyCode = state.debugHotkeyKeyCode || 90;
            if (e.altKey && e.which == debugKeyCode) {
                showDebugDOM();
                e.preventDefault();
            }

            // Hot key [Alt+R] to reload script (fixed, not customizable)
            if (e.which == '82' && e.altKey) {
                reloadScript();
                e.preventDefault();
            }

            // Hot key [Alt+S] to download story/highlights resource - use custom keycode if enabled, fallback to default Alt+S(83)
            let downloadStoryKeyCode = state.downloadStoryHotkeyKeyCode || 83;
            if (e.altKey && e.which == downloadStoryKeyCode) {
                if (location.href.match(/^(https:\/\/www\.instagram\.com\/stories\/)/ig) && $('.IG_DWSTORY').length > 0) {
                    $('.IG_DWSTORY')?.trigger("click");
                }
                if (location.href.match(/^(https:\/\/www\.instagram\.com\/stories\/highlights\/)/ig) && $('.IG_DWHISTORY').length > 0) {
                    $('.IG_DWHISTORY')?.trigger("click");
                }
                e.preventDefault();
            }
        });

        $body.on('change', '.IG_POPUP_DIG input', function () {
            const $this = $(this);
            var name = $this.attr('id');

            if (name && USER_SETTING[name] !== undefined) {
                let isChecked = $this.prop('checked');
                GM_setValue(name, isChecked);
                USER_SETTING[name] = isChecked;

                console.log('user settings', name, isChecked);
            }
        });

        $body.on('click', '.IG_POPUP_DIG .globalSettings', function (e) {
            if ($(this).find('#tempWrapper').length > 0) {
                e.preventDefault();
            }
        });

        $body.on('change', '.IG_POPUP_DIG #tempWrapper input:not(#date_format)', function () {
            const $this = $(this);
            let value = $this.val();

            if ($this.attr('type') == 'range') {
                $this.next().val(value);
            }
            else {
                $this.prev().val(value);
            }

            if (value >= 0 && value <= 1) {
                state.videoVolume = value;
                GM_setValue('G_VIDEO_VOLUME', value);
            }
        });

        $body.on('input', '.IG_POPUP_DIG #tempWrapper input:not(#date_format)', function () {
            const $this = $(this);
            if ($this.attr('type') == 'range') {
                let value = $this.val();
                $this.next().val(value);
            }
            else {
                let value = $this.val();
                if (value >= 0 && value <= 1) {
                    $this.prev().val(value);
                }
                else {
                    if (value < 0) {
                        $this.val(0);
                    }
                    else {
                        $this.val(1);
                    }
                }
            }
        });

        $body.on('input', '.IG_POPUP_DIG #tempWrapper input#date_format', function () {
            const val = $(this).val();
            GM_setValue('G_RENAME_FORMAT', val);
            state.fileRenameFormat = val;
        });

        $body.on('click', 'a[data-needed="direct"]', function (e) {
            e.preventDefault();
            triggerLinkElement($(this), false);
        });

        $body.on('click', '.IG_POPUP_DIG_BODY .newTab', function () {
            const $this = $(this);
            const $linkA = $this.parent().children('a');
            if (USER_SETTING.FORCE_RESOURCE_VIA_MEDIA && USER_SETTING.NEW_TAB_ALWAYS_FORCE_MEDIA_IN_POST) {
                triggerLinkElement($linkA.first()[0], true);
            }
            else {
                openNewTab(replaceSameOriginHost($linkA.data('href')));
            }
        });

        $body.on('click', '.IG_POPUP_DIG_BODY .videoThumbnail', function () {
            const $this = $(this);
            const $linkA = $this.parent().children('a');
            let timestamp = new Date().getTime();

            if (USER_SETTING.RENAME_PUBLISH_DATE && $linkA.attr('datetime')) {
                timestamp = $linkA.attr('datetime');
            }

            let postPath = $linkA.data('path') ?? $('#article-id').text();

            if (USER_SETTING.CAPTURE_IMAGE_VIA_MEDIA_CACHE) {
                const mediaId = $linkA.first().attr('media-id');
                const cached = getImageFromCache(mediaId);

                if (cached) {
                    logger("[Restore Cached postThumbnail]", mediaId);
                    saveFiles(cached, {
                        username: $linkA.data('username'),
                        sourceType: 'thumbnail',
                        timestamp,
                        filetype: 'jpg',
                        shortcode: postPath
                    });
                    return;
                }
            }

            saveFiles(
                $linkA.find('img').first().attr('src'),
                {
                    username: $linkA.data('username'),
                    sourceType: 'thumbnail',
                    timestamp,
                    filetype: 'jpg',
                    shortcode: postPath
                });
        });

        // Running if user left-click download icon in stories
        $body.on('click', '.IG_DWSTORY', function () {
            onStory(true);
        });

        // Running if user left-click all download icon in stories
        $body.on('click', '.IG_DWSTORY_ALL', function () {
            onStoryAll();
        });

        // Running if user left-click 'open in new tab' icon in stories
        $body.on('click', '.IG_DWNEWTAB', function (e) {
            e.preventDefault();
            onStory(true, true, true);
        });

        // Running if user left-click download thumbnail icon in stories
        $body.on('click', '.IG_DWSTORY_THUMBNAIL', function () {
            onStoryThumbnail(true);
        });

        // Running if user left-click download icon in profile
        $body.on('click', '.IG_DWPROFILE', function (e) {
            e.stopPropagation();
            onProfileAvatar(true);
        });

        // Running if user left-click download icon in highlight stories
        $body.on('click', '.IG_DWHISTORY', function () {
            onHighlightsStory(true);
        });

        // Running if user left-click all download icon in highlight stories
        $body.on('click', '.IG_DWHISTORY_ALL', function () {
            onHighlightsStoryAll();
        });

        // Running if user left-click 'open in new tab' icon in highlight stories
        $body.on('click', '.IG_DWHINEWTAB', function (e) {
            e.preventDefault();
            onHighlightsStory(true, true);
        });

        // Running if user left-click thumbnail download icon in highlight stories
        $body.on('click', '.IG_DWHISTORY_THUMBNAIL', function () {
            onHighlightsStoryThumbnail(true);
        });

        // Running if user left-click download icon in reels
        $body.on('click', '.IG_REELS', function () {
            onReels(true, true);
        });

        // Running if user left-click newtab icon in reels
        $body.on('click', '.IG_REELS_NEWTAB', function () {
            onReels(true, true, true);
        });

        // Running if user left-click download icon in reels
        $body.on('click', '.IG_REELS_THUMBNAIL', function () {
            onReels(true, false);
        });

        // Running if user right-click profile picture in stories area
        $body.on('mousedown', 'button[role="menuitem"], div[role="menuitem"], ul > li[tabindex="-1"] > div[role="button"]', function (e) {
            // Right-Click || Middle-Click
            if (e.which === 3 || e.which === 2) {
                if (location.href === 'https://www.instagram.com/' && USER_SETTING.REDIRECT_CLICK_USER_STORY_PICTURE) {
                    e.preventDefault();

                    const $this = $(this);
                    $this.find('img').each(function () {
                        const $img = $(this);
                        if (!$img.data('contextmenu')) {
                            $img.data('contextmenu', true);
                            $img.on('contextmenu', function (e) {
                                e.preventDefault();
                            });
                        }
                    });

                    if ($this.find('canvas._aarh, canvas + span > img').length > 0) {
                        const targetUrl = 'https://www.instagram.com/' + $this.children('div').last().text();
                        if (e.which === 2) {
                            GM_openInTab(targetUrl);
                        }
                        else {
                            location.href = targetUrl;
                        }
                    }
                }
            }
        });

        $body.on('change', '.IG_POPUP_DIG_TITLE .checkbox', function () {
            const isChecked = $(this).find('input').prop('checked');
            $('.IG_POPUP_DIG_BODY .inner_box').each(function () {
                $(this).prop('checked', isChecked);
            });
            updatePopupSelectionSummary();
        });

        $body.on('change', '.IG_POPUP_DIG_BODY .inner_box', function () {
            updatePopupSelectionSummary();
        });

        $body.on('click', '.IG_POPUP_DIG_TITLE #batch_download_selected', function () {
            if ($('.IG_POPUP_DIG #_SNLOAD').length > 0) return;

            let index = 0;
            let links = [];
            $('.IG_POPUP_DIG_BODY a[data-needed="direct"]').each(function () {
                let $link = $(this);
                if ($link.prev().children('input').prop('checked')) {
                    links.push($link);
                    index++;
                }
            });

            if (index == 0) {
                alert(_i18n('NO_CHECK_RESOURCE'));
            }
            else {
                batchDownloadPostFiles(links);
            }
        });

        $body.on('change', '.IG_POPUP_DIG_TITLE #langSelect', function () {
            const $this = $(this);
            const val = $this.val();
            GM_setValue('UI_LANGUAGE', val);
            state.lang = val;

            if (state.lang?.startsWith('en') || state.locale[state.lang] != null) {
                repaintingTranslations();
                registerMenuCommand();
            }
            else {
                getTranslationText(state.lang).then((res) => {
                    state.locale[state.lang] = res;
                    repaintingTranslations();
                    registerMenuCommand();
                }).catch((err) => {
                    console.error('getTranslationText catch error:', err);
                });
            }
        });

        $body.on('click', '.IG_POPUP_DIG_TITLE #batch_download_direct', function () {
            if ($('.IG_POPUP_DIG #_SNLOAD').length > 0) return;

            let links = [];
            $('.IG_POPUP_DIG_BODY a[data-needed="direct"]').each(function () {
                links.push($(this));
            });

            batchDownloadPostFiles(links);
        });

        registerPerformanceObserver();

        const element_observer = new MutationObserver((mutationsList) => {
            for (const mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        const $node = $(node);
                        const $videos = $node.find('video').addBack('video');

                        if (location.pathname.startsWith("/stories/highlights/")) {
                            if (
                                $node.attr("data-ih-locale-title") == null &&
                                $node.attr("data-visualcompletion") == null &&
                                node.tagName === "DIV"
                            ) {
                                // replace something times ago format to publish time when switch highlight
                                var $time = getHighlightCurrentTimeElement($node);
                                setTimeElementDateAndLocaleTime($time);
                            }
                        }

                        if ($videos.length > 0) {
                            // Modify video volume
                            if (USER_SETTING.MODIFY_VIDEO_VOLUME) {
                                $videos.each(function () {
                                    $(this).on('play playing', function () {
                                        const $this = $(this);
                                        if (!$this.data('modify')) {
                                            $this.data('modify', true);
                                            this.volume = state.videoVolume;
                                            logger('(audio_observer) Added video event listener #modify');
                                        }
                                    });
                                });
                            }

                            if (location.pathname.match(/^(\/stories\/)/ig)) {
                                const isHighlight = location.pathname.match(/^(\/stories\/highlights\/)/ig) != null;
                                const storyType = isHighlight ? 'highlight' : 'story';

                                $videos.each(function () {
                                    $(this).on('timeupdate', function () {
                                        const $this = $(this);
                                        if (!$this.data('modify-thumbnail')) {
                                                let $video = $this;
                                                if ($video.parents('div[style][class]').filter(function () {
                                                    return $(this).width() == $video.width();
                                                }).find('.IG_DWSTORY_THUMBNAIL, .IG_DWHISTORY_THUMBNAIL').length === 0) {
                                                    $this.data('modify-thumbnail', true);

                                                    if (isHighlight) {
                                                        onHighlightsStoryThumbnail(false);
                                                    }
                                                    else {
                                                        onStoryThumbnail(false);
                                                    }

                                                    logger(`(${storyType})`, 'Manually inserting thumbnail button');
                                                }
                                                else {
                                                    $this.data('modify-thumbnail', true);
                                                    logger(`(${storyType})`, 'Thumbnail button already inserted');
                                                }
                                            }
                                        });

                                    var $video = $(this);

                                    if (USER_SETTING.HTML5_VIDEO_CONTROL) {
                                        if (!$video.data('controls')) {
                                            logger(`(${storyType})`, 'Added video html5 contorller #modify');

                                            if (USER_SETTING.MODIFY_VIDEO_VOLUME) {
                                                this.volume = state.videoVolume;

                                                $video.on('loadstart', function () {
                                                    this.volume = state.videoVolume;
                                                });
                                            }

                                            let $videoParent = $video.parents('div').filter(function () {
                                                const $this = $(this);
                                                return $this.attr('class') == null && $this.attr('style') == null;
                                            }).first();

                                            // This is mute/unmute's icon
                                            let $element_mute_button = $videoParent.parent().find('svg > path[d^="M1.5 13.3c-.8 0-1.5.7-1.5 1.5v18.4c0"], svg > path[d^="M16.636 7.028a1.5 1.5"]').parents('[role="button"]').first();
                                            state.GL_weakCache.mutedButton.set($video[0], $element_mute_button);

                                            // story bottom bar
                                            let $bottomBar = $videoParent.next();

                                            // read more button in center
                                            let $readMoreButton = $videoParent.find('div[class][role="button"]');

                                            let $targets = $video.parent().find('video + div');

                                            const hideContextmenu = function (e) {
                                                e.preventDefault();
                                                e.stopPropagation();

                                                let $overlayElement = null;

                                                if ($overlayElement == null) {
                                                    $overlayElement = $(e.target).parent().find('div[aria-label][data-visualcompletion="ignore"]').first();

                                                    if ($overlayElement.length === 0) {
                                                        $overlayElement = $(e.target).first();
                                                    }
                                                }

                                                state.GL_weakCache.overlay.set($video[0], $overlayElement);

                                                $video.css('z-index', '2');
                                                $video.attr('controls', true);
                                                $targets.css('z-index', '-10');
                                                $overlayElement.css('z-index', '-10');

                                                $readMoreButton.hide();
                                                $bottomBar.hide();

                                                toggleVolumeSilder($video, $video.parents('div[style][class]').filter(function () {
                                                    return $(this).width() == $video.width();
                                                }).first(), storyType, 'vertical');
                                            };

                                            // Hide layout to show controller
                                            $targets.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', hideContextmenu);
                                            $readMoreButton.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', hideContextmenu);
                                            $bottomBar.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', hideContextmenu);
                                            $videoParent.off('contextmenu.IG_videoControl').on('contextmenu.IG_videoControl', hideContextmenu);

                                            // Restore layout to show details interface
                                            $video.on('contextmenu', function (e) {
                                                e.preventDefault();
                                                e.stopPropagation();

                                                $video.css('z-index', '-1');
                                                $video.removeAttr('controls');
                                                $targets.css('z-index', '1');
                                                state.GL_weakCache.overlay.get($video[0])?.css('z-index', '1');

                                                $bottomBar.show();
                                                $readMoreButton.show();

                                                toggleVolumeSilder($video, $video.parents('div[style][class]').filter(function () {
                                                    return $(this).width() == $video.width();
                                                }).first(), storyType, 'vertical');
                                            });

                                            $video.on('volumechange', function () {
                                                let $element_mute_button = state.GL_weakCache.mutedButton.get(this) || {};
                                                var is_element_muted = $element_mute_button?.find && $element_mute_button.find('svg > path[d^="M16.636"]').length === 0;

                                                if (this.muted != is_element_muted) {
                                                    this.volume = state.videoVolume;

                                                    triggerReactClickHandler($element_mute_button.first()[0]);
                                                }

                                                const $v = $(this);
                                                if ($v.data('completed')) {
                                                    state.videoVolume = this.volume;
                                                    GM_setValue('G_VIDEO_VOLUME', this.volume);
                                                }

                                                if (this.volume == state.videoVolume) {
                                                    $v.data('completed', true);
                                                }
                                            });

                                            $video.css('position', 'absolute');
                                            $video.data('controls', true);

                                            toggleVolumeSilder($video, $video.parents('div[style][class]').filter(function () {
                                                return $(this).width() == $video.width();
                                            }).first(), storyType, 'vertical');
                                        }
                                    }
                                    else {
                                        toggleVolumeSilder($video, $video.parents('div[style][class]').filter(function () {
                                            return $(this).width() == $video.width();
                                        }).first(), storyType, 'vertical');
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });

        (function installElementObserver(attempts) {
            const mountRoot = $('div[id^="mount"]')[0];
            if (mountRoot) {
                element_observer.observe(mountRoot, { childList: true, subtree: true });
                logger('[element_observer] installed on mount root');
            } else if (attempts > 0) {
                setTimeout(() => installElementObserver(attempts - 1), 250);
                logger('[element_observer] mount root not ready, retrying...');
            } else {
                logger('[element_observer] mount root not found after multiple retries');
            }
        })(20);
    });
})(jQuery, Mediabunny);
